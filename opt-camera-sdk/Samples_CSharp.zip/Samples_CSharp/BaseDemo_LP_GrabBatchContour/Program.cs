﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using System.Net;
using System.Net.Sockets;
using System.Runtime.InteropServices;

using SciCamera.Net;

namespace BaseDemo_LP_GrabContour
{
    internal partial class Program
    {
        // ---------------------------------------------------------------------------------------
        // 用户可配置的参数部分：
        private const int m_LineCount = 1000;     // 总采集行数
        private const int m_BatchNumber = 100;    // 批处理量
        private const int m_Timeout = 5000;       // 采集超时

        // 32S轮廓数据格式
        private static SciCam.SciCamPayloadDataType m_DataType = SciCam.SciCamPayloadDataType.SciCam_Payload_DataType_INT;
        //private static int m_invalidValue = int.MinValue;
        private static int m_invalidValue = 0;
        private static IntPtr m_rangeImageData = Marshal.AllocHGlobal(3200 * m_LineCount * sizeof(int));

        // 16U轮廓数据格式
        //private static SciCam.SciCamPayloadDataType m_DataType = SciCam.SciCamPayloadDataType.SciCam_Payload_DataType_USHORT;
        //private static ushort m_invalidValue = ushort.MinValue;
        //private static IntPtr m_rangeImageData = Marshal.AllocHGlobal(3200 * m_LineCount * sizeof(ushort));
        // ---------------------------------------------------------------------------------------

        private static SciCam.SCI_DEVICE_INFO m_currentDevInfo = new SciCam.SCI_DEVICE_INFO();
        private static SciCam m_currentDev = new SciCam();
        private static SciCam.fnOnPayloadDelegate m_imageCallBack;

        private static SciCam.SCI_NODE_VAL_FLOAT m_ZMin = new SciCam.SCI_NODE_VAL_FLOAT();
        private static SciCam.SCI_NODE_VAL_FLOAT m_ZMax = new SciCam.SCI_NODE_VAL_FLOAT();
        private static SciCam.SCI_NODE_VAL_FLOAT m_XSizeInfo = new SciCam.SCI_NODE_VAL_FLOAT();
        private static SciCam.SCI_NODE_VAL_INT m_Scaler = new SciCam.SCI_NODE_VAL_INT();

        private static string GetEnumStr_SciCamDeviceType(SciCam.SciCamDeviceType val)
        {
            switch (val)
            {
                case SciCam.SciCamDeviceType.SciCam_DeviceType_Unknown:
                    return "Unknown device";
                case SciCam.SciCamDeviceType.SciCam_DeviceType_2D:
                    return "2D device";
                case SciCam.SciCamDeviceType.SciCam_DeviceType_3DLP:
                    return "3DLP device";
                default:
                    break;
            }

            return "Invalid";
        }

        private static string GetEnumStr_SciCamTLType(SciCam.SciCamTLType val)
        {
            switch (val)
            {
                case SciCam.SciCamTLType.SciCam_TLType_Unknown:
                    return "Unknown";
                case SciCam.SciCamTLType.SciCam_TLType_Gige:
                    return "Gige";
                case SciCam.SciCamTLType.SciCam_TLType_Usb3:
                    return "USB3";
                case SciCam.SciCamTLType.SciCam_TLType_CL:
                    return "CL";
                case SciCam.SciCamTLType.SciCam_TLType_CXP:
                    return "CXP";
                case SciCam.SciCamTLType.SciCam_TLType_IIDC:
                    return "IIDC";
                case SciCam.SciCamTLType.SciCam_TLType_UVC:
                    return "UVC";
                case SciCam.SciCamTLType.SciCam_TLType_CLHS:
                    return "CLHS";
                case SciCam.SciCamTLType.SciCam_TLType_Ethernet:
                    return "Ethernet";
                case SciCam.SciCamTLType.SciCam_TLType_PCI:
                    return "PCI";
                case SciCam.SciCamTLType.SciCam_TLType_CL_CAM_ONLY:
                    return "CL_CAM_ONLY";
                default:
                    break;
            }

            return "Invalid";
        }

        private static string i4tos(uint ip)
        {
            IPAddress ipAddress = new IPAddress(ip);
            return ipAddress.ToString();
        }

        private static void ShowDeviceInfo(ref SciCam.SCI_DEVICE_INFO device)
        {
            string devType = GetEnumStr_SciCamDeviceType(device.devType);
            Console.WriteLine("| Device type: {0}", devType);

            string devTlType = GetEnumStr_SciCamTLType(device.tlType);
            Console.WriteLine("| Device transfer type: {0}", devTlType);

            if (device.tlType == SciCam.SciCamTLType.SciCam_TLType_Gige)
            {
                SciCam.SCI_DEVICE_GIGE_INFO gigeDevInfo = (SciCam.SCI_DEVICE_GIGE_INFO)SciCam.ByteToStruct(device.info.gigeInfo, typeof(SciCam.SCI_DEVICE_GIGE_INFO));
                Console.WriteLine("| Camera status: {0}", gigeDevInfo.status);
                Console.WriteLine("| Camera name: {0}", gigeDevInfo.name);
                Console.WriteLine("| Camera manufactureName: {0}", gigeDevInfo.manufactureName);
                Console.WriteLine("| Camera modelName: {0}", gigeDevInfo.modelName);
                Console.WriteLine("| Camera version: {0}", gigeDevInfo.version);
                Console.WriteLine("| Camera userDefineName: {0}", gigeDevInfo.userDefineName);
                Console.WriteLine("| Camera serialNumber: {0}", gigeDevInfo.serialNumber);
                Console.WriteLine("| Camera mac: {0:X}:{1:X}:{2:X}:{3:X}:{4:X}:{5:X}", gigeDevInfo.mac[0], gigeDevInfo.mac[1], gigeDevInfo.mac[2], gigeDevInfo.mac[3], gigeDevInfo.mac[4], gigeDevInfo.mac[5]);
                Console.WriteLine("| Camera ip: {0}", i4tos(gigeDevInfo.ip));
                Console.WriteLine("| Camera mask: {0}", i4tos(gigeDevInfo.mask));
                Console.WriteLine("| Camera gateway: {0}", i4tos(gigeDevInfo.gateway));
                Console.WriteLine("| Camera adapterIp: {0}", i4tos(gigeDevInfo.adapterIp));
                Console.WriteLine("| Camera adapterMask: {0}", i4tos(gigeDevInfo.adapterMask));
                Console.WriteLine("| Camera adapterName: {0}", gigeDevInfo.adapterName);
            }
            else if (device.tlType == SciCam.SciCamTLType.SciCam_TLType_Usb3)
            {
                SciCam.SCI_DEVICE_USB3_INFO usb3Info = (SciCam.SCI_DEVICE_USB3_INFO)SciCam.ByteToStruct(device.info.gigeInfo, typeof(SciCam.SCI_DEVICE_USB3_INFO));
                Console.WriteLine("| Camera status: {0}", usb3Info.status);
                Console.WriteLine("| Camera name: {0}", usb3Info.name);
                Console.WriteLine("| Camera manufactureName: {0}", usb3Info.manufactureName);
                Console.WriteLine("| Camera modelName: {0}", usb3Info.modelName);
                Console.WriteLine("| Camera version: {0}", usb3Info.version);
                Console.WriteLine("| Camera userDefineName: {0}", usb3Info.userDefineName);
                Console.WriteLine("| Camera serialNumber: {0}", usb3Info.serialNumber);
                Console.WriteLine("| Camera guid: {0}", usb3Info.guid);
                Console.WriteLine("| Camera U3VVersion: {0}", usb3Info.U3VVersion);
                Console.WriteLine("| Camera GenCPVersion: {0}", usb3Info.GenCPVersion);
            }
            else if (device.tlType == SciCam.SciCamTLType.SciCam_TLType_CL)
            {
                SciCam.SCI_DEVICE_CL_INFO clInfo = (SciCam.SCI_DEVICE_CL_INFO)SciCam.ByteToStruct(device.info.gigeInfo, typeof(SciCam.SCI_DEVICE_CL_INFO));
                Console.WriteLine("| Card Status: {0}", clInfo.cardStatus);
                Console.WriteLine("| Card Name: {0}", clInfo.cardName);
                Console.WriteLine("| Card Manufacture: {0}", clInfo.cardManufacture);
                Console.WriteLine("| Card Model: {0}", clInfo.cardModel);
                Console.WriteLine("| Card Version: {0}", clInfo.cardVersion);
                Console.WriteLine("| Card UserDefineName: {0}", clInfo.cardUserDefineName);
                Console.WriteLine("| Card SerialNumber: {0}", clInfo.cardSerialNumber);

                Console.WriteLine("| Camera Status: {0}", clInfo.cameraStatus);
                Console.WriteLine("| Camera Type: {0}", clInfo.cameraType);
                Console.WriteLine("| Camera Baud: {0}", clInfo.cameraBaud);
                Console.WriteLine("| Camera Model: {0}", clInfo.cameraModel);
                Console.WriteLine("| Camera Manufacture: {0}", clInfo.cameraManufacture);
                Console.WriteLine("| Camera Family: {0}", clInfo.cameraFamily);
                Console.WriteLine("| Camera Model: {0}", clInfo.cameraModel);
                Console.WriteLine("| Camera Version: {0}", clInfo.cameraVersion);
                Console.WriteLine("| Camera SerialNumber: {0}", clInfo.cameraSerialNumber);
                Console.WriteLine("| Camera SerialPort: {0}", clInfo.cameraSerialPort);
                Console.WriteLine("| Camera Protocol: {0}", clInfo.cameraProtocol);
            }
        }

        private static int WaitForNumInput(bool isLimit, int min, int max)
        {
            int number;

            while (true)
            {
                if (int.TryParse(Console.ReadLine(), out number))
                {
                    if (isLimit)
                    {
                        if (number < min || number > max)
                        {
                            Console.Write("Input error, please input again: ");
                        }
                        else
                        {
                            break;
                        }
                    }
                    else
                    {
                        break;
                    }
                }
                else
                {
                    Console.Write("Input error, please input again: ");
                }
            }

            return number;
        }

        private static void PayloadReceived(IntPtr payload, IntPtr tag)
        {
            SciCam.SCI_CAM_LP3D_META payloadMeta = new SciCam.SCI_CAM_LP3D_META();
            uint nReVal = SciCam.PayloadLP3DGetMeta(payload, ref payloadMeta);
            if(nReVal != SciCam.SCI_CAMERA_OK)
            {
                return;
            }

            Console.WriteLine("FrameID: {0}  Index: {1}  IsFinish: {2}", payloadMeta.frameId, payloadMeta.index, payloadMeta.finished);
            // 原则上此处是需要先调用SciCam_Payload_LP3D_GetPointCounts，获取批轮廓点数，根据点数分配内存空间，
            // 接着调用SciCam_Payload_LP3D_GetContour进行一批轮廓的内存拷贝；

            uint offset = payloadMeta.index * 3200 * m_BatchNumber * 4;
            IntPtr invalidValue = new IntPtr(m_invalidValue);
            IntPtr pCpntour = new IntPtr(m_rangeImageData.ToInt64() + offset);
            nReVal = SciCam.PayloadLP3DGetContour(payload, m_DataType, pCpntour, invalidValue);

            if(payloadMeta.finished)
            {
                // 此处已完成整帧轮廓数据的拼接，可直接拷贝m_rangeImageData进行使用；

            }
        }

        static void Main(string[] args)
        {
            // 搜索相机
            SciCam.SCI_DEVICE_INFO_LIST devInfos = new SciCam.SCI_DEVICE_INFO_LIST();
            UInt32 reVal = SciCam.DiscoveryDevices(ref devInfos, 0);
            Console.WriteLine("The number of discovered devices is: {0}", devInfos.count);
            for (uint i = 0; i < devInfos.count; ++i)
            {
                Console.WriteLine("-------------------------------------------");
                Console.WriteLine("| ---- Index: {0}", i);
                ShowDeviceInfo(ref devInfos.pDevInfo[i]);
            }
            if (devInfos.count != 0)
            {
                Console.WriteLine("-------------------------------------------");
                Console.Write("Please enter your selection based on the index: ");
                int op = WaitForNumInput(true, 0, (int)devInfos.count - 1);

                m_currentDevInfo = devInfos.pDevInfo[op];
            }

            // 创建相机
            uint nReVal = m_currentDev.CreateDevice(ref m_currentDevInfo);
            if (nReVal != SciCam.SCI_CAMERA_OK)
            {
                Console.WriteLine("Create device failed, return error code: {0}", nReVal);
                return;
            }
            else
            {
                Console.WriteLine("Create device success.");
            }

            // 打开相机
            nReVal = m_currentDev.OpenDevice();
            if (nReVal != SciCam.SCI_CAMERA_OK)
            {
                Console.WriteLine("Open device failed, return error code: {0}", nReVal);
                return;
            }
            else
            {
                Console.WriteLine("Open device success!");
            }

            // 注册采集回调
            m_imageCallBack = new SciCam.fnOnPayloadDelegate(PayloadReceived);
            nReVal = m_currentDev.RegisterPayloadCallBack(m_imageCallBack, IntPtr.Zero, true);
            if (nReVal != SciCam.SCI_CAMERA_OK)
            {
                Console.WriteLine("Register payload callback function failed, return error code: {0}", nReVal);
                return;
            }
            else
            {
                Console.WriteLine("Register payload callback function success!");
            }

            // 获取节点参数值
            nReVal = m_currentDev.GetFloatValueEx(SciCam.SciCamDeviceXmlType.SciCam_DeviceXml_Camera,"ZUpSizeInfo", ref m_ZMax);
            if(nReVal != SciCam.SCI_CAMERA_OK)
            {
                Console.WriteLine("GetFloatValue: ZUpSizeInfo failed, return error code: {0}", nReVal);
                return;
            }
            else
            {
                Console.WriteLine("GetFloatValue: ZUpSizeInfo success.");
            }

            nReVal = m_currentDev.GetFloatValueEx(SciCam.SciCamDeviceXmlType.SciCam_DeviceXml_Camera,"ZDownSizeInfo", ref m_ZMin);
            if (nReVal != SciCam.SCI_CAMERA_OK)
            {
                Console.WriteLine("GetFloatValue: ZDownSizeInfo failed, return error code: {0}", nReVal);
                return;
            }
            else
            {
                Console.WriteLine("GetFloatValue: ZDownSizeInfo success.");
            }

            nReVal = m_currentDev.GetIntValueEx(SciCam.SciCamDeviceXmlType.SciCam_DeviceXml_Camera,"Scaler", ref m_Scaler);
            if(nReVal != SciCam.SCI_CAMERA_OK)
            {
                Console.WriteLine("GetIntValue: Scaler failed, return error code: {0}", nReVal);
                return;
            }
            else
            {
                Console.WriteLine("GetIntValue: Scaler success.");
            }

            nReVal = m_currentDev.GetFloatValueEx(SciCam.SciCamDeviceXmlType.SciCam_DeviceXml_Camera,"XSizeInfo", ref m_XSizeInfo);
            if(nReVal != SciCam.SCI_CAMERA_OK)
            {
                Console.WriteLine("GetFloatValue: XSizeInfo failed, return error code: {0}", nReVal);
                return;
            }
            else
            {
                Console.WriteLine("GetFloatValue: XSizeInfo success.");
            }

            // 设置采集模式为批量轮廓
            nReVal = m_currentDev.LP3D_SetGrabType(SciCam.SciCamLp3dGrabMode.SciCam_GrabMode_LP3D_BatchContour);
            if(nReVal != SciCam.SCI_CAMERA_OK)
            {
                Console.WriteLine("SetGrabType: SciCam_GrabMode_LP3D_BatchContour failed, return error code: {0}", nReVal);
                return;
            }
            else
            {
                Console.WriteLine("SetGrabType: SciCam_GrabMode_LP3D_BatchContour success.");
            }

            // 设置采集超时
            nReVal = m_currentDev.SetGrabTimeout(m_Timeout);
            if(nReVal != SciCam.SCI_CAMERA_OK)
            {
                Console.WriteLine("SetGrabTimeout failed, return error code: {0}", nReVal);
                return;
            }
            else
            {
                Console.WriteLine("SetGrabTimeout success.");
            }

            // 设置批处理量
            nReVal = m_currentDev.SetIntValueEx(SciCam.SciCamDeviceXmlType.SciCam_DeviceXml_Camera,"BatchNumber", m_BatchNumber);
            if(nReVal != SciCam.SCI_CAMERA_OK)
            {
                Console.WriteLine("SetIntValue: BatchNumber failed, return error code: {0}", nReVal);
                return;
            }
            else
            {
                Console.WriteLine("SetIntValue: BatchNumber success.");
            }

            // 设置总采集行数
            nReVal = m_currentDev.SetIntValueEx(SciCam.SciCamDeviceXmlType.SciCam_DeviceXml_Camera,"AcquisitionLineCount", m_LineCount);
            if(nReVal != SciCam.SCI_CAMERA_OK)
            {
                Console.WriteLine("SetIntValue: AcquisitionLineCount failed, return error code: {0}", nReVal);
                return;
            }
            else
            {
                Console.WriteLine("SetIntValue: AcquisitionLineCount success.");
            }

            // 设置采集的轮廓数据位数，如设置失败则代表该激光线扫设备不支持该数据类型设置
            if(m_DataType == SciCam.SciCamPayloadDataType.SciCam_Payload_DataType_USHORT)
            {
                nReVal = m_currentDev.SetEnumValueByStringEx(SciCam.SciCamDeviceXmlType.SciCam_DeviceXml_Camera,"DepthDataType", "Uint16_t");
            }
            else if(m_DataType == SciCam.SciCamPayloadDataType.SciCam_Payload_DataType_INT)
            {
                nReVal = m_currentDev.SetEnumValueByStringEx(SciCam.SciCamDeviceXmlType.SciCam_DeviceXml_Camera,"DepthDataType", "Uint32_t");
            }

            if(nReVal != SciCam.SCI_CAMERA_OK)
            {
                m_DataType = SciCam.SciCamPayloadDataType.SciCam_Payload_DataType_INT;
            }

            // 开始采集
            nReVal = m_currentDev.StartGrabbing();
            if(nReVal != SciCam.SCI_CAMERA_OK)
            {
                Console.WriteLine("StartGrabbing failed, return error code: {0}", nReVal);
                return;
            }
            else
            {
                Console.WriteLine("StartGrabbing success.");
            }

            Console.WriteLine("Press any key to continue...");
            Console.ReadLine();

            nReVal = m_currentDev.StopGrabbing();
            nReVal = m_currentDev.CloseDevice();
        }
    }
}

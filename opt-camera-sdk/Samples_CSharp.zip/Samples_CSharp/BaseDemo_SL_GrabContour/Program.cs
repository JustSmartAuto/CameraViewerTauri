﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using System.Net;
using System.Net.Sockets;
using System.Runtime.InteropServices;

using SciCamera.Net;
using System.CodeDom;
using static SciCamera.Net.SciCam;

namespace BaseDemo_SL_Console
{
    internal partial class Program
    {


        private static SciCam.SCI_DEVICE_INFO m_currentDevInfo = new SciCam.SCI_DEVICE_INFO();
        private static SciCam m_currentDev = new SciCam();
        private static SciCam.fnOnPayloadDelegate m_imageCallBack;

        private static string GetEnumStr_SciCamDeviceType(SciCam.SciCamDeviceType val)
        {
            switch (val)
            {
                case SciCam.SciCamDeviceType.SciCam_DeviceType_Unknown:
                    return "Unknown device";
                case SciCam.SciCamDeviceType.SciCam_DeviceType_2D:
                    return "2D device";
                case SciCam.SciCamDeviceType.SciCam_DeviceType_3DLP:
                    return "3DLP device";
                default:
                    break;
            }

            return "Invalid";
        }

        private static string GetEnumStr_SciCamTLType(SciCam.SciCamTLType val)
        {
            switch (val)
            {
                case SciCam.SciCamTLType.SciCam_TLType_Unknown:
                    return "Unknown";
                case SciCam.SciCamTLType.SciCam_TLType_Gige:
                    return "Gige";
                case SciCam.SciCamTLType.SciCam_TLType_Usb3:
                    return "USB3";
                case SciCam.SciCamTLType.SciCam_TLType_CL:
                    return "CL";
                case SciCam.SciCamTLType.SciCam_TLType_CXP:
                    return "CXP";
                case SciCam.SciCamTLType.SciCam_TLType_IIDC:
                    return "IIDC";
                case SciCam.SciCamTLType.SciCam_TLType_UVC:
                    return "UVC";
                case SciCam.SciCamTLType.SciCam_TLType_CLHS:
                    return "CLHS";
                case SciCam.SciCamTLType.SciCam_TLType_Ethernet:
                    return "Ethernet";
                case SciCam.SciCamTLType.SciCam_TLType_PCI:
                    return "PCI";
                case SciCam.SciCamTLType.SciCam_TLType_CL_CAM_ONLY:
                    return "CL_CAM_ONLY";
                default:
                    break;
            }

            return "Invalid";
        }

        private static string i4tos(uint ip)
        {
            IPAddress ipAddress = new IPAddress(ip);
            return ipAddress.ToString();
        }

        private static void ShowDeviceInfo(ref SciCam.SCI_DEVICE_INFO device)
        {
            string devType = GetEnumStr_SciCamDeviceType(device.devType);
            Console.WriteLine("| Device type: {0}", devType);

            string devTlType = GetEnumStr_SciCamTLType(device.tlType);
            Console.WriteLine("| Device transfer type: {0}", devTlType);

            if (device.tlType == SciCam.SciCamTLType.SciCam_TLType_Gige)
            {
                SciCam.SCI_DEVICE_GIGE_INFO gigeDevInfo = (SciCam.SCI_DEVICE_GIGE_INFO)SciCam.ByteToStruct(device.info.gigeInfo, typeof(SciCam.SCI_DEVICE_GIGE_INFO));
                Console.WriteLine("| Camera status: {0}", gigeDevInfo.status);
                Console.WriteLine("| Camera name: {0}", gigeDevInfo.name);
                Console.WriteLine("| Camera manufactureName: {0}", gigeDevInfo.manufactureName);
                Console.WriteLine("| Camera modelName: {0}", gigeDevInfo.modelName);
                Console.WriteLine("| Camera version: {0}", gigeDevInfo.version);
                Console.WriteLine("| Camera userDefineName: {0}", gigeDevInfo.userDefineName);
                Console.WriteLine("| Camera serialNumber: {0}", gigeDevInfo.serialNumber);
                Console.WriteLine("| Camera mac: {0:X}:{1:X}:{2:X}:{3:X}:{4:X}:{5:X}", gigeDevInfo.mac[0], gigeDevInfo.mac[1], gigeDevInfo.mac[2], gigeDevInfo.mac[3], gigeDevInfo.mac[4], gigeDevInfo.mac[5]);
                Console.WriteLine("| Camera ip: {0}", i4tos(gigeDevInfo.ip));
                Console.WriteLine("| Camera mask: {0}", i4tos(gigeDevInfo.mask));
                Console.WriteLine("| Camera gateway: {0}", i4tos(gigeDevInfo.gateway));
                Console.WriteLine("| Camera adapterIp: {0}", i4tos(gigeDevInfo.adapterIp));
                Console.WriteLine("| Camera adapterMask: {0}", i4tos(gigeDevInfo.adapterMask));
                Console.WriteLine("| Camera adapterName: {0}", gigeDevInfo.adapterName);
            }

          
        }

        private static int WaitForNumInput(bool isLimit, int min, int max)
        {
            int number;

            while (true)
            {
                if (int.TryParse(Console.ReadLine(), out number))
                {
                    if (isLimit)
                    {
                        if (number < min || number > max)
                        {
                            Console.Write("Input error, please input again: ");
                        }
                        else
                        {
                            break;
                        }
                    }
                    else
                    {
                        break;
                    }
                }
                else
                {
                    Console.Write("Input error, please input again: ");
                }
            }

            return number;
        }

        private static void PayloadReceived(IntPtr payload, IntPtr tag)
        {
            SciCam.SCI_CAM_SL3D_META payloadMeta = new SciCam.SCI_CAM_SL3D_META();
            uint nReVal = SciCam.PayloadSL3DGetMeta(payload, ref payloadMeta);
            if (nReVal == SciCam.SCI_CAMERA_OK)
            {
                Console.WriteLine("FrameID: {0}   IsFinish: {1}", payloadMeta.frameId,  payloadMeta.finished);
                Console.WriteLine("Get meta success");
            }
            else
            {
                Console.WriteLine("GetMeta failed, return error code:{0}", nReVal);
                return;
            }

            //获取当前帧的2D图信息或3D图信息
            //条纹结构光：双投影FPB设备目标数据类型分左右，单投影FPC设备只有右侧图像目标数据
            SciCamPayloadSL3DTargetDataType target = SciCamPayloadSL3DTargetDataType.SciCam_payload_SL_Striped_2D_Right;  //目标图像数据类型为：条纹结构光右2D图
            //SciCamPayloadSL3DTargetDataType target = SciCamPayloadSL3DTargetDataType.SciCam_payload_SL_Striped_3D;  //目标图像数据类型为：条纹结构光FP3D点云数据

            //散斑结构光：SciCamPayloadSL3DTargetDataType target = SciCamPayloadSL3DTargetDataType.SciCam_payload_SL_Speckle_2D_Left;
            //SciCamPayloadSL3DTargetDataType target1 = SciCamPayloadSL3DTargetDataType.SciCam_payload_SL_Speckle_3D;
            SCI_CAM_SL3D_DATA pData = new SCI_CAM_SL3D_DATA();
            nReVal = SciCam.PayloadSL3DGetData(payload, target, ref pData);
            if (nReVal != SciCam.SCI_CAMERA_OK)
            {

                Console.WriteLine("Get data failed, return error code: {0}", nReVal);
                return;
            }
            else
            {
                Console.WriteLine("Get data success");
                Console.WriteLine("Get data success");
                Console.WriteLine("deviceType: " + pData.deviceType);
                Console.WriteLine("imageType: " + pData.imageType);
                Console.WriteLine("imageNum: " + (int)pData.imageNum);
                Console.WriteLine("calculated: " + (int)pData.calculated);
                Console.WriteLine("pixelFormat: " + pData.pixelFormat.ToString("X"));
                Console.WriteLine("width: " + pData.width);
                Console.WriteLine("height: " + pData.height);
                Console.WriteLine("step: " + pData.step);
                Console.WriteLine("channel: " + pData.channel);
                Console.WriteLine("dataType: " + pData.dataType);
                Console.WriteLine("RangeImageInfo.someInfo: ");
                Console.WriteLine("RangeImageInfo.minValue: " + pData.RangeImageInfo.minValue);
                Console.WriteLine("RangeImageInfo.maxValue: " + pData.RangeImageInfo.maxValue);
                Console.WriteLine("RangeImageInfo.resolutionX: " + pData.RangeImageInfo.resolutionX);
                Console.WriteLine("RangeImageInfo.resolutionY: " + pData.RangeImageInfo.resolutionY);
                Console.WriteLine("RangeImageInfo.resolutionZ: " + pData.RangeImageInfo.resolutionZ);
                Console.WriteLine("RangeImageInfo.offsetX: " + pData.RangeImageInfo.offsetX);
                Console.WriteLine("RangeImageInfo.offsetY: " + pData.RangeImageInfo.offsetY);
                Console.WriteLine("RangeImageInfo.offsetZ: " + pData.RangeImageInfo.offsetZ);
                Console.WriteLine("RangeImageInfo.modelType: " + (int)pData.RangeImageInfo.modelType);
                // 数据指针，在 C# 中使用 IntPtr 表示
                Console.WriteLine("data: " + pData.data);
                string saveFileParam1 = @"D:\image\2D_Right_Image.bmp";
                nReVal = SciCam.PayloadSaveImage(saveFileParam1, pData.pixelFormat, pData.data, pData.width, pData.height);
                if (nReVal == SciCam.SCI_CAMERA_OK)
                {
                    Console.WriteLine("SaveImage success.");
                }
            }




                if (payloadMeta.finished)
            {
               

            }
        }

        static void Main(string[] args)
        {
            // 搜索相机
            SciCam.SCI_DEVICE_INFO_LIST devInfos = new SciCam.SCI_DEVICE_INFO_LIST();
            UInt32 reVal = SciCam.DiscoveryDevices(ref devInfos, 0);
            Console.WriteLine("The number of discovered devices is: {0}", devInfos.count);
            for (uint i = 0; i < devInfos.count; ++i)
            {
                Console.WriteLine("-------------------------------------------");
                Console.WriteLine("| ---- Index: {0}", i);
                ShowDeviceInfo(ref devInfos.pDevInfo[i]);
            }
            if (devInfos.count != 0)
            {
                Console.WriteLine("-------------------------------------------");
                Console.Write("Please enter your selection based on the index: ");
                int op = WaitForNumInput(true, 0, (int)devInfos.count - 1);

                m_currentDevInfo = devInfos.pDevInfo[op];
            }

            // 创建相机
            uint nReVal = m_currentDev.CreateDevice(ref m_currentDevInfo);
            if (nReVal != SciCam.SCI_CAMERA_OK)
            {
                Console.WriteLine("Create device failed, return error code: {0}", nReVal);
                return;
            }
            else
            {
                Console.WriteLine("Create device success.");
            }

            // 打开相机
            nReVal = m_currentDev.OpenDevice();
            if (nReVal != SciCam.SCI_CAMERA_OK)
            {
                Console.WriteLine("Open device failed, return error code: {0}", nReVal);
                return;
            }
            else
            {
                Console.WriteLine("Open device success!");
            }

           //注册采集回调
           //m_imageCallBack = new SciCam.fnOnPayloadDelegate(PayloadReceived);
           // nReVal = m_currentDev.RegisterPayloadCallBack(m_imageCallBack, IntPtr.Zero, true);
           // if (nReVal != SciCam.SCI_CAMERA_OK)
           // {
           //     Console.WriteLine("Register payload callback function failed, return error code: {0}", nReVal);
           //     return;
           // }
           // else
           // {
           //     Console.WriteLine("Register payload callback function success!");
           // }


            bool nodeVal = false;
            //获取参数 判断是否输出2D图像或3D图像 条纹结构光
            nReVal = m_currentDev.GetBoolValueEx(SciCam.SciCamDeviceXmlType.SciCam_DeviceXml_Camera, "Left2DImage", ref nodeVal);
            if (nReVal == SciCam.SCI_CAMERA_OK)
            {
                Console.WriteLine("---- Node Name: {0} ", "Left2DImage");
                Console.WriteLine("---- Node Current Value: {0}", (nodeVal ? "true" : "false"));
            }
            nReVal = m_currentDev.GetBoolValue("Right2DImage", ref nodeVal);
            if (nReVal == SciCam.SCI_CAMERA_OK)
            {
                Console.WriteLine("---- Node Name: {0} ", "Right2DImage");
                Console.WriteLine("---- Node Current Value: {0}", (nodeVal ? "true" : "false"));
            }
            nReVal = m_currentDev.GetBoolValueEx(SciCam.SciCamDeviceXmlType.SciCam_DeviceXml_Camera, "Range3DImage", ref nodeVal);
            if (nReVal == SciCam.SCI_CAMERA_OK)
            {
                Console.WriteLine("---- Node Name: {0} ", "Range3DImage");
                Console.WriteLine("---- Node Current Value: {0}", (nodeVal ? "true" : "false"));
            }
            //设置需要输出的图像类型 为true
            nReVal = m_currentDev.SetBoolValueEx(SciCam.SciCamDeviceXmlType.SciCam_DeviceXml_Camera, "Left2DImage", nodeVal);
            if (nReVal == SciCam.SCI_CAMERA_OK)
            {
                Console.WriteLine("Set device node: {0}, val: {1} success!", "Left2DImage", (nodeVal ? "true" : "false"));
            }
            nReVal = m_currentDev.SetBoolValueEx(SciCam.SciCamDeviceXmlType.SciCam_DeviceXml_Camera, "Right2DImage", nodeVal);
            if (nReVal == SciCam.SCI_CAMERA_OK)
            {
                Console.WriteLine("Set device node: {0}, val: {1} success!", "Right2DImage", (nodeVal ? "true" : "false"));
            }
            nReVal = m_currentDev.SetBoolValueEx(SciCam.SciCamDeviceXmlType.SciCam_DeviceXml_Camera, "Range3DImage", nodeVal);
            if (nReVal == SciCam.SCI_CAMERA_OK)
            {
                Console.WriteLine("Set device node: {0}, val: {1} success!", "Range3DImage", (nodeVal ? "true" : "false"));
            }

            //设置采集模式 0.自由采集 1.硬触发 2.软触发
            nReVal = m_currentDev.SetEnumValueEx(SciCam.SciCamDeviceXmlType.SciCam_DeviceXml_Camera, "Acquisition", 0);
            if (nReVal == SciCam.SCI_CAMERA_OK)
            {
                Console.WriteLine("Set device node: {0}, val: {1} success!", "Acquisition", nodeVal);
            }

            //设置条纹结构光光机亮度
            nReVal = m_currentDev.SetIntValueEx(SciCam.SciCamDeviceXmlType.SciCam_DeviceXml_Camera, "Light1Value", 300);
            if (nReVal == SciCam.SCI_CAMERA_OK)
            {
                Console.WriteLine("Set device node: {0}, val: {1} success!", "Light1Value", 300);
            }



            // 开始采集
            nReVal = m_currentDev.StartGrabbing();
            if (nReVal != SciCam.SCI_CAMERA_OK)
            {
                Console.WriteLine("StartGrabbing failed, return error code: {0}", nReVal);
                return;
            }
            else
            {
                Console.WriteLine("StartGrabbing success.");
            }

            IntPtr pPayload = IntPtr.Zero;
            while (true)
            {
                nReVal = m_currentDev.Grab(ref pPayload);
                if (nReVal != SciCam.SCI_CAMERA_OK)
                {
                    Console.WriteLine("Grab failed, return error code: {0}", nReVal);
                    return;
                }
                else
                {
                    Console.WriteLine("Grab success!");
                }
                SCI_CAM_SL3D_META pMeta = new SCI_CAM_SL3D_META();
                nReVal = SciCam.PayloadSL3DGetMeta(pPayload, ref pMeta);
                if (nReVal == SciCam.SCI_CAMERA_OK)
                {
                    Console.WriteLine("FrameID: {0}   IsFinish: {1}", pMeta.frameId, pMeta.finished);
                    Console.WriteLine("Get meta success");
                }
                else
                {
                    Console.WriteLine("GetMeta failed, return error code:{0}", nReVal);
                    return;
                }

                //获取当前帧的2D图信息或3D图信息
                //条纹结构光：双投影FPB设备目标数据类型分左右，单投影FPC设备只有右侧图像目标数据
                SciCamPayloadSL3DTargetDataType target = SciCamPayloadSL3DTargetDataType.SciCam_payload_SL_Striped_2D_Right;  //目标图像数据类型为：条纹结构光右2D图
                //SciCamPayloadSL3DTargetDataType target = SciCamPayloadSL3DTargetDataType.SciCam_payload_SL_Striped_3D;  //目标图像数据类型为：条纹结构光FP3D点云数据

                //散斑结构光：SciCamPayloadSL3DTargetDataType target = SciCamPayloadSL3DTargetDataType.SciCam_payload_SL_Speckle_2D_Left;
                //SciCamPayloadSL3DTargetDataType target1 = SciCamPayloadSL3DTargetDataType.SciCam_payload_SL_Speckle_3D;
                SCI_CAM_SL3D_DATA pData = new SCI_CAM_SL3D_DATA();
                nReVal = SciCam.PayloadSL3DGetData(pPayload, target, ref pData);
                if (nReVal != SciCam.SCI_CAMERA_OK)
                {

                    Console.WriteLine("Get data failed, return error code: {0}", nReVal);
                    return;
                }
                else
                {
                    Console.WriteLine("Get data success");
                    Console.WriteLine("Get data success");
                    Console.WriteLine("deviceType: " + pData.deviceType);
                    Console.WriteLine("imageType: " + pData.imageType);
                    Console.WriteLine("imageNum: " + (int)pData.imageNum);
                    Console.WriteLine("calculated: " + (int)pData.calculated);
                    Console.WriteLine("pixelFormat: " + pData.pixelFormat.ToString("X"));
                    Console.WriteLine("width: " + pData.width);
                    Console.WriteLine("height: " + pData.height);
                    Console.WriteLine("step: " + pData.step);
                    Console.WriteLine("channel: " + pData.channel);
                    Console.WriteLine("dataType: " + pData.dataType);
                    Console.WriteLine("RangeImageInfo.someInfo: ");
                    Console.WriteLine("RangeImageInfo.minValue: " + pData.RangeImageInfo.minValue);
                    Console.WriteLine("RangeImageInfo.maxValue: " + pData.RangeImageInfo.maxValue);
                    Console.WriteLine("RangeImageInfo.resolutionX: " + pData.RangeImageInfo.resolutionX);
                    Console.WriteLine("RangeImageInfo.resolutionY: " + pData.RangeImageInfo.resolutionY);
                    Console.WriteLine("RangeImageInfo.resolutionZ: " + pData.RangeImageInfo.resolutionZ);
                    Console.WriteLine("RangeImageInfo.offsetX: " + pData.RangeImageInfo.offsetX);
                    Console.WriteLine("RangeImageInfo.offsetY: " + pData.RangeImageInfo.offsetY);
                    Console.WriteLine("RangeImageInfo.offsetZ: " + pData.RangeImageInfo.offsetZ);
                    Console.WriteLine("RangeImageInfo.modelType: " + (int)pData.RangeImageInfo.modelType);
                    // 数据指针，在 C# 中使用 IntPtr 表示
                    Console.WriteLine("data: " + pData.data);
                    string saveFileParam1 = @"D:\image\2D_Right_Image.bmp";
                    nReVal = SciCam.PayloadSaveImage(saveFileParam1, pData.pixelFormat, pData.data, pData.width, pData.height);
                    if (nReVal == SciCam.SCI_CAMERA_OK)
                    {
                        Console.WriteLine("SaveImage success.");
                    }
                }

                nReVal = m_currentDev.FreePayload(pPayload);
                if (nReVal != SciCam.SCI_CAMERA_OK)
                {
                    Console.WriteLine("Free payload failed, return error code: {0}", nReVal);
                }


             }
            Console.WriteLine("Press any key to continue...");
            Console.ReadLine();

            nReVal = m_currentDev.StopGrabbing();
            nReVal = m_currentDev.CloseDevice();


        }
    }
}


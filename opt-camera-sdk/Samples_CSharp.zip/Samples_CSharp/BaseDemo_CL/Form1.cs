﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Net;
using System.Threading;
using System.Runtime.InteropServices;
using GdiPlus = System.Drawing.Imaging;
using System.Windows.Forms;

using SciCamera.Net;

namespace BaseDemo
{
	public partial class Form1 : Form
	{
		SciCam.SCI_DEVICE_INFO_LIST m_stDevList = new SciCam.SCI_DEVICE_INFO_LIST();    //设备列表
		SciCam m_currentDev = new SciCam();		//当前设备
		Boolean m_bDeviceReady = false;         //是否存在相机
		Boolean m_bDeviceOpened = false;        //相机是否打开
		Boolean m_bStartGrabbing = false;       //开始采集状态

		Thread m_hGrabThread = null;			//取流线程句柄
		bool m_bThreadState = false;            //线程状态
        float m_frameRateEditValue = 0;


        enum ImageSaveType
		{
			Type_NONE = 0,
			Type_BMP,
			Type_JPG,
			Type_TIFF,
			Type_PNG,
		};
		ImageSaveType m_imageSaveType;          //保存图像类型

		static Mutex mutex = new Mutex();

		public Form1()
		{
			InitializeComponent();
			DiscoveryDevices();
			RefreshWindow();
			Control.CheckForIllegalCrossThreadCalls = false;
		}

		private void ShowMsg(string msg, uint nErrorNum)
		{
			string errorMsg;
			if(nErrorNum == 0)
			{
				errorMsg = msg;
			}
			else
			{
				errorMsg = msg + ": Error code = " + string.Format("{0}", nErrorNum) + ": ";
			}

			switch (nErrorNum)
			{
				case SciCam.SCI_CAMERA_OK: errorMsg += " Success."; break;
				case SciCam.SCI_ERR_CAMERA_INCORRECT_INIT_OBJECT: errorMsg += " Incorrect initialization object."; break;
				case SciCam.SCI_ERR_CAMERA_PARAM_INVALID: errorMsg += " Parameter is invalid."; break;
				case SciCam.SCI_ERR_CAMERA_SDK_VERSION_MISMATCH: errorMsg += " SDK version mismatch."; break;
				case SciCam.SCI_ERR_CAMERA_UNKNOW: errorMsg += " Unknow error."; break;
				case SciCam.SCI_ERR_CAMERA_FUNCTION_CONFLICT: errorMsg += " Function or interface call conflict."; break;
				case SciCam.SCI_ERR_CAMERA_ENUM_DEVICES_FAILED: errorMsg += " Failed to search camera."; break;
				case SciCam.SCI_ERR_CAMERA_MODIFY_IP_ADDRESS_FAILED: errorMsg += " Failed to modify camera ip address."; break;
				case SciCam.SCI_ERR_CAMERA_SET_PERSISTENT_IP_FAILED: errorMsg += " Failed to modify persistent camera ip address."; break;
				case SciCam.SCI_ERR_CAMERA_CREATE_FAILED: errorMsg += " Failed to create a camera object."; break;
				case SciCam.SCI_ERR_CAMERA_EXCEPTION: errorMsg += " Camera operation exception."; break;
				case SciCam.SCI_ERR_CAMERA_NOT_FOUND: errorMsg += " Cannot to find camera."; break;
				case SciCam.SCI_ERR_CAMERA_OFFLINE: errorMsg += " Camera is offline."; break;
				case SciCam.SCI_ERR_CAMERA_OPEN_FAILED: errorMsg += " Failed to open camera."; break;
				case SciCam.SCI_ERR_CAMERA_NOT_MISMATCHACQ: errorMsg += " Camera mismatch witch ACQ."; break;
				case SciCam.SCI_ERR_CAMERA_NOT_SUPPORT: errorMsg += " Camera does not support."; break;
				case SciCam.SCI_ERR_CAMERA_NOT_OPEN: errorMsg += " Camera isn't open."; break;
				case SciCam.SCI_ERR_CAMERA_ALLREADY_OPEN: errorMsg += " Camera allready open."; break;
				case SciCam.SCI_ERR_CAMERA_OCCUPANCY: errorMsg += " Camera occupied by another device."; break;
				case SciCam.SCI_ERR_CAMERA_ROMOVED: errorMsg += " The camera was removed."; break;
				case SciCam.SCI_ERR_CAMERA_START_GRAB_FAILED: errorMsg += " Failed to start grab."; break;
				case SciCam.SCI_ERR_CAMERA_NOT_GRABBING: errorMsg += " Camera isn't grabbing."; break;
				case SciCam.SCI_ERR_CAMERA_ALREADY_GRABBING: errorMsg += " Camera is grabbing."; break;
				case SciCam.SCI_ERR_CAMERA_GRAB_FAILED: errorMsg += " Camera grab failed."; break;
				case SciCam.SCI_ERR_CAMERA_GRAB_TIMEOUT: errorMsg += " Grab image timeout."; break;
				case SciCam.SCI_ERR_CAMERA_TRIGGER_WAIT_FAILED: errorMsg += " Wait for trigger failed."; break;
				case SciCam.SCI_ERR_CAMERA_SOFTWARE_TRIGGER_FAILED: errorMsg += " Failed to set software trigger."; break;
				case SciCam.SCI_ERR_CAMERA_GRAB_EXCEPTION: errorMsg += " Camera grab image exception."; break;
				case SciCam.SCI_ERR_CAMERA_GRAB_INTERRUPTED: errorMsg += " Capture interrupted."; break;
				case SciCam.SCI_ERR_CAMERA_GRAB_INSUFFICIENT_BUFFER: errorMsg += " Insufficient buffer for capture."; break;
				case SciCam.SCI_ERR_CAMERA_SET_VALUE_FAILED: errorMsg += " Failed to set parameter value."; break;
				case SciCam.SCI_ERR_CAMERA_GET_VALUE_FAILED: errorMsg += " Failed to Get parameter value."; break;
				case SciCam.SCI_ERR_CAMERA_SEND_CMD_FAILED: errorMsg += " Failed to send command."; break;
				case SciCam.SCI_ERR_CAMERA_WRONG_ACK: errorMsg += " Get ACK failed, maybe result of wrong IP."; break;
				case SciCam.SCI_ERR_CAMERA_FILE_OPEN_FAILED: errorMsg += " Open camera configuration file error."; break;
				case SciCam.SCI_ERR_CAMERA_NODE_XML_TYPE: errorMsg += " XML type error."; break;
				case SciCam.SCI_ERR_CAMERA_NODE_NAME_INVALID: errorMsg += " Node name is invalid."; break;
				case SciCam.SCI_ERR_CAMERA_NODE_READ_FORBIDDEN: errorMsg += " Node is forbidden to read."; break;
				case SciCam.SCI_ERR_CAMERA_NODE_WRITE_FORBIDDEN: errorMsg += " Node is forbidden to write."; break;
				case SciCam.SCI_ERR_CAMERA_NODE_TYPE_INVALID: errorMsg += " Node type is invalid."; break;
				case SciCam.SCI_ERR_CAMERA_NODE_TYPE_UNMATCH: errorMsg += " Node type is unmatched."; break;
				case SciCam.SCI_ERR_CAMERA_NODE_VALUE: errorMsg += " The value of node is wrong."; break;
				case SciCam.SCI_ERR_CAMERA_NODE_MAP_INVALID: errorMsg += " Failed to access the node map."; break;
				case SciCam.SCI_ERR_CAMERA_NODE_GET_ROOT_NODE_FAILED: errorMsg += " Failed to get root node."; break;
				case SciCam.SCI_ERR_CAMERA_NODE_TRAVERSE: errorMsg += " Failed to traverse nodes."; break;
				case SciCam.SCI_ERR_CAMERA_IMAGE_INVALID: errorMsg += " Image data is invalid."; break;
				case SciCam.SCI_ERR_CAMERA_IMAGE_CREATE_FAILED: errorMsg += " Failed to create image file."; break;
				case SciCam.SCI_ERR_CAMERA_IMAGE_TYPE_NOT_SUPPORT: errorMsg += " Image type does not support."; break;
				case SciCam.SCI_ERR_CAMERA_IMAGE_NOT_COMPLETE: errorMsg += " Grab Image not complete."; break;
				case SciCam.SCI_ERR_CAMERA_IMAGE_DATACONVERT_FAILED: errorMsg += " Failed to convert to image."; break;
				case SciCam.SCI_ERR_CAMERA_IMAGE_FORMAT: errorMsg += " Image format is wrong."; break;
				case SciCam.SCI_ERR_CAMERA_IMAGE_GET_PROPERTY: errorMsg += " Failed to get image properties (e.g., width, height)."; break;
				case SciCam.SCI_ERR_CAMERA_IMAGE_OUT_OF_BOUNDS: errorMsg += " Image data out of bounds."; break;
				case SciCam.SCI_ERR_CAMERA_CHUNKDATA_EMPTY: errorMsg += " Chunk data is empty."; break;
				case SciCam.SCI_ERR_CAMERA_CHUNKDATA_LENGTH: errorMsg += " Chunk data length is abnormal."; break;
				case SciCam.SCI_ERR_CAMERA_CHUNKDATA_PARSING_EXCEPTION: errorMsg += " Chunk parsing exception."; break;
				case SciCam.SCI_ERR_CAMERA_MEMORY_ALLOCATION_FAILED: errorMsg += " Memory allocation failed."; break;
				case SciCam.SCI_ERR_CAMERA_APPEND_BUFFER_FAILED: errorMsg += " Failed to append buffer."; break;
				case SciCam.SCI_ERR_CAMERA_SYSTEM_RESOURCE_EXHAUSTED: errorMsg += " System resource exhausted."; break;
				case SciCam.SCI_ERR_CAMERA_INSUFFICIENT_MEMORY_LENGTH: errorMsg += " Insufficient memory length at the target address."; break;
				case SciCam.SCI_ERR_CAMERA_GET_CTI_OBJECT_NULL: errorMsg += " Failed to get CTI object."; break;
				case SciCam.SCI_ERR_CAMERA_GET_ANY_PORT_FAILED: errorMsg += " Failed to get any port (card port, data stream port, or device port) is null."; break;
				case SciCam.SCI_ERR_CAMERA_GET_IF_PORT_FAILED: errorMsg += " Failed to get IF port."; break;
				case SciCam.SCI_ERR_CAMERA_GET_DEVICE_PORT_FAILED: errorMsg += " Failed to get device port."; break;
				case SciCam.SCI_ERR_CAMERA_GET_DEVICE_DATA_STREAM_PORT_FAILED: errorMsg += " Failed to get device data stream port."; break;
				case SciCam.SCI_ERR_CAMERA_GET_DEVICE_DATA_STREAM_FAILED: errorMsg += " Failed to get device data stream."; break;
				case SciCam.SCI_ERR_CAMERA_GET_DEVICE_DATA_STREAM_COUNT_ZERO: errorMsg += " Device data stream count is zero."; break;
				case SciCam.SCI_ERR_CAMERA_GET_DATA_STREAM_ID_FAILED: errorMsg += " Failed to get device data stream ID."; break;
				case SciCam.SCI_ERR_CAMERA_OPEN_DATA_STREAM_FAILED: errorMsg += " Failed to open data stream."; break;
				case SciCam.SCI_ERR_CAMERA_NODEMAP_NULL: errorMsg += " Device nodemap is null."; break;
				case SciCam.SCI_ERR_CAMERA_PAYLOAD_SIZE_INVALID: errorMsg += " Invalid payload size."; break;
				case SciCam.SCI_ERR_CAMERA_REGISTER_IMAGE_EVENT_FAILED: errorMsg += " Failed to register image event."; break;
				case SciCam.SCI_ERR_CAMERA_CTI: errorMsg += " CTI error."; break;
				case SciCam.SCI_ERR_CAMERA_DS: errorMsg += " DS error."; break;
				case SciCam.SCI_ERR_CAMERA_GEN_TL_EVENT: errorMsg += " GenTL Event error."; break;
				case SciCam.SCI_ERR_CAMERA_BUF: errorMsg += " Buf error."; break;
				default: break;
			}

			MessageBox.Show(errorMsg, "BaseDemo");
		}

		private void RefreshWindow()
		{
			// 相机列表
			comboBox_devList.Enabled = m_bDeviceReady && !m_bDeviceOpened;
			// 打开设备按钮
			button_open.Enabled = m_bDeviceReady && !m_bDeviceOpened;
			// 关闭相机按钮
			button_close.Enabled = m_bDeviceOpened;
			// 自由采集
			radioButton_continusMode.Enabled = m_bDeviceOpened && !m_bStartGrabbing;
			// 触发模式
			radioButton_triggerMode.Enabled = m_bDeviceOpened && !m_bStartGrabbing;
			// 开始采集按钮
			button_startGrabbing.Enabled = m_bDeviceOpened && !m_bStartGrabbing;
			// 停止采集按钮
			button_stopGrabbing.Enabled = m_bDeviceOpened && m_bStartGrabbing;
			// 软触发选项
			checkBox_softwareTrigger.Enabled = m_bDeviceOpened;
			// 执行按钮
			button_execute.Enabled = m_bDeviceOpened && checkBox_softwareTrigger.Checked;
			// 保存BMP按钮
			button_saveBMP.Enabled = m_bDeviceOpened && m_bStartGrabbing;
			// 保存JPG按钮
			button_saveJPG.Enabled = m_bDeviceOpened && m_bStartGrabbing;
			// 保存TIFF按钮
			button_saveTIFF.Enabled = m_bDeviceOpened && m_bStartGrabbing;
			// 保存PNG按钮
			button_savePNG.Enabled = m_bDeviceOpened && m_bStartGrabbing;
			// 像素格式
			comboBox_pixelFormat.Enabled = m_bDeviceOpened && !m_bStartGrabbing;
			// 曝光
			textBox_exposure.Enabled = m_bDeviceOpened;
			// 增益
			textBox_gain.Enabled = m_bDeviceOpened;
			// 帧率
			//textBox_frameRate.Enabled = m_bDeviceOpened;
			textBox_frameRate.Enabled = false;
			// 参数获取
			button_getParameter.Enabled = m_bDeviceOpened;
			// 参数设置
			button_setParameter.Enabled = m_bDeviceOpened;
		}

		private void RefreshTriggerModeStatus()
		{
			SciCam.SCI_NODE_VAL_ENUM eNodeVal = new SciCam.SCI_NODE_VAL_ENUM();
			uint nReVal = m_currentDev.GetEnumValueEx(SciCam.SciCamDeviceXmlType.SciCam_DeviceXml_Card, "FrameTriggerCtrl", ref eNodeVal);
			if(nReVal != SciCam.SCI_CAMERA_OK)
			{
				ShowMsg("Get FrameTriggerCtrl failed", nReVal);
			}

			string triggerMode = "Disable";
			for(int i = 0; i < eNodeVal.itemCount; i++)
			{
				if(eNodeVal.nVal == eNodeVal.items[i].val)
				{
					triggerMode = eNodeVal.items[i].desc;
					break;
				}
			}
			if (triggerMode == "Disable")
			{
				radioButton_continusMode.Checked = true;
				radioButton_triggerMode.Checked = false;
				checkBox_softwareTrigger.Enabled = false;
			}
			else
			{
				radioButton_continusMode.Checked = false;
				radioButton_triggerMode.Checked = true;
				checkBox_softwareTrigger.Enabled = true;
			}
		}

		private void GetPixelFormat()
		{
			comboBox_pixelFormat.Items.Clear();

			SciCam.SCI_NODE_VAL_ENUM eNodeVal = new SciCam.SCI_NODE_VAL_ENUM();
			uint nReVal = m_currentDev.GetEnumValueEx(SciCam.SciCamDeviceXmlType.SciCam_DeviceXml_Card, "PixelFormat", ref eNodeVal);

			if(nReVal == SciCam.SCI_CAMERA_OK)
			{
				int currentIndex = 0;
				for(int i = 0; i < eNodeVal.itemCount; i++)
				{
					string itemStr = eNodeVal.items[i].desc;
					comboBox_pixelFormat.Items.Add(itemStr);
					if(eNodeVal.nVal == eNodeVal.items[i].val)
					{
						currentIndex = i;
					}
				}

				comboBox_pixelFormat.SelectedIndex = currentIndex;
			}
		}

		private uint SetPixelFormat()
		{
			uint nReVal = SciCam.SCI_CAMERA_OK;
			int nIndex = comboBox_pixelFormat.SelectedIndex;
			if(nIndex != -1)
			{
				string str = comboBox_pixelFormat.SelectedItem.ToString();
				nReVal = m_currentDev.SetEnumValueByStringEx(SciCam.SciCamDeviceXmlType.SciCam_DeviceXml_Card, "PixelFormat", str);
			}

			return nReVal;
		}

		private uint GetExposureTime()
		{
			string[] nodeName = new string[]
			{
				"ExposureTime",
				"ExposureTimeAbs",
				"ExposureTimeRaw"
			};

			uint nReVal = SciCam.SCI_CAMERA_OK;
			for(int i = 0; i < nodeName.Count(); i++)
			{
				SciCam.SCI_NODE_VAL_INT iNodeVal = new SciCam.SCI_NODE_VAL_INT();
				nReVal = m_currentDev.GetIntValueEx(SciCam.SciCamDeviceXmlType.SciCam_DeviceXml_Camera, nodeName[i], ref iNodeVal);
				if(nReVal != SciCam.SCI_CAMERA_OK)
				{
					SciCam.SCI_NODE_VAL_FLOAT fNodeVal = new SciCam.SCI_NODE_VAL_FLOAT();
					nReVal = m_currentDev.GetFloatValueEx(SciCam.SciCamDeviceXmlType.SciCam_DeviceXml_Camera, nodeName[i], ref fNodeVal);
					if(nReVal == SciCam.SCI_CAMERA_OK)
					{
						textBox_exposure.Text = fNodeVal.dVal.ToString();
						break;
					}
				}
				else
				{
					textBox_exposure.Text = iNodeVal.nVal.ToString();
					break;
				}
			}

			return nReVal;
		}

		private uint SetExposureTime()
		{
			string[] nodeName = new string[]
			{
				"ExposureTime",
				"ExposureTimeAbs",
				"ExposureTimeRaw"
			};

			uint nReVal = SciCam.SCI_CAMERA_OK;

			int iExposure = 0;
			bool success = int.TryParse(textBox_exposure.Text, out iExposure);
			if(success)
			{
				for (int i = 0; i < nodeName.Count(); i++)
				{
					nReVal = m_currentDev.SetIntValueEx(SciCam.SciCamDeviceXmlType.SciCam_DeviceXml_Camera, nodeName[i], iExposure);
					if(nReVal != SciCam.SCI_CAMERA_OK)
					{
						double dExposure = 0;
						success = double.TryParse(textBox_exposure.Text, out dExposure);
						if(success)
						{
							nReVal = m_currentDev.SetFloatValueEx(SciCam.SciCamDeviceXmlType.SciCam_DeviceXml_Camera, nodeName[i], dExposure);
							if(nReVal == SciCam.SCI_CAMERA_OK)
							{
								break;
							}
						}
					}
					else
					{
						break;
					}
				}
			}

			return nReVal;
		}

		private uint GetGain()
		{
			string[] nodeName = new string[]
			{
				"Gain",
				"GainRaw"
			};

			uint nReVal = SciCam.SCI_CAMERA_OK;
			for(int i = 0; i < nodeName.Count(); i++)
			{
				SciCam.SCI_NODE_VAL_INT iNodeVal = new SciCam.SCI_NODE_VAL_INT();
				nReVal = m_currentDev.GetIntValueEx(SciCam.SciCamDeviceXmlType.SciCam_DeviceXml_Camera, nodeName[i], ref iNodeVal);
				if(nReVal != SciCam.SCI_CAMERA_OK)
				{
					SciCam.SCI_NODE_VAL_FLOAT fNodeVal = new SciCam.SCI_NODE_VAL_FLOAT();
					nReVal = m_currentDev.GetFloatValueEx(SciCam.SciCamDeviceXmlType.SciCam_DeviceXml_Camera, nodeName[i], ref fNodeVal);
					if(nReVal == SciCam.SCI_CAMERA_OK)
					{
						textBox_gain.Text = fNodeVal.dVal.ToString();
						break;
					}
				}
				else
				{
					textBox_gain.Text = iNodeVal.nVal.ToString();
					break;
				}
			}

			return nReVal;
		}

		private uint SetGain()
		{
			string[] nodeName = new string[]
			{
				"Gain",
				"GainRaw"
			};

			uint nReVal = SciCam.SCI_CAMERA_OK;

			int iGain = 0;
			bool success = int.TryParse(textBox_gain.Text, out iGain);
			if(success)
			{
				for (int i = 0; i < nodeName.Count(); i++)
				{
					nReVal = m_currentDev.SetIntValueEx(SciCam.SciCamDeviceXmlType.SciCam_DeviceXml_Camera, nodeName[i], iGain);
					if(nReVal != SciCam.SCI_CAMERA_OK)
					{
						double dGain = 0;
						success = double.TryParse(textBox_gain.Text, out dGain);
						if(success)
						{
							nReVal = m_currentDev.SetFloatValueEx(SciCam.SciCamDeviceXmlType.SciCam_DeviceXml_Camera, nodeName[i], dGain);
							if(nReVal == SciCam.SCI_CAMERA_OK)
							{
								break;
							}
						}
					}
				}
			}

			return nReVal;
		}

        private uint GetFrameRate()
        {
            uint nReVal = SciCam.SCI_CAMERA_OK;
            SciCam.SCI_NODE_VAL_INT iLNodeVal = new SciCam.SCI_NODE_VAL_INT();
            nReVal = m_currentDev.GetIntValueEx(SciCam.SciCamDeviceXmlType.SciCam_DeviceXml_Card, "CameraLineRate", ref iLNodeVal);
            SciCam.SCI_NODE_VAL_INT iHNodeVal = new SciCam.SCI_NODE_VAL_INT();
            m_currentDev.GetIntValueEx(SciCam.SciCamDeviceXmlType.SciCam_DeviceXml_Card, "Height", ref iHNodeVal);
            if (nReVal == SciCam.SCI_CAMERA_OK)
            {
                m_frameRateEditValue = (float)iLNodeVal.nVal / (float)iHNodeVal.nVal;
                textBox_frameRate.Text = m_frameRateEditValue.ToString("F2");
            }

            return nReVal;
        }

        private uint SetFrameRate()
		{
			string[] nodeName = new string[]
			{
				"ResultingFrameRate",
				"ResultingFrameRateAbs",
				"AcquisitionActualFrameRate"
			};

			uint nReVal = SciCam.SCI_CAMERA_OK;
			//nReVal = SciCam_SetBoolValue(m_currentDevHandle, "AcquisitionFrameRateEnable", true);
			nReVal = m_currentDev.SetBoolValueEx(SciCam.SciCamDeviceXmlType.SciCam_DeviceXml_Camera, "AcquisitionFrameRateEnable", true);
			if(nReVal == SciCam.SCI_CAMERA_OK)
			{
				for(int i = 0; i < nodeName.Count(); i++)
				{
					double dFrameRate = 0;
					bool success = double.TryParse(textBox_frameRate.Text, out dFrameRate);
					if(success)
					{
						nReVal = m_currentDev.SetFloatValueEx(SciCam.SciCamDeviceXmlType.SciCam_DeviceXml_Camera, nodeName[i], dFrameRate);
						if(nReVal == SciCam.SCI_CAMERA_OK)
						{
							break;
						}
					}
					
				}
			}


			return nReVal;
		}

		private void GetParameter()
		{
			uint nReVal = GetExposureTime();
			if(nReVal != SciCam.SCI_CAMERA_OK)
			{
				ShowMsg("Get ExposureTime failed", nReVal);
			}

			nReVal = GetGain();
			if(nReVal!= SciCam.SCI_CAMERA_OK)
			{
				ShowMsg("Get Gain failed", nReVal);
			}

			nReVal = GetFrameRate();
			if(nReVal != SciCam.SCI_CAMERA_OK)
			{
				ShowMsg("FrameRate failed", nReVal);
			}
		}

		private void SetParameter()
		{
			uint nReVal = SetExposureTime();
			if (nReVal != SciCam.SCI_CAMERA_OK)
			{
				ShowMsg("Set ExposureTime failed", nReVal);
			}

			nReVal = SetGain();
			if (nReVal != SciCam.SCI_CAMERA_OK)
			{
				ShowMsg("Set Gain failed", nReVal);
			}

			//nReVal = SetFrameRate();
			//if (nReVal != SciCam.SCI_CAMERA_OK)
			//{
			//	ShowMsg("Set FrameRate failed", nReVal);
			//}
		}

		private string i4tos(uint ip)
		{
			IPAddress iPAddress = new IPAddress(ip);
			return iPAddress.ToString();
		}

		private void DiscoveryDevices()
		{
			System.GC.Collect();
			comboBox_devList.Items.Clear();
			uint nReVal = SciCam.DiscoveryDevices(ref m_stDevList, (uint)(SciCam.SciCamTLType.SciCam_TLType_CL));
			if (nReVal != SciCam.SCI_CAMERA_OK)
			{
				ShowMsg("Discovery devices failed!", nReVal);
				m_bDeviceReady = false;
				RefreshWindow();
				return;
			}
			if (m_stDevList.count == 0)
			{
				ShowMsg("Discovery devices Success, but found 0 device.", 0);
				m_bDeviceReady = false;
				RefreshWindow();
				return;
			}

			for (int i = 0; i < m_stDevList.count; i++)
			{
				SciCam.SCI_DEVICE_INFO device = m_stDevList.pDevInfo[i];
				SciCam.SciCamTLType devTlType = device.tlType;

				if (devTlType == SciCam.SciCamTLType.SciCam_TLType_CL)
				{
                    SciCam.SCI_DEVICE_CL_INFO clInfo = (SciCam.SCI_DEVICE_CL_INFO)SciCam.ByteToStruct(device.info.clInfo, typeof(SciCam.SCI_DEVICE_CL_INFO));
                    string cardName = clInfo.cardName;
                    string cameraModel = clInfo.cameraModel;

                    string itemName = string.Format("[{0}] CL: {1}({2})", i, cardName, cameraModel);
                    comboBox_devList.Items.Add(itemName);
                }
			}

			if (comboBox_devList.Items.Count != 0)
			{
				comboBox_devList.SelectedIndex = 0;
			}

			m_bDeviceReady = true;
			RefreshWindow();
		}

		private void OpenDevice()
		{
			int currentCamIndex = comboBox_devList.SelectedIndex;
			if (currentCamIndex == -1 || m_stDevList.count == 0)
			{
				ShowMsg("Please select a device first!", 0);
				return;
			}

			uint nReVal = m_currentDev.CreateDevice(ref m_stDevList.pDevInfo[currentCamIndex]);
			if (nReVal != SciCam.SCI_CAMERA_OK)
			{
				ShowMsg("Create device failed", nReVal);
				return;
			}

			nReVal = m_currentDev.OpenDevice();
			if (nReVal != SciCam.SCI_CAMERA_OK)
			{
				ShowMsg("Open CL device failed", nReVal);
				return;
			}

			nReVal = m_currentDev.CL_OpenCam();
            if (nReVal != SciCam.SCI_CAMERA_OK)
            {
                ShowMsg("Open CL camera failed", nReVal);
                return;
            }


            m_bDeviceOpened = true;
			RefreshWindow();
			RefreshTriggerModeStatus();
			GetPixelFormat();
			GetParameter();
		}

		private void CloseDevice()
		{
			if(m_bStartGrabbing)
			{
				StopGrabbing();
			}
			if (!m_bDeviceOpened) return;
			uint nReVal = m_currentDev.CL_CloseCam();
			if(nReVal != SciCam.SCI_CAMERA_OK)
			{
				ShowMsg("Close device failed", nReVal);
				return;
			}

			nReVal = m_currentDev.DeleteDevice();
			if(nReVal != SciCam.SCI_CAMERA_OK)
			{
				ShowMsg("Delete device failed", nReVal);

			}

			m_bDeviceOpened = false;
			m_bStartGrabbing = false;
			RefreshWindow();
		}

		private void StartGrabbing()
		{
			m_bThreadState = true;
			m_hGrabThread = new Thread(GrabThreadProcess);
			m_hGrabThread.Start();
			
			uint nReVal = m_currentDev.StartGrabbing();
			if (nReVal != SciCam.SCI_CAMERA_OK)
			{
				m_bThreadState = false;
				ShowMsg("Start grabbing failed", nReVal);
				return;
			}

			m_bStartGrabbing = true;
			RefreshWindow();
		}

		private void StopGrabbing()
		{
			m_bThreadState = false;
			m_hGrabThread.Join();

			uint nReVal = m_currentDev.StopGrabbing();
			if (nReVal != SciCam.SCI_CAMERA_OK)
			{
				ShowMsg("Stop grabbing failed", nReVal);
				return;
			}

			m_bStartGrabbing = false;
			RefreshWindow();
		}

		private uint SaveImage(IntPtr imgData, ulong imgWidth, ulong imgHeight, ulong framID, SciCam.SciCamPixelType imgType)
		{
			uint nReVal = SciCam.SCI_CAMERA_OK;

			mutex.WaitOne();

			if (m_imageSaveType == ImageSaveType.Type_BMP)
            {
				string fileName = string.Format("Image_W{0}_H{1}_fID{2}.bmp", imgWidth, imgHeight, framID);
				nReVal = SciCam.PayloadSaveImage(fileName, imgType, imgData, (long)imgWidth, (long)imgHeight);
				if (nReVal != SciCam.SCI_CAMERA_OK)
				{
					ShowMsg("Save bmp image failed", nReVal);
				}
			}
			else if (m_imageSaveType == ImageSaveType.Type_JPG)
			{
				string fileName = string.Format("Image_W{0}_H{1}_fID{2}.jpeg", imgWidth, imgHeight, framID);
				nReVal = SciCam.PayloadSaveImage(fileName, imgType, imgData, (long)imgWidth, (long)imgHeight);
				if (nReVal != SciCam.SCI_CAMERA_OK)
				{
					ShowMsg("Save jpg image failed", nReVal);
				}
			}
			else if (m_imageSaveType == ImageSaveType.Type_TIFF)
			{
				string fileName = string.Format("Image_W{0}_H{1}_fID{2}.tiff", imgWidth, imgHeight, framID);
				nReVal = SciCam.PayloadSaveImage(fileName, imgType, imgData, (long)imgWidth, (long)imgHeight);
				if (nReVal != SciCam.SCI_CAMERA_OK)
				{
					ShowMsg("Save tiff image failed", nReVal);
				}
			}
			else if (m_imageSaveType == ImageSaveType.Type_PNG)
			{
				string fileName = string.Format("Image_W{0}_H{1}_fID{2}.png", imgWidth, imgHeight, framID);
				nReVal = SciCam.PayloadSaveImage(fileName, imgType, imgData, (long)imgWidth, (long)imgHeight);
				if (nReVal != SciCam.SCI_CAMERA_OK)
				{
					ShowMsg("Save png image failed", nReVal);
				}
			}

			m_imageSaveType = ImageSaveType.Type_NONE;

			mutex.ReleaseMutex();

			return 0;
		}

		private int GetConvertedInfo(IntPtr payload)
		{
			if (payload == IntPtr.Zero)
			{
				return -1;
			}

			SciCam.SCI_CAM_PAYLOAD_ATTRIBUTE payloadAttribute = new SciCam.SCI_CAM_PAYLOAD_ATTRIBUTE();
			uint nReVal = SciCam.PayloadGetAttribute(payload, ref payloadAttribute);
			if (nReVal != SciCam.SCI_CAMERA_OK)
			{
				return -1;
			}

			bool imgIsComplete = payloadAttribute.isComplete;
			SciCam.SciCamPayloadMode payloadMode = payloadAttribute.payloadMode;
			SciCam.SciCamPixelType imgPixelType = payloadAttribute.imgAttr.pixelType;
			ulong imgWidth = payloadAttribute.imgAttr.width;
			ulong imgHeight = payloadAttribute.imgAttr.height;
			ulong framID = payloadAttribute.frameID;

			if (!imgIsComplete || payloadMode != SciCam.SciCamPayloadMode.SciCam_PayloadMode_2D)
			{
				return -1;
			}

			IntPtr imgData = IntPtr.Zero;
			nReVal = SciCam.PayloadGetImage(payload, ref imgData);
			if (nReVal != SciCam.SCI_CAMERA_OK)
			{
				return -1;
			}

			long destImgSize = 0;

			if (imgPixelType == SciCam.SciCamPixelType.Mono1p ||
				imgPixelType == SciCam.SciCamPixelType.Mono2p ||
				imgPixelType == SciCam.SciCamPixelType.Mono4p ||
				imgPixelType == SciCam.SciCamPixelType.Mono8s ||
				imgPixelType == SciCam.SciCamPixelType.Mono8 ||
				imgPixelType == SciCam.SciCamPixelType.Mono10 ||
				imgPixelType == SciCam.SciCamPixelType.Mono10p ||
				imgPixelType == SciCam.SciCamPixelType.Mono12 ||
				imgPixelType == SciCam.SciCamPixelType.Mono12p ||
				imgPixelType == SciCam.SciCamPixelType.Mono14 ||
				imgPixelType == SciCam.SciCamPixelType.Mono16 ||
				imgPixelType == SciCam.SciCamPixelType.Mono10Packed ||
				imgPixelType == SciCam.SciCamPixelType.Mono12Packed ||
				imgPixelType == SciCam.SciCamPixelType.Mono14p)
			{
				nReVal = SciCam.PayloadConvertImageEx(ref payloadAttribute.imgAttr, imgData, SciCam.SciCamPixelType.Mono8, IntPtr.Zero, ref destImgSize, true,0);
				if (nReVal == SciCam.SCI_CAMERA_OK)
				{
					IntPtr destImg = Marshal.AllocHGlobal((int)destImgSize);
					try
					{
						nReVal = SciCam.PayloadConvertImageEx(ref payloadAttribute.imgAttr, imgData, SciCam.SciCamPixelType.Mono8, destImg, ref destImgSize, true,0);
						if (nReVal == SciCam.SCI_CAMERA_OK)
						{
							byte[] bBitmap = new byte[destImgSize];
							Marshal.Copy(destImg, bBitmap, 0, (int)destImgSize);
							Bitmap bitMap = new Bitmap((int)imgWidth, (int)imgHeight, GdiPlus.PixelFormat.Format8bppIndexed);
							GdiPlus.BitmapData bitmapData = bitMap.LockBits(new Rectangle(0, 0, (int)imgWidth, (int)imgHeight), GdiPlus.ImageLockMode.WriteOnly, GdiPlus.PixelFormat.Format8bppIndexed);
							Marshal.Copy(bBitmap, 0, bitmapData.Scan0, (int)destImgSize);
							bitMap.UnlockBits(bitmapData);

							//设置调色板
							GdiPlus.ColorPalette palette = bitMap.Palette;
							for (int i = 0; i < 256; i++)
							{
								palette.Entries[i] = Color.FromArgb(i, i, i);
							}
							bitMap.Palette = palette;

							//显示图片
							pictureBox_picture.Image = bitMap;
							//保存图片
							SaveImage(destImg, imgWidth, imgHeight, framID, SciCam.SciCamPixelType.Mono8);
						}
					}
					catch(Exception ex)
                    {

                    }
					finally
					{
						Marshal.FreeHGlobal(destImg);
					}
				}
			}
			else
			{
				nReVal = SciCam.PayloadConvertImageEx(ref payloadAttribute.imgAttr, imgData, SciCam.SciCamPixelType.RGB8, IntPtr.Zero, ref destImgSize, true,0);
				if (nReVal == SciCam.SCI_CAMERA_OK)
				{
					IntPtr destImg = Marshal.AllocHGlobal((int)destImgSize);
					try
					{
						nReVal = SciCam.PayloadConvertImageEx(ref payloadAttribute.imgAttr, imgData, SciCam.SciCamPixelType.RGB8, destImg, ref destImgSize, true,0);
						if (nReVal == SciCam.SCI_CAMERA_OK)
						{
							byte[] bBitmap = new byte[destImgSize];
							Marshal.Copy(destImg, bBitmap, 0, (int)destImgSize);
							Bitmap bitMap = new Bitmap((int)imgWidth, (int)imgHeight, GdiPlus.PixelFormat.Format24bppRgb);
							GdiPlus.BitmapData bitmapData = bitMap.LockBits(new Rectangle(0, 0, (int)imgWidth, (int)imgHeight), GdiPlus.ImageLockMode.WriteOnly, GdiPlus.PixelFormat.Format24bppRgb);
							Marshal.Copy(bBitmap, 0, bitmapData.Scan0, (int)destImgSize);
							bitMap.UnlockBits(bitmapData);

							//显示图片
							pictureBox_picture.Image = bitMap;
							//保存图片
							SaveImage(destImg, imgWidth, imgHeight, framID, SciCam.SciCamPixelType.RGB8);
						}
					}
					catch (Exception ex)
					{

					}
					finally
					{
						Marshal.FreeHGlobal(destImg);
					}
				}
			}
			return 0;
		}

		private void GrabThreadProcess()
		{
			uint nReVal = SciCam.SCI_CAMERA_OK;
			IntPtr payload = IntPtr.Zero;

			while(m_bThreadState)
			{
				nReVal = m_currentDev.Grab(ref payload);
				if (nReVal == SciCam.SCI_CAMERA_OK)
				{
					int reVal = GetConvertedInfo(payload);
				}

				nReVal = m_currentDev.FreePayload(payload);
			}
		}

		private void button1_Click(object sender, EventArgs e)
		{
			// 搜索设备
			button_search.Enabled = false;
			DiscoveryDevices();
			button_search.Enabled = true;
		}

		private void button2_Click(object sender, EventArgs e)
		{
			// 打开设备
			OpenDevice();
		}

		private void button3_Click(object sender, EventArgs e)
		{
			// 关闭设备
			CloseDevice();
		}

		private void radioButton1_CheckedChanged(object sender, EventArgs e)
		{
			// 自由采集
			checkBox_softwareTrigger.Checked = false;

			uint nReVal = m_currentDev.SetEnumValueByStringEx(SciCam.SciCamDeviceXmlType.SciCam_DeviceXml_Card, "FrameTriggerCtrl", "Disable");
			if(nReVal != SciCam.SCI_CAMERA_OK)
			{
				ShowMsg("Set FrameTriggerCtrl Disable failed", nReVal);
			}
		}

		private void radioButton2_CheckedChanged(object sender, EventArgs e)
		{
			// 触发模式

            uint nReVal = m_currentDev.SetEnumValueByStringEx(SciCam.SciCamDeviceXmlType.SciCam_DeviceXml_Card, "FrameTriggerCtrl", "Enable");
            if (nReVal != SciCam.SCI_CAMERA_OK)
			{
                ShowMsg("Set FrameTriggerCtrl Enable failed", nReVal);
				return;
            }

            checkBox_softwareTrigger.Checked = true;
        }

		private void button4_Click(object sender, EventArgs e)
		{
			// 开始采集
			StartGrabbing();
		}

		private void button5_Click(object sender, EventArgs e)
		{
			// 停止采集
			StopGrabbing();
		}

		private void checkBox1_CheckedChanged(object sender, EventArgs e)
		{
			// 软触发
			bool isCheck = checkBox_softwareTrigger.Checked;
			if(isCheck)
			{
				uint nReVal = m_currentDev.SetEnumValueByStringEx(SciCam.SciCamDeviceXmlType.SciCam_DeviceXml_Card, "FrameTriggerSource", "Software");
				if(nReVal != SciCam.SCI_CAMERA_OK)
				{
					ShowMsg("Set FrameTriggerSource: Software failed", nReVal);
					checkBox_softwareTrigger.Checked = false;
				}
			}

			RefreshWindow();
		}

		private void button6_Click(object sender, EventArgs e)
		{
			// 执行
			uint nReVal = m_currentDev.SetCommandValueEx(SciCam.SciCamDeviceXmlType.SciCam_DeviceXml_Card, "TriggerSoftware");
			if (nReVal != SciCam.SCI_CAMERA_OK)
			{
				ShowMsg("Excuse TriggerSoftware failed", nReVal);
			}
		}

		private void button7_Click(object sender, EventArgs e)
		{
			// 保存BMP
			mutex.WaitOne();
			m_imageSaveType = ImageSaveType.Type_BMP;
			mutex.ReleaseMutex();
		}

		private void button8_Click(object sender, EventArgs e)
		{
			// 保存JPG
			mutex.WaitOne();
			m_imageSaveType = ImageSaveType.Type_JPG;
			mutex.ReleaseMutex();
		}

		private void button9_Click(object sender, EventArgs e)
		{
			// 保存TIFF
			mutex.WaitOne();
			m_imageSaveType = ImageSaveType.Type_TIFF;
			mutex.ReleaseMutex();
		}

		private void button10_Click(object sender, EventArgs e)
		{
			// 保存PNG
			mutex.WaitOne();
			m_imageSaveType = ImageSaveType.Type_PNG;
			mutex.ReleaseMutex();
		}

		private void button11_Click(object sender, EventArgs e)
		{
			// 参数获取
			GetParameter();
		}

		private void button12_Click(object sender, EventArgs e)
		{
			// 参数设置
			SetParameter();
		}

		private void comboBox_pixelFormat_SelectedIndexChanged(object sender, EventArgs e)
		{
			SetPixelFormat();
		}

        private void comboBox_devList_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.InteropServices;
using System.Threading;
using SciCamera.Net;
namespace Events
{
    class Events
    {


        static bool g_bExit = true;	//ch:线程状态 | en:Thread Status


        // ch:打印设备信息 | en:Print Device Info
        static void PrintDeviceInfo(SciCam.SCI_DEVICE_INFO info)
        {
            SciCam.SCI_DEVICE_GIGE_INFO gigeDevInfo = (SciCam.SCI_DEVICE_GIGE_INFO)SciCam.ByteToStruct(info.info.gigeInfo, typeof(SciCam.SCI_DEVICE_GIGE_INFO));
            uint ip = gigeDevInfo.ip;
            int nIp1 = (int)(ip & 0x000000ff);
            int nIp2 = (int)((ip & 0x0000ff00) >> 8);
            int nIp3 = (int)((ip & 0x00ff0000) >> 16);
            int nIp4 = (int)((ip & 0xff000000) >> 24);
            // ch:打印当前相机ip,制造商和序列号 | en:print current ip,ManufactureName,SN 
            Console.WriteLine("CurrentIp: {0}.{1}.{2}.{3}", nIp1, nIp2, nIp3, nIp4);
            Console.WriteLine("Serial Number: {0}", gigeDevInfo.serialNumber);
            Console.WriteLine("ManufactureName: {0}", gigeDevInfo.manufactureName);
            Console.WriteLine("ModelName: {0}\n", gigeDevInfo.modelName);
        }

        // ch:事件回调接口 | en:Event Callback interface     
        static void EventCallBack(ref SciCam.SCI_CAM_EVENT evt, IntPtr tag)
        {
            Console.WriteLine("EventID{0}, EventTick{1}, EventData{2}, EventDatalen{3}",
            evt.id, evt.tick, evt.data, evt.len);
        }

		// ch:线程工作函数 | en:Thread Work function
        static void WorkThread(object obj)
        {
            SciCam handle = (SciCam)obj;
            uint nReVal = SciCam.SCI_CAMERA_OK;
            IntPtr payload = IntPtr.Zero;
            SciCam.SCI_CAM_PAYLOAD_ATTRIBUTE attribute = new SciCam.SCI_CAM_PAYLOAD_ATTRIBUTE();
            while (g_bExit)
            {

                if (!handle.IsDeviceOpen()) return;
                // ch:获取一张图像 | en:Get One Frame
                nReVal = handle.Grab(ref payload);
                if (nReVal != SciCam.SCI_CAMERA_OK)
                {
                    Console.WriteLine("Get Payload Fail! nRet:{0}", nReVal);
                    continue;
                }
                else
                {
                    Console.WriteLine("Get Payload Sucees! nRet:{0}", nReVal);
                    
                }

                // ch:获取图像信息 | en: Get Iamge Attribute
                nReVal = SciCam.PayloadGetAttribute(payload, ref attribute);
                if (nReVal != SciCam.SCI_CAMERA_OK)
                {
                    Console.WriteLine("Get Payload Attribute fail! nRet:{0}", nReVal);
                    continue;
                }
                else
                {
                    Console.WriteLine("Get Payload Attribute: Width[{0}], Height[{1}], FrameNum[{2}]",
                         attribute.imgAttr.width, attribute.imgAttr.height, attribute.frameID);
                    handle.FreePayload(payload);
                }
            }
        }

        static void Main(string[] args)
        {
            SciCam.SCI_DEVICE_INFO_LIST m_devlist = new SciCam.SCI_DEVICE_INFO_LIST();// ch:设备列表 | en:Device List
            SciCam m_currentDev = new SciCam();// ch:设备对象 | en:Device Object
            Thread m_hGrabThread = null;		//ch:取流线程句柄 | en:Grab Thread Handle
            
            do{
                 // ch:枚举设备 | en:Enum device
                 uint nReVal = SciCam.DiscoveryDevices(ref m_devlist, (uint)(SciCam.SciCamTLType.SciCam_TLType_Gige));
                 if (nReVal != SciCam.SCI_CAMERA_OK)
                {
                    Console.WriteLine("Enum Device Fail! nRet:{0}", nReVal);
                    break;
                }
                if (m_devlist.count > 0)
                {
                    for (int i = 0; i < m_devlist.count; i++)
                    {
                        Console.WriteLine("Device {0}", i);
                        PrintDeviceInfo(m_devlist.pDevInfo[i]);
                    }
                }
                else
                {
                    Console.WriteLine("Find no Device");
                    break;
                }

                // ch:选择设备并创建句柄 | en:Select device and create handle
                int index = 0;
                Console.WriteLine("Please input index(0-{0}):", m_devlist.count - 1);
                index = Convert.ToInt32(Console.ReadLine());
				if (index >= m_devlist.count )
                {
                    Console.WriteLine("Input error!\n");
                    break;
                }
                nReVal = m_currentDev.CreateDevice(ref m_devlist.pDevInfo[index]);
                if (nReVal != SciCam.SCI_CAMERA_OK)
                {
                    Console.WriteLine("Creat Device Fail! nRet:{0}", nReVal);
                    break;
                }

                // ch:打开设备 | en:Open device
                nReVal = m_currentDev.OpenDevice();
                if (nReVal != SciCam.SCI_CAMERA_OK)
                {
                    Console.WriteLine("Open Device Fail! nRet:{0}", nReVal);
                    break;
                }

                // ch:设置触发模式为off | en:Set trigger mode as off
                nReVal = m_currentDev.SetEnumValueByStringEx(SciCam.SciCamDeviceXmlType.SciCam_DeviceXml_Camera, "TriggerMode", "Off");
                if (nReVal != SciCam.SCI_CAMERA_OK)
                {
                    Console.WriteLine("Stop Grabbing fail! nRet:{0}", nReVal);
                    break;
                }

                // ch:开始取流 | en:Start grab image
                nReVal = m_currentDev.StartGrabbing();
                if (nReVal != SciCam.SCI_CAMERA_OK)
                {
                    Console.WriteLine("Start Grabbing fail! nRet:{0}", 0);
                    break;
                }

                // ch:注册事件回调 | en:Register event callback
                nReVal = m_currentDev.RegisterEventCallback(new SciCam.fnOnEventDelegate(EventCallBack),IntPtr.Zero);
                if (nReVal != SciCam.SCI_CAMERA_OK)
                {
                    Console.WriteLine("Register Event CallBack fail! nRet {0}", nReVal);
                    break;
                }

                // ch:开启抓图线程 | en: Start the grabbing thread
                m_hGrabThread = new Thread(WorkThread);
                m_hGrabThread.Start(m_currentDev);

                Console.WriteLine("Press Any Key to Stop");
                Console.ReadLine();

                //ch: 通知线程退出 | en: Notify the grab thread to exit
                g_bExit = false;
                m_hGrabThread.Join();

                // ch:停止取流 | en:Stop grab image
                nReVal = m_currentDev.StopGrabbing();
                if (nReVal != SciCam.SCI_CAMERA_OK)
                {
                    Console.WriteLine("Stop Grabbing fail! nRet:{0}", nReVal);
                    break;
                }

                // ch:关闭设备 | en:Close device
                nReVal = m_currentDev.CloseDevice();
                if (nReVal != SciCam.SCI_CAMERA_OK)
                {
                    Console.WriteLine("Close Device fail! nRet:{0}", nReVal);
                    break;
                }

                // ch:销毁句柄 | en:Destroy handle
                nReVal = m_currentDev.DeleteDevice();
                if (nReVal != SciCam.SCI_CAMERA_OK)
                {
                    Console.WriteLine("Delete Device fail! nRet:{0}", nReVal);
                    break;
                }



        }while(false);
        Console.WriteLine("Press Any Key to Exit");
        Console.ReadLine();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.InteropServices;
using System.Threading;
using SciCamera.Net;
using System.Reflection;
namespace GrabStrategies
{
    class GrabStrategies
    {
        // ch:打印设备信息 | en:Print Device Info
        static void PrintDeviceInfo(SciCam.SCI_DEVICE_INFO info)
        {
            SciCam.SCI_DEVICE_GIGE_INFO gigeDevInfo = (SciCam.SCI_DEVICE_GIGE_INFO)SciCam.ByteToStruct(info.info.gigeInfo, typeof(SciCam.SCI_DEVICE_GIGE_INFO));
            uint ip = gigeDevInfo.ip;
            int nIp1 = (int)(ip & 0x000000ff);
            int nIp2 = (int)((ip & 0x0000ff00) >> 8);
            int nIp3 = (int)((ip & 0x00ff0000) >> 16);
            int nIp4 = (int)((ip & 0xff000000) >> 24);
            // ch:打印当前相机ip,制造商和序列号 | en:print current ip,ManufactureName,SN 
            Console.WriteLine("CurrentIp: {0}.{1}.{2}.{3}", nIp1, nIp2, nIp3, nIp4);
            Console.WriteLine("Serial Number: {0}", gigeDevInfo.serialNumber);
            Console.WriteLine("UserDefinedName: {0}\n", gigeDevInfo.manufactureName);
        }

        // ch:线程工作函数 | en:Thread Work function
        static void UpcomingThread(object obj)
        {
            SciCam handle = (SciCam)obj;
            Thread.Sleep(3000);
            Console.WriteLine("Trigger Software Once for SCI_CAMERAGrabStrategy_UpcomingImage");
            // ch:发送软触发命令 | en:Send Trigger Software command
            handle.SetCommandValueEx(SciCam.SciCamDeviceXmlType.SciCam_DeviceXml_Camera, "TriggerSoftware");
        }

        static void Main(string[] args)
        {
            SciCam.SCI_DEVICE_INFO_LIST m_devlist = new SciCam.SCI_DEVICE_INFO_LIST();// ch:设备列表 | en:Device List
            SciCam m_currentDev = new SciCam();// ch:设备对象 | en:Device Object
            IntPtr payload = IntPtr.Zero;
            SciCam.SCI_CAM_PAYLOAD_ATTRIBUTE m_attribute = new SciCam.SCI_CAM_PAYLOAD_ATTRIBUTE();
            Thread m_hGrabThread = null;		//ch:取流线程句柄 | en:Grab Thread Handle
            
            do{
                 // ch:枚举设备 | en:Enum device
                 uint nReVal = SciCam.DiscoveryDevices(ref m_devlist, (uint)(SciCam.SciCamTLType.SciCam_TLType_Gige));
                 if (nReVal != SciCam.SCI_CAMERA_OK)
                {
                    Console.WriteLine("Enum Device Fail! nRet:{0}", nReVal);
                    break;
                }
                if (m_devlist.count > 0)
                {
                    for (int i = 0; i < m_devlist.count; i++)
                    {
                        Console.WriteLine("Device {0}", i);
                        PrintDeviceInfo(m_devlist.pDevInfo[i]);
                    }
                }
                else
                {
                    Console.WriteLine("Find no Device");
                    break;
                }

                // ch:选择设备并创建句柄 | en:Select device and create handle
                int index = 0;
                Console.WriteLine("Please input index(0-{0}):", m_devlist.count - 1);
                index = Convert.ToInt32(Console.ReadLine());
                if (index >= m_devlist.count )
                {
                    Console.WriteLine("Input error!\n");
                    break;
                }
                nReVal = m_currentDev.CreateDevice(ref m_devlist.pDevInfo[index]);
                if (nReVal != SciCam.SCI_CAMERA_OK)
                {
                    Console.WriteLine("Creat Device Fail! nRet:{0}", nReVal);
                    break;
                }

                // ch:打开设备 | en:Open device
                nReVal = m_currentDev.OpenDevice();
                if (nReVal != SciCam.SCI_CAMERA_OK)
                {
                    Console.WriteLine("Open Device Fail! nRet:{0}", nReVal);
                    break;
                }

                // ch:设置触发模式为on | en:Set trigger mode as On
                nReVal = m_currentDev.SetEnumValueByStringEx(SciCam.SciCamDeviceXmlType.SciCam_DeviceXml_Camera, "TriggerMode", "On");
                if (nReVal != SciCam.SCI_CAMERA_OK)
                {
                    Console.WriteLine("Stop Grabbing fail! nRet:{0}", nReVal);
                    break;
                }

                // ch:设置触发源 | en:Set Trigger Source
                nReVal = m_currentDev.SetEnumValueByStringEx(SciCam.SciCamDeviceXmlType.SciCam_DeviceXml_Camera, "TriggerSource", "Software");
                if (nReVal != SciCam.SCI_CAMERA_OK)
                {
                    Console.WriteLine("Set Trigger Source fail! nRet {0}\n", nReVal);
                    break;
                }

                Console.WriteLine("\n**********************************");
                Console.WriteLine("* 0.SciCam_GrabStrategy_OneByOne;  *");
                Console.WriteLine("* 1.SciCam_GrabStrategy_Latest;    *");
                Console.WriteLine("* 2.SciCam_GrabStrategy_Upcoming;  *");
                Console.WriteLine("************************************");
                Console.WriteLine("Please Input Grab Strategy:");

                int nGrabStrategy = 0;
                nGrabStrategy = Convert.ToInt32(Console.ReadLine());
                switch (nGrabStrategy)
                    {
                    case 0:
                             Console.WriteLine("Grab using the SciCam_GrabStrategy_OneByOne default strategy");
                            // ch:设置采集策略 | en:Set Grab Strategy
                            nReVal = m_currentDev.SetGrabStrategy(SciCam.SciCamGrabStrategy.SciCam_GrabStrategy_OneByOne);
                            if (nReVal != SciCam.SCI_CAMERA_OK)
                            {
                                Console.WriteLine("Set Grab Strategy fail! nRet {0}", nReVal);
                                break;
                            }
                    
                            break;
                        case 1:
                             Console.WriteLine("Grab using strategy SciCam_GrabStrategy_Latest");
                            // ch:设置采集策略 | en:Set Grab Strategy
                            nReVal = m_currentDev.SetGrabStrategy(SciCam.SciCamGrabStrategy.SciCam_GrabStrategy_Latest);
                            if (nReVal != SciCam.SCI_CAMERA_OK)
                            {
                                Console.WriteLine("Set Grab Strategy fail! nRet {0}", nReVal);
                                break;
                            }
                            break;
                    case 2:
                            Console.WriteLine("Grab using strategy SciCam_GrabStrategy_Upcoming");
                            // ch:设置采集策略 | en:Set Grab Strategy
                            nReVal = m_currentDev.SetGrabStrategy(SciCam.SciCamGrabStrategy.SciCam_GrabStrategy_Upcoming);
                            if (nReVal != SciCam.SCI_CAMERA_OK)
                            {
                                Console.WriteLine("Set Grab Strategy fail! nRet {0}", nReVal);
                                break;
                            }
                            m_hGrabThread = new Thread(UpcomingThread);
                            m_hGrabThread.Start(m_currentDev);
                            break;
                    default:
                            Console.WriteLine("Input error!Use default strategy:SCI_CAMERAGrabStrategy_OneByOne");
                            break;
                      }

               // ch:开始取流 | en:Start grab image
               nReVal = m_currentDev.StartGrabbing();
               if (nReVal != SciCam.SCI_CAMERA_OK)
               {
                   Console.WriteLine("Start Grabbing fail! nRet:{0}", 0);
                   break;
               }
               for (int i = 0; i < 5; i++)
               {
                    // ch:发送软触发命令 | en:Send Trigger Software command
                   nReVal = m_currentDev.SetCommandValueEx(SciCam.SciCamDeviceXmlType.SciCam_DeviceXml_Camera, "TriggerSoftware");
                   if (nReVal != SciCam.SCI_CAMERA_OK)
                    {
                        Console.WriteLine("Send Trigger Software command fail! nRet {0}", nReVal);
                        break;
                    }
                   Thread.Sleep(500);

               }
               while (true)
               {
                   // ch:采集一张图像 | en:Grab One Image
                   nReVal = m_currentDev.Grab(ref payload);
                   if (nReVal != SciCam.SCI_CAMERA_OK)
                   {
                       Console.WriteLine("Get Image fail! nRet {0}", nReVal);
                       break;
                   }
                   // ch:获取图像信息 | en:Get Iamge Attribute
                   nReVal = SciCam.PayloadGetAttribute(payload, ref m_attribute);
                   if (nReVal != SciCam.SCI_CAMERA_OK)
                   {
                       Console.WriteLine("Get Payload Attribute fail! nRet:{0}", nReVal);
                       continue;
                   }
                   else
                   {
                       Console.WriteLine("Get Payload Attribute: Width[{0}], Height[{1}], FrameNum[{2}]",
                            m_attribute.imgAttr.width, m_attribute.imgAttr.height, m_attribute.frameID);
                       m_currentDev.FreePayload(payload);
                   }
                   
                }
                // ch:停止取流 | en:Stop grab image
                nReVal = m_currentDev.StopGrabbing();
                if (nReVal != SciCam.SCI_CAMERA_OK)
                {
                    Console.WriteLine("Stop Grabbing fail! nRet:{0}", nReVal);
                    break;
                }

                // ch:关闭设备 | en:Close device
                nReVal = m_currentDev.CloseDevice();
                if (nReVal != SciCam.SCI_CAMERA_OK)
                {
                    Console.WriteLine("Close Device fail! nRet:{0}", nReVal);
                    break;
                }

                // ch:销毁句柄 | en:Destroy handle
                nReVal = m_currentDev.DeleteDevice();
                if (nReVal != SciCam.SCI_CAMERA_OK)
                {
                    Console.WriteLine("Delete Device fail! nRet:{0}", nReVal);
                    break;
                }



        }while(false);
        Console.WriteLine("Press Any Key to Exit");
        Console.ReadLine();
        }
    }
}

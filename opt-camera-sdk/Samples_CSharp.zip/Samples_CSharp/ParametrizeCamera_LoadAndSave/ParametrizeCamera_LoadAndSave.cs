﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SciCamera.Net;
namespace ParamSaveandLoad
{

     class ParamSaveandLoad
    {
        // ch:打印设备信息 | en:Print Device Info
        static void PrintDeviceInfo(SciCam.SCI_DEVICE_INFO info)
        {
            SciCam.SCI_DEVICE_GIGE_INFO gigeDevInfo = (SciCam.SCI_DEVICE_GIGE_INFO)SciCam.ByteToStruct(info.info.gigeInfo, typeof(SciCam.SCI_DEVICE_GIGE_INFO));
            uint ip = gigeDevInfo.ip;
            int nIp1 = (int)(ip & 0x000000ff);
            int nIp2 = (int)((ip & 0x0000ff00) >> 8);
            int nIp3 = (int)((ip & 0x00ff0000) >> 16);
            int nIp4 = (int)((ip & 0xff000000) >> 24);
            // ch:打印当前相机ip,制造商和序列号 | en:print current ip,ManufactureName,SN 
            Console.WriteLine("CurrentIp: {0}.{1}.{2}.{3}", nIp1, nIp2, nIp3, nIp4);
            Console.WriteLine("Serial Number: {0}", gigeDevInfo.serialNumber);
            Console.WriteLine("UserDefinedName: {0}\n", gigeDevInfo.manufactureName);
        }

        static void Main(string[] args)
        {
            SciCam.SCI_DEVICE_INFO_LIST m_devlist = new SciCam.SCI_DEVICE_INFO_LIST();// ch:设备列表 | en:Device List
            SciCam m_currentDev = new SciCam();// ch:设备对象 | en:Device Object
            do
            {
                // ch:枚举设备 | en:Enum device
                uint nReVal = SciCam.DiscoveryDevices(ref m_devlist, (uint)(SciCam.SciCamTLType.SciCam_TLType_Gige));
                if (nReVal != SciCam.SCI_CAMERA_OK)
                {
                    Console.WriteLine("Enum Device Fail! nRet:{0}", nReVal);
                    break;
                }
                if (m_devlist.count > 0)
                {
                    for (int i = 0; i < m_devlist.count; i++)
                    {
                        Console.WriteLine("Device {0}", i);
                        PrintDeviceInfo(m_devlist.pDevInfo[i]);
                    }
                }
                else
                {
                    Console.WriteLine("Find no Device");
                    break;
                }

                // ch:选择设备并创建句柄 | en:Select device and create handle
                int index = 0;
                Console.WriteLine("Please input index(0-{0}):", m_devlist.count - 1);
                index = Convert.ToInt32(Console.ReadLine());
				if (index >= m_devlist.count )
                {
                    Console.WriteLine("Input error!\n");
                    break;
                }
                nReVal = m_currentDev.CreateDevice(ref m_devlist.pDevInfo[index]);
                if (nReVal != SciCam.SCI_CAMERA_OK)
                {
                    Console.WriteLine("Creat Device Fail! nRet:{0}", nReVal);
                    break;
                }

                // ch:打开设备 | en:Open device
                nReVal = m_currentDev.OpenDevice();
                if (nReVal != SciCam.SCI_CAMERA_OK)
                {
                    Console.WriteLine("Open Device Fail! nRet:{0}", nReVal);
                    break;
                }

                Console.WriteLine("Start export the camera properties to the file");
                Console.WriteLine("Wait......");

                // ch:将相机属性导出到文件中 | en:Export the camera properties to the file
                nReVal = m_currentDev.FeatureSaveEx(SciCam.SciCamDeviceXmlType.SciCam_DeviceXml_Camera,"FeatureFile.xml");
                if (nReVal != SciCam.SCI_CAMERA_OK)
                {
                    Console.WriteLine("Save Feature fail! nRet {0}]", nReVal);
                    break;
                }
                Console.WriteLine("Finish export the camera properties to the file");

                Console.WriteLine("Start import the camera properties from the file");
                Console.WriteLine("Wait......");

                // ch:从文件中导入相机属性 | en:Import the camera properties from the file
                nReVal = m_currentDev.FeatureLoadEx(SciCam.SciCamDeviceXmlType.SciCam_DeviceXml_Camera,"FeatureFile.xml");
                if (nReVal != SciCam.SCI_CAMERA_OK)
                {
                    Console.WriteLine("Load Feature fail! nRet {0}", nReVal);
                    break;
                }
                Console.WriteLine("Finish import the camera properties from the file");

                // ch:关闭设备 | en:Close device
                nReVal = m_currentDev.CloseDevice();
                if (nReVal != SciCam.SCI_CAMERA_OK)
                {
                    Console.WriteLine("Close Device fail! nRet:{0}", nReVal);
                    break;
                }

                // ch:销毁句柄 | en:Destroy handle
                nReVal = m_currentDev.DeleteDevice();
                if (nReVal != SciCam.SCI_CAMERA_OK)
                {
                    Console.WriteLine("Delete Device fail! nRet:{0}", nReVal);
                    break;
                }



            } while (false);
            Console.WriteLine("Press Any Key to Exit");
            Console.ReadLine();

        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.InteropServices;
using System.IO;
using SciCamera.Net;
namespace ConvertPixelType
{
    class ConvertPixelType
    {
        // ch:打印设备信息 | en:Print Device Info
        static void PrintDeviceInfo(SciCam.SCI_DEVICE_INFO info)
        {
            SciCam.SCI_DEVICE_GIGE_INFO gigeDevInfo = (SciCam.SCI_DEVICE_GIGE_INFO)SciCam.ByteToStruct(info.info.gigeInfo, typeof(SciCam.SCI_DEVICE_GIGE_INFO));
            uint ip = gigeDevInfo.ip;
            int nIp1 = (int)(ip & 0x000000ff);
            int nIp2 = (int)((ip & 0x0000ff00) >> 8);
            int nIp3 = (int)((ip & 0x00ff0000) >> 16);
            int nIp4 = (int)((ip & 0xff000000) >> 24);
            // ch:打印当前相机ip,制造商和序列号 | en:print current ip,ManufactureName,SN 
            Console.WriteLine("CurrentIp: {0}.{1}.{2}.{3}", nIp1, nIp2, nIp3, nIp4);
            Console.WriteLine("Serial Number: {0}", gigeDevInfo.serialNumber);
            Console.WriteLine("UserDefinedName: {0}\n", gigeDevInfo.manufactureName);
        }

        // ch:检查是否为彩色 | en:Check if the camera is RGB
        static bool IsColor(SciCam.SciCamPixelType enType)
        {
            switch (enType)
            {
                case SciCam.SciCamPixelType.BayerRG8:
                case SciCam.SciCamPixelType.BGR8:
                case SciCam.SciCamPixelType.YUV422_8:
                case SciCam.SciCamPixelType.YUV422_8_UYVY:
                case SciCam.SciCamPixelType.BayerGB8:
                case SciCam.SciCamPixelType.BayerGB10:
                case SciCam.SciCamPixelType.BayerGB10Packed:
                case SciCam.SciCamPixelType.BayerGB12:
                case SciCam.SciCamPixelType.BayerGB12Packed:
                    return true;
                default:
                    return false;
            }
        }

        // ch:检查是否为黑白 | en:Check if the camera is Mono
        static bool IsMono(SciCam.SciCamPixelType enType)
        {
            switch (enType)
            {
                case SciCam.SciCamPixelType.Mono10:
                case SciCam.SciCamPixelType.Mono10p:
                case SciCam.SciCamPixelType.Mono12:
                case SciCam.SciCamPixelType.Mono12p:
                case SciCam.SciCamPixelType.Mono10Packed:
                case SciCam.SciCamPixelType.Mono12Packed:
                    return true;
                default:
                    return false;
            }
        }

        static void Main(string[] args)
        {
            SciCam.SCI_DEVICE_INFO_LIST m_devlist = new SciCam.SCI_DEVICE_INFO_LIST();// ch:设备列表 | en:Device List
            SciCam m_currentDev = new SciCam();// ch:设备对象 | en:Device Object
            SciCam.SCI_CAM_PAYLOAD_ATTRIBUTE m_attribute = new SciCam.SCI_CAM_PAYLOAD_ATTRIBUTE();
            IntPtr payload = IntPtr.Zero;

            do{
                 // ch:枚举设备 | en:Enum device
                 uint nReVal = SciCam.DiscoveryDevices(ref m_devlist, (uint)(SciCam.SciCamTLType.SciCam_TLType_Gige));
                 if (nReVal != SciCam.SCI_CAMERA_OK)
                {
                    Console.WriteLine("Enum Device Fail! nRet:{0}", nReVal);
                    break;
                }
                if (m_devlist.count > 0)
                {
                    for (int i = 0; i < m_devlist.count; i++)
                    {
                        Console.WriteLine("Device {0}", i);
                        PrintDeviceInfo(m_devlist.pDevInfo[i]);
                    }
                }
                else
                {
                    Console.WriteLine("Find no Device");
                    break;
                }

                // ch:选择设备并创建句柄 | en:Select device and create handle
                int index = 0;
                Console.WriteLine("Please input index(0-{0}):", m_devlist.count - 1);
                index = Convert.ToInt32(Console.ReadLine());
				if (index >= m_devlist.count )
                {
                    Console.WriteLine("Input error!\n");
                    break;
                }
                nReVal = m_currentDev.CreateDevice(ref m_devlist.pDevInfo[index]);
                if (nReVal != SciCam.SCI_CAMERA_OK)
                {
                    Console.WriteLine("Creat Device Fail! nRet:{0}", nReVal);
                    break;
                }

                // ch:打开设备 | en:Open device
                nReVal = m_currentDev.OpenDevice();
                if (nReVal != SciCam.SCI_CAMERA_OK)
                {
                    Console.WriteLine("Open Device Fail! nRet:{0}", nReVal);
                    break;
                }

                // ch:设置触发模式为off | en:Set trigger mode as off
                nReVal = m_currentDev.SetEnumValueByStringEx(SciCam.SciCamDeviceXmlType.SciCam_DeviceXml_Camera,"TriggerMode", "Off");
                if (nReVal != SciCam.SCI_CAMERA_OK)
                {
                    Console.WriteLine("Stop Grabbing fail! nRet:{0}", nReVal);
                    break;
                }

                // ch:开始取流 | en:Start grab image
                nReVal = m_currentDev.StartGrabbing();
                if (nReVal != SciCam.SCI_CAMERA_OK)
                {
                    Console.WriteLine("Start Grabbing fail! nRet:{0}", 0);
                    break;
                }

                // ch:采集一帧图像 | en: Grab One Image
                nReVal = m_currentDev.Grab(ref payload);
                if (nReVal != SciCam.SCI_CAMERA_OK)
                {
                    Console.WriteLine("Get payload fail! nRet:{0}", 0);
                    break;
                }

                // ch:获取payload属性 | en:Get PayloadAttribute
                nReVal = SciCam.PayloadGetAttribute(payload, ref m_attribute);
                if (nReVal != SciCam.SCI_CAMERA_OK)
                {
                    Console.WriteLine("Get payload Attribute fail! nRet:{0}", 0);
                    break;
                }
                else
                {
                    Console.WriteLine("Get One Frame: width{0}, height{1}, frameID{2}", m_attribute.imgAttr.width, m_attribute.imgAttr.height, m_attribute.frameID);
                    // ch:判断是否为2D相机以及帧完整性 | en:Determine if it is a 2D camera and isComplete
                    if (m_attribute.payloadMode != SciCam.SciCamPayloadMode.SciCam_PayloadMode_2D | !m_attribute.isComplete)
                    {
                        Console.WriteLine("The Camera payloadMode is not 2D or The frame is not complete");
                        break;
                    }
                    // ch:获取图像数据 | en: Get image data
                    IntPtr m_imgdata = IntPtr.Zero;
                    nReVal = SciCam.PayloadGetImage(payload, ref m_imgdata);
                    string filename = "";
                    // ch:判断图像格式 | en:Determine whether chunkdata is included
                    SciCam.SciCamPixelType pixeltype = SciCam.SciCamPixelType.PixelTypeUnknown;
                    if (IsColor(m_attribute.imgAttr.pixelType))
                    {
                        pixeltype = SciCam.SciCamPixelType.RGB8;
                        filename = "AfterConvertRGB8.raw";
                    }
                    else if (IsMono(m_attribute.imgAttr.pixelType))
                    {
                        pixeltype = SciCam.SciCamPixelType.Mono8;
                        filename = "AfterConvertMono8.raw";
                    }
                    else
                    {
                        Console.WriteLine("Don't need to convert!");
                    }
                    if (pixeltype != SciCam.SciCamPixelType.PixelTypeUnknown)
                    {
                        long dstImgSize = 0;
                        IntPtr destImg = IntPtr.Zero;
                        // ch:获取目标图像数据大小 | en:Get the target image data size
                        nReVal = SciCam.PayloadConvertImageEx(ref m_attribute.imgAttr, m_imgdata, pixeltype, IntPtr.Zero, ref dstImgSize, true,0);
                        if (nReVal != SciCam.SCI_CAMERA_OK)
                        {
                            Console.WriteLine("Convert Pixel Type fail! nRet {0}", nReVal);
                            break;
                        }
                        // ch:将图像转为目标格式| en:Convert Image Format to Target Pixelformat
                        byte[] pDstData = new byte[dstImgSize];
                        destImg = Marshal.AllocHGlobal((int)dstImgSize);
                        nReVal = SciCam.PayloadConvertImageEx(ref m_attribute.imgAttr, m_imgdata, pixeltype, destImg, ref dstImgSize, true,0);
                        Marshal.Copy(destImg, pDstData, 0, (int)dstImgSize);
                        BinaryWriter fs = new BinaryWriter(new FileStream(filename, FileMode.Create));

                        fs.Write(pDstData, 0, (int)dstImgSize);
                        fs.Close();
                        Console.WriteLine("Convert pixeltype succeed");
                       
                        if (destImg != IntPtr.Zero)
                        {
                            Marshal.FreeHGlobal(destImg);
                        }
                    }

                }

                // ch:停止取流 | en:Stop grab image
                nReVal = m_currentDev.StopGrabbing();
                if (nReVal != SciCam.SCI_CAMERA_OK)
                {
                    Console.WriteLine("Stop Grabbing fail! nRet:{0}", nReVal);
                    break;
                }

                // ch:关闭设备 | en:Close device
                nReVal = m_currentDev.CloseDevice();
                if (nReVal != SciCam.SCI_CAMERA_OK)
                {
                    Console.WriteLine("Close Device fail! nRet:{0}", nReVal);
                    break;
                }

                // ch:销毁句柄 | en:Destroy handle
                nReVal = m_currentDev.DeleteDevice();
                if (nReVal != SciCam.SCI_CAMERA_OK)
                {
                    Console.WriteLine("Delete Device fail! nRet:{0}", nReVal);
                    break;
                }



        }while(false);
        Console.WriteLine("Press Any Key to Exit");
        Console.ReadLine();
        }
    }
}

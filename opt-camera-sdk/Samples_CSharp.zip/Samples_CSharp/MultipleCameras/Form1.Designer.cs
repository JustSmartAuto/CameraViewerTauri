﻿namespace MultipleCamera
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox_init = new System.Windows.Forms.GroupBox();
            this.btn_close = new System.Windows.Forms.Button();
            this.btn_open = new System.Windows.Forms.Button();
            this.btn_enum = new System.Windows.Forms.Button();
            this.groupBox_grabImg = new System.Windows.Forms.GroupBox();
            this.btn_excute = new System.Windows.Forms.Button();
            this.btn_saveimg = new System.Windows.Forms.Button();
            this.btn_software = new System.Windows.Forms.Button();
            this.btn_trigger = new System.Windows.Forms.Button();
            this.btn_stopGrabbing = new System.Windows.Forms.Button();
            this.btn_startGrabbing = new System.Windows.Forms.Button();
            this.rbn_triggerMode = new System.Windows.Forms.RadioButton();
            this.rbn_continusMode = new System.Windows.Forms.RadioButton();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.checkBox9 = new System.Windows.Forms.CheckBox();
            this.pictureBox9 = new System.Windows.Forms.PictureBox();
            this.checkBox8 = new System.Windows.Forms.CheckBox();
            this.pictureBox8 = new System.Windows.Forms.PictureBox();
            this.checkBox7 = new System.Windows.Forms.CheckBox();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.checkBox6 = new System.Windows.Forms.CheckBox();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.checkBox5 = new System.Windows.Forms.CheckBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.checkBox4 = new System.Windows.Forms.CheckBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.checkBox3 = new System.Windows.Forms.CheckBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.checkBox2 = new System.Windows.Forms.CheckBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.groupBox_init.SuspendLayout();
            this.groupBox_grabImg.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox_init
            // 
            this.groupBox_init.Controls.Add(this.btn_close);
            this.groupBox_init.Controls.Add(this.btn_open);
            this.groupBox_init.Controls.Add(this.btn_enum);
            this.groupBox_init.Location = new System.Drawing.Point(761, 43);
            this.groupBox_init.Name = "groupBox_init";
            this.groupBox_init.Size = new System.Drawing.Size(199, 117);
            this.groupBox_init.TabIndex = 1;
            this.groupBox_init.TabStop = false;
            this.groupBox_init.Text = "相机初始化设置";
            // 
            // btn_close
            // 
            this.btn_close.Location = new System.Drawing.Point(99, 20);
            this.btn_close.Name = "btn_close";
            this.btn_close.Size = new System.Drawing.Size(87, 38);
            this.btn_close.TabIndex = 2;
            this.btn_close.Text = "关闭设备";
            this.btn_close.UseVisualStyleBackColor = true;
            this.btn_close.Click += new System.EventHandler(this.btn_close_Click);
            // 
            // btn_open
            // 
            this.btn_open.Location = new System.Drawing.Point(6, 20);
            this.btn_open.Name = "btn_open";
            this.btn_open.Size = new System.Drawing.Size(87, 38);
            this.btn_open.TabIndex = 1;
            this.btn_open.Text = "打开设备";
            this.btn_open.UseVisualStyleBackColor = true;
            this.btn_open.Click += new System.EventHandler(this.btn_open_Click);
            // 
            // btn_enum
            // 
            this.btn_enum.Location = new System.Drawing.Point(99, 64);
            this.btn_enum.Name = "btn_enum";
            this.btn_enum.Size = new System.Drawing.Size(87, 38);
            this.btn_enum.TabIndex = 0;
            this.btn_enum.Text = "重新枚举";
            this.btn_enum.UseVisualStyleBackColor = true;
            this.btn_enum.Click += new System.EventHandler(this.btn_enum_Click);
            // 
            // groupBox_grabImg
            // 
            this.groupBox_grabImg.Controls.Add(this.btn_excute);
            this.groupBox_grabImg.Controls.Add(this.btn_saveimg);
            this.groupBox_grabImg.Controls.Add(this.btn_software);
            this.groupBox_grabImg.Controls.Add(this.btn_trigger);
            this.groupBox_grabImg.Controls.Add(this.btn_stopGrabbing);
            this.groupBox_grabImg.Controls.Add(this.btn_startGrabbing);
            this.groupBox_grabImg.Controls.Add(this.rbn_triggerMode);
            this.groupBox_grabImg.Controls.Add(this.rbn_continusMode);
            this.groupBox_grabImg.Location = new System.Drawing.Point(761, 172);
            this.groupBox_grabImg.Name = "groupBox_grabImg";
            this.groupBox_grabImg.Size = new System.Drawing.Size(208, 216);
            this.groupBox_grabImg.TabIndex = 3;
            this.groupBox_grabImg.TabStop = false;
            this.groupBox_grabImg.Text = "图像采集";
            // 
            // btn_excute
            // 
            this.btn_excute.Location = new System.Drawing.Point(114, 160);
            this.btn_excute.Name = "btn_excute";
            this.btn_excute.Size = new System.Drawing.Size(87, 38);
            this.btn_excute.TabIndex = 10;
            this.btn_excute.Text = "软触发一次";
            this.btn_excute.UseVisualStyleBackColor = true;
            this.btn_excute.Click += new System.EventHandler(this.btn_excute_Click);
            // 
            // btn_saveimg
            // 
            this.btn_saveimg.Location = new System.Drawing.Point(9, 160);
            this.btn_saveimg.Name = "btn_saveimg";
            this.btn_saveimg.Size = new System.Drawing.Size(87, 38);
            this.btn_saveimg.TabIndex = 9;
            this.btn_saveimg.Text = "保存图片";
            this.btn_saveimg.UseVisualStyleBackColor = true;
            this.btn_saveimg.Click += new System.EventHandler(this.btn_saveimg_Click);
            // 
            // btn_software
            // 
            this.btn_software.Location = new System.Drawing.Point(114, 105);
            this.btn_software.Name = "btn_software";
            this.btn_software.Size = new System.Drawing.Size(87, 38);
            this.btn_software.TabIndex = 8;
            this.btn_software.Text = "软触发";
            this.btn_software.UseVisualStyleBackColor = true;
            this.btn_software.Click += new System.EventHandler(this.btn_software_Click);
            // 
            // btn_trigger
            // 
            this.btn_trigger.Location = new System.Drawing.Point(9, 105);
            this.btn_trigger.Name = "btn_trigger";
            this.btn_trigger.Size = new System.Drawing.Size(87, 38);
            this.btn_trigger.TabIndex = 7;
            this.btn_trigger.Text = "硬触发";
            this.btn_trigger.UseVisualStyleBackColor = true;
            this.btn_trigger.Click += new System.EventHandler(this.btn_trigger_Click);
            // 
            // btn_stopGrabbing
            // 
            this.btn_stopGrabbing.Location = new System.Drawing.Point(114, 46);
            this.btn_stopGrabbing.Name = "btn_stopGrabbing";
            this.btn_stopGrabbing.Size = new System.Drawing.Size(87, 38);
            this.btn_stopGrabbing.TabIndex = 5;
            this.btn_stopGrabbing.Text = "停止采集";
            this.btn_stopGrabbing.UseVisualStyleBackColor = true;
            this.btn_stopGrabbing.Click += new System.EventHandler(this.btn_stopGrabbing_Click);
            // 
            // btn_startGrabbing
            // 
            this.btn_startGrabbing.Location = new System.Drawing.Point(9, 46);
            this.btn_startGrabbing.Name = "btn_startGrabbing";
            this.btn_startGrabbing.Size = new System.Drawing.Size(87, 38);
            this.btn_startGrabbing.TabIndex = 4;
            this.btn_startGrabbing.Text = "开始采集";
            this.btn_startGrabbing.UseVisualStyleBackColor = true;
            this.btn_startGrabbing.Click += new System.EventHandler(this.btn_startGrabbing_Click);
            // 
            // rbn_triggerMode
            // 
            this.rbn_triggerMode.AutoSize = true;
            this.rbn_triggerMode.Location = new System.Drawing.Point(108, 24);
            this.rbn_triggerMode.Name = "rbn_triggerMode";
            this.rbn_triggerMode.Size = new System.Drawing.Size(71, 16);
            this.rbn_triggerMode.TabIndex = 3;
            this.rbn_triggerMode.TabStop = true;
            this.rbn_triggerMode.Text = "触发模式";
            this.rbn_triggerMode.UseVisualStyleBackColor = true;
            this.rbn_triggerMode.Click += new System.EventHandler(this.rbn_triggerMode_CheckedChanged);
            // 
            // rbn_continusMode
            // 
            this.rbn_continusMode.AutoSize = true;
            this.rbn_continusMode.Location = new System.Drawing.Point(15, 24);
            this.rbn_continusMode.Name = "rbn_continusMode";
            this.rbn_continusMode.Size = new System.Drawing.Size(71, 16);
            this.rbn_continusMode.TabIndex = 2;
            this.rbn_continusMode.TabStop = true;
            this.rbn_continusMode.Text = "连续模式";
            this.rbn_continusMode.UseVisualStyleBackColor = true;
            this.rbn_continusMode.Click += new System.EventHandler(this.rbn_continusMode_CheckedChanged);
            // 
            // textBox1
            // 
            this.textBox1.AllowDrop = true;
            this.textBox1.Location = new System.Drawing.Point(14, 593);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textBox1.Size = new System.Drawing.Size(741, 132);
            this.textBox1.TabIndex = 33;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.checkBox9);
            this.groupBox1.Controls.Add(this.pictureBox9);
            this.groupBox1.Controls.Add(this.checkBox8);
            this.groupBox1.Controls.Add(this.pictureBox8);
            this.groupBox1.Controls.Add(this.checkBox7);
            this.groupBox1.Controls.Add(this.pictureBox7);
            this.groupBox1.Controls.Add(this.checkBox6);
            this.groupBox1.Controls.Add(this.pictureBox6);
            this.groupBox1.Controls.Add(this.checkBox5);
            this.groupBox1.Controls.Add(this.pictureBox5);
            this.groupBox1.Controls.Add(this.checkBox4);
            this.groupBox1.Controls.Add(this.pictureBox4);
            this.groupBox1.Controls.Add(this.checkBox3);
            this.groupBox1.Controls.Add(this.pictureBox3);
            this.groupBox1.Controls.Add(this.checkBox2);
            this.groupBox1.Controls.Add(this.pictureBox2);
            this.groupBox1.Controls.Add(this.checkBox1);
            this.groupBox1.Controls.Add(this.pictureBox1);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(743, 575);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            // 
            // checkBox9
            // 
            this.checkBox9.AutoSize = true;
            this.checkBox9.Location = new System.Drawing.Point(510, 386);
            this.checkBox9.Name = "checkBox9";
            this.checkBox9.Size = new System.Drawing.Size(48, 16);
            this.checkBox9.TabIndex = 58;
            this.checkBox9.Text = "Cam9";
            this.checkBox9.UseVisualStyleBackColor = true;
            // 
            // pictureBox9
            // 
            this.pictureBox9.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.pictureBox9.Location = new System.Drawing.Point(510, 408);
            this.pictureBox9.Name = "pictureBox9";
            this.pictureBox9.Size = new System.Drawing.Size(227, 145);
            this.pictureBox9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox9.TabIndex = 57;
            this.pictureBox9.TabStop = false;
            this.pictureBox9.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.Form1_MouseDoubleClick_1);
            // 
            // checkBox8
            // 
            this.checkBox8.AutoSize = true;
            this.checkBox8.Location = new System.Drawing.Point(260, 386);
            this.checkBox8.Name = "checkBox8";
            this.checkBox8.Size = new System.Drawing.Size(48, 16);
            this.checkBox8.TabIndex = 55;
            this.checkBox8.Text = "Cam8";
            this.checkBox8.UseVisualStyleBackColor = true;
            // 
            // pictureBox8
            // 
            this.pictureBox8.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.pictureBox8.Location = new System.Drawing.Point(258, 408);
            this.pictureBox8.Name = "pictureBox8";
            this.pictureBox8.Size = new System.Drawing.Size(227, 145);
            this.pictureBox8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox8.TabIndex = 54;
            this.pictureBox8.TabStop = false;
            this.pictureBox8.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.Form1_MouseDoubleClick_1);
            // 
            // checkBox7
            // 
            this.checkBox7.AutoSize = true;
            this.checkBox7.Location = new System.Drawing.Point(0, 386);
            this.checkBox7.Name = "checkBox7";
            this.checkBox7.Size = new System.Drawing.Size(48, 16);
            this.checkBox7.TabIndex = 52;
            this.checkBox7.Text = "Cam7";
            this.checkBox7.UseVisualStyleBackColor = true;
            // 
            // pictureBox7
            // 
            this.pictureBox7.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.pictureBox7.Location = new System.Drawing.Point(-2, 408);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(227, 145);
            this.pictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox7.TabIndex = 51;
            this.pictureBox7.TabStop = false;
            this.pictureBox7.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.Form1_MouseDoubleClick_1);
            // 
            // checkBox6
            // 
            this.checkBox6.AutoSize = true;
            this.checkBox6.Location = new System.Drawing.Point(510, 194);
            this.checkBox6.Name = "checkBox6";
            this.checkBox6.Size = new System.Drawing.Size(48, 16);
            this.checkBox6.TabIndex = 49;
            this.checkBox6.Text = "Cam6";
            this.checkBox6.UseVisualStyleBackColor = true;
            // 
            // pictureBox6
            // 
            this.pictureBox6.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.pictureBox6.Location = new System.Drawing.Point(508, 216);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(227, 145);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox6.TabIndex = 48;
            this.pictureBox6.TabStop = false;
            this.pictureBox6.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.Form1_MouseDoubleClick_1);
            // 
            // checkBox5
            // 
            this.checkBox5.AutoSize = true;
            this.checkBox5.Location = new System.Drawing.Point(260, 194);
            this.checkBox5.Name = "checkBox5";
            this.checkBox5.Size = new System.Drawing.Size(48, 16);
            this.checkBox5.TabIndex = 46;
            this.checkBox5.Text = "Cam5";
            this.checkBox5.UseVisualStyleBackColor = true;
            // 
            // pictureBox5
            // 
            this.pictureBox5.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.pictureBox5.Location = new System.Drawing.Point(258, 216);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(227, 145);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox5.TabIndex = 45;
            this.pictureBox5.TabStop = false;
            this.pictureBox5.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.Form1_MouseDoubleClick_1);
            // 
            // checkBox4
            // 
            this.checkBox4.AutoSize = true;
            this.checkBox4.Location = new System.Drawing.Point(0, 194);
            this.checkBox4.Name = "checkBox4";
            this.checkBox4.Size = new System.Drawing.Size(48, 16);
            this.checkBox4.TabIndex = 43;
            this.checkBox4.Text = "Cam4";
            this.checkBox4.UseVisualStyleBackColor = true;
            // 
            // pictureBox4
            // 
            this.pictureBox4.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.pictureBox4.Location = new System.Drawing.Point(-2, 216);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(227, 145);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox4.TabIndex = 42;
            this.pictureBox4.TabStop = false;
            this.pictureBox4.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.Form1_MouseDoubleClick_1);
            // 
            // checkBox3
            // 
            this.checkBox3.AutoSize = true;
            this.checkBox3.Location = new System.Drawing.Point(510, 7);
            this.checkBox3.Name = "checkBox3";
            this.checkBox3.Size = new System.Drawing.Size(48, 16);
            this.checkBox3.TabIndex = 40;
            this.checkBox3.Text = "Cam3";
            this.checkBox3.UseVisualStyleBackColor = true;
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.pictureBox3.Location = new System.Drawing.Point(508, 26);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(227, 145);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 39;
            this.pictureBox3.TabStop = false;
            this.pictureBox3.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.Form1_MouseDoubleClick_1);
            // 
            // checkBox2
            // 
            this.checkBox2.AutoSize = true;
            this.checkBox2.Location = new System.Drawing.Point(260, 7);
            this.checkBox2.Name = "checkBox2";
            this.checkBox2.Size = new System.Drawing.Size(48, 16);
            this.checkBox2.TabIndex = 37;
            this.checkBox2.Text = "Cam2";
            this.checkBox2.UseVisualStyleBackColor = true;
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.pictureBox2.Location = new System.Drawing.Point(258, 26);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(227, 145);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 36;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.Form1_MouseDoubleClick_1);
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Location = new System.Drawing.Point(0, 7);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(48, 16);
            this.checkBox1.TabIndex = 34;
            this.checkBox1.Text = "Cam1";
            this.checkBox1.UseVisualStyleBackColor = true;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.pictureBox1.Location = new System.Drawing.Point(2, 26);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(227, 145);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 33;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.Form1_MouseDoubleClick_1);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(978, 737);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.groupBox_grabImg);
            this.Controls.Add(this.groupBox_init);
            this.Name = "Form1";
            this.Text = "MultipleCameras CS演示程序";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Form1_FormClosed);
            this.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.Form1_MouseDoubleClick_1);
            this.groupBox_init.ResumeLayout(false);
            this.groupBox_grabImg.ResumeLayout(false);
            this.groupBox_grabImg.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.GroupBox groupBox_init;
        private System.Windows.Forms.Button btn_enum;
        private System.Windows.Forms.Button btn_close;
        private System.Windows.Forms.Button btn_open;
        private System.Windows.Forms.GroupBox groupBox_grabImg;
        private System.Windows.Forms.Button btn_trigger;
        private System.Windows.Forms.Button btn_stopGrabbing;
        private System.Windows.Forms.Button btn_startGrabbing;
        private System.Windows.Forms.RadioButton rbn_triggerMode;
        private System.Windows.Forms.RadioButton rbn_continusMode;
        private System.Windows.Forms.Button btn_excute;
        private System.Windows.Forms.Button btn_saveimg;
        private System.Windows.Forms.Button btn_software;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.CheckBox checkBox9;
        private System.Windows.Forms.PictureBox pictureBox9;
        private System.Windows.Forms.CheckBox checkBox8;
        private System.Windows.Forms.PictureBox pictureBox8;
        private System.Windows.Forms.CheckBox checkBox7;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.CheckBox checkBox6;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.CheckBox checkBox5;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.CheckBox checkBox4;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.CheckBox checkBox3;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.CheckBox checkBox2;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}


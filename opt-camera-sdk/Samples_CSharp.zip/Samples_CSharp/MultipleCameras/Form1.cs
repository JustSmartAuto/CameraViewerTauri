﻿using System;
using System.Collections.Generic;

using System.Drawing;
using System.Linq;

using System.Threading;
using System.Runtime.InteropServices;
using GdiPlus = System.Drawing.Imaging;
using System.Windows.Forms;

using SciCamera.Net;



namespace MultipleCamera
{
    public partial class Form1 : Form
    {
        SciCam.SCI_DEVICE_INFO_LIST m_stDevList = new SciCam.SCI_DEVICE_INFO_LIST();    //ch:设备列表 | en:Device List
        List<SciCam> m_currentDevArr = new List<SciCam>{new SciCam(),
        new SciCam(),new SciCam(),new SciCam(), new SciCam(), new SciCam(), new SciCam(), new SciCam(), new SciCam()};    //ch:相机对象数组 | en:Camera Object Array
        uint m_nValidCamNum = 0;  //ch:在线相机数量 | en: Online Camera Number
        int m_nZoomInIndex = -1;    //ch:当前缩放相机下标 | en: Current Scale Camera Index
        Boolean m_bDeviceReady = false;         //ch:是否存在相机 | en: The presence or absence of a camera
        bool m_bOpenDevice = false; // ch:相机是否打开 | en: Camera IsOpened
        bool[] m_bCamCheck = new bool[9]; //ch:是否勾选相机 | en: Camera Selection Status
        bool m_bStartGrabbing = false; //ch:开始采集状态 | en:The Grab Status
        bool m_nTriggerMode = false;    //ch:触发模式状态 | en: Trigger Mode Status
        bool m_IsSoftWare = false;      //ch:是否为软件触发 | en: Software Trigger Status
        bool[] m_isSaveImg = new bool[9];   //ch:相机图像保存状态 | en: Image Saving Status for Each Camera
        Thread[] m_hGrabThread = new Thread[9]; //ch:相机采集线程数组 | en: Camera Grabbing Thread Array
        Point m_point;                  //ch:原窗口坐标点 | en: Original PictureBox Coordinate Point
        Size m_size;                   //ch:原窗口尺寸大小 | en: Original PictureBox Size Dimension
        Mutex[] mutexarr = new Mutex[9];    //ch:相机操作互斥锁数组 | en: Mutex Array for Camera Operations

        public Form1()
        {
            InitializeComponent();
            btn_enum_Click(btn_enum, EventArgs.Empty);
            RefreshWindow();
            Control.CheckForIllegalCrossThreadCalls = false;
            for (int i = 0; i < mutexarr.Length; i++)
            {
                mutexarr[i] = new Mutex();
            }
        }

        //ch:显示错误信息 | en:Show Error Message
        private void ShowMsg(string msg, uint nErrorNum, int index, bool iscontact)
        {
            string errorMsg = "";
            if (iscontact)
            {
                if (nErrorNum == 0)
                {
                    errorMsg = msg;
                }
                else
                {

                    errorMsg = msg + ": Error code = " + string.Format("{0}", nErrorNum);

                    if (index != -1)
                    {
                        errorMsg = errorMsg + "DecIndex: " + string.Format("{0}", index) + " :";

                    }

                }

                switch (nErrorNum)
                {
                    case SciCam.SCI_CAMERA_OK: errorMsg += " Success."; break;
                    case SciCam.SCI_ERR_CAMERA_INCORRECT_INIT_OBJECT: errorMsg += " Incorrect initialization object."; break;
                    case SciCam.SCI_ERR_CAMERA_PARAM_INVALID: errorMsg += " Parameter is invalid."; break;
                    case SciCam.SCI_ERR_CAMERA_SDK_VERSION_MISMATCH: errorMsg += " SDK version mismatch."; break;
                    case SciCam.SCI_ERR_CAMERA_UNKNOW: errorMsg += " Unknow error."; break;
                    case SciCam.SCI_ERR_CAMERA_FUNCTION_CONFLICT: errorMsg += " Function or interface call conflict."; break;
                    case SciCam.SCI_ERR_CAMERA_ENUM_DEVICES_FAILED: errorMsg += " Failed to search camera."; break;
                    case SciCam.SCI_ERR_CAMERA_MODIFY_IP_ADDRESS_FAILED: errorMsg += " Failed to modify camera ip address."; break;
                    case SciCam.SCI_ERR_CAMERA_SET_PERSISTENT_IP_FAILED: errorMsg += " Failed to modify persistent camera ip address."; break;
                    case SciCam.SCI_ERR_CAMERA_CREATE_FAILED: errorMsg += " Failed to create a camera object."; break;
                    case SciCam.SCI_ERR_CAMERA_EXCEPTION: errorMsg += " Camera operation exception."; break;
                    case SciCam.SCI_ERR_CAMERA_NOT_FOUND: errorMsg += " Cannot to find camera."; break;
                    case SciCam.SCI_ERR_CAMERA_OFFLINE: errorMsg += " Camera is offline."; break;
                    case SciCam.SCI_ERR_CAMERA_OPEN_FAILED: errorMsg += " Failed to open camera."; break;
                    case SciCam.SCI_ERR_CAMERA_NOT_MISMATCHACQ: errorMsg += " Camera mismatch witch ACQ."; break;
                    case SciCam.SCI_ERR_CAMERA_NOT_SUPPORT: errorMsg += " Camera does not support."; break;
                    case SciCam.SCI_ERR_CAMERA_NOT_OPEN: errorMsg += " Camera isn't open."; break;
                    case SciCam.SCI_ERR_CAMERA_ALLREADY_OPEN: errorMsg += " Camera allready open."; break;
                    case SciCam.SCI_ERR_CAMERA_OCCUPANCY: errorMsg += " Camera occupied by another device."; break;
                    case SciCam.SCI_ERR_CAMERA_ROMOVED: errorMsg += " The camera was removed."; break;
                    case SciCam.SCI_ERR_CAMERA_START_GRAB_FAILED: errorMsg += " Failed to start grab."; break;
                    case SciCam.SCI_ERR_CAMERA_NOT_GRABBING: errorMsg += " Camera isn't grabbing."; break;
                    case SciCam.SCI_ERR_CAMERA_ALREADY_GRABBING: errorMsg += " Camera is grabbing."; break;
                    case SciCam.SCI_ERR_CAMERA_GRAB_FAILED: errorMsg += " Camera grab failed."; break;
                    case SciCam.SCI_ERR_CAMERA_GRAB_TIMEOUT: errorMsg += " Grab image timeout."; break;
                    case SciCam.SCI_ERR_CAMERA_TRIGGER_WAIT_FAILED: errorMsg += " Wait for trigger failed."; break;
                    case SciCam.SCI_ERR_CAMERA_SOFTWARE_TRIGGER_FAILED: errorMsg += " Failed to set software trigger."; break;
                    case SciCam.SCI_ERR_CAMERA_GRAB_EXCEPTION: errorMsg += " Camera grab image exception."; break;
                    case SciCam.SCI_ERR_CAMERA_GRAB_INTERRUPTED: errorMsg += " Capture interrupted."; break;
                    case SciCam.SCI_ERR_CAMERA_GRAB_INSUFFICIENT_BUFFER: errorMsg += " Insufficient buffer for capture."; break;
                    case SciCam.SCI_ERR_CAMERA_SET_VALUE_FAILED: errorMsg += " Failed to set parameter value."; break;
                    case SciCam.SCI_ERR_CAMERA_GET_VALUE_FAILED: errorMsg += " Failed to Get parameter value."; break;
                    case SciCam.SCI_ERR_CAMERA_SEND_CMD_FAILED: errorMsg += " Failed to send command."; break;
                    case SciCam.SCI_ERR_CAMERA_WRONG_ACK: errorMsg += " Get ACK failed, maybe result of wrong IP."; break;
                    case SciCam.SCI_ERR_CAMERA_FILE_OPEN_FAILED: errorMsg += " Open camera configuration file error."; break;
                    case SciCam.SCI_ERR_CAMERA_NODE_XML_TYPE: errorMsg += " XML type error."; break;
                    case SciCam.SCI_ERR_CAMERA_NODE_NAME_INVALID: errorMsg += " Node name is invalid."; break;
                    case SciCam.SCI_ERR_CAMERA_NODE_READ_FORBIDDEN: errorMsg += " Node is forbidden to read."; break;
                    case SciCam.SCI_ERR_CAMERA_NODE_WRITE_FORBIDDEN: errorMsg += " Node is forbidden to write."; break;
                    case SciCam.SCI_ERR_CAMERA_NODE_TYPE_INVALID: errorMsg += " Node type is invalid."; break;
                    case SciCam.SCI_ERR_CAMERA_NODE_TYPE_UNMATCH: errorMsg += " Node type is unmatched."; break;
                    case SciCam.SCI_ERR_CAMERA_NODE_VALUE: errorMsg += " The value of node is wrong."; break;
                    case SciCam.SCI_ERR_CAMERA_NODE_MAP_INVALID: errorMsg += " Failed to access the node map."; break;
                    case SciCam.SCI_ERR_CAMERA_NODE_GET_ROOT_NODE_FAILED: errorMsg += " Failed to get root node."; break;
                    case SciCam.SCI_ERR_CAMERA_NODE_TRAVERSE: errorMsg += " Failed to traverse nodes."; break;
                    case SciCam.SCI_ERR_CAMERA_IMAGE_INVALID: errorMsg += " Image data is invalid."; break;
                    case SciCam.SCI_ERR_CAMERA_IMAGE_CREATE_FAILED: errorMsg += " Failed to create image file."; break;
                    case SciCam.SCI_ERR_CAMERA_IMAGE_TYPE_NOT_SUPPORT: errorMsg += " Image type does not support."; break;
                    case SciCam.SCI_ERR_CAMERA_IMAGE_NOT_COMPLETE: errorMsg += " Grab Image not complete."; break;
                    case SciCam.SCI_ERR_CAMERA_IMAGE_DATACONVERT_FAILED: errorMsg += " Failed to convert to image."; break;
                    case SciCam.SCI_ERR_CAMERA_IMAGE_FORMAT: errorMsg += " Image format is wrong."; break;
                    case SciCam.SCI_ERR_CAMERA_IMAGE_GET_PROPERTY: errorMsg += " Failed to get image properties (e.g., width, height)."; break;
                    case SciCam.SCI_ERR_CAMERA_IMAGE_OUT_OF_BOUNDS: errorMsg += " Image data out of bounds."; break;
                    case SciCam.SCI_ERR_CAMERA_CHUNKDATA_EMPTY: errorMsg += " Chunk data is empty."; break;
                    case SciCam.SCI_ERR_CAMERA_CHUNKDATA_LENGTH: errorMsg += " Chunk data length is abnormal."; break;
                    case SciCam.SCI_ERR_CAMERA_CHUNKDATA_PARSING_EXCEPTION: errorMsg += " Chunk parsing exception."; break;
                    case SciCam.SCI_ERR_CAMERA_MEMORY_ALLOCATION_FAILED: errorMsg += " Memory allocation failed."; break;
                    case SciCam.SCI_ERR_CAMERA_APPEND_BUFFER_FAILED: errorMsg += " Failed to append buffer."; break;
                    case SciCam.SCI_ERR_CAMERA_SYSTEM_RESOURCE_EXHAUSTED: errorMsg += " System resource exhausted."; break;
                    case SciCam.SCI_ERR_CAMERA_INSUFFICIENT_MEMORY_LENGTH: errorMsg += " Insufficient memory length at the target address."; break;
                    case SciCam.SCI_ERR_CAMERA_GET_CTI_OBJECT_NULL: errorMsg += " Failed to get CTI object."; break;
                    case SciCam.SCI_ERR_CAMERA_GET_ANY_PORT_FAILED: errorMsg += " Failed to get any port (card port, data stream port, or device port) is null."; break;
                    case SciCam.SCI_ERR_CAMERA_GET_IF_PORT_FAILED: errorMsg += " Failed to get IF port."; break;
                    case SciCam.SCI_ERR_CAMERA_GET_DEVICE_PORT_FAILED: errorMsg += " Failed to get device port."; break;
                    case SciCam.SCI_ERR_CAMERA_GET_DEVICE_DATA_STREAM_PORT_FAILED: errorMsg += " Failed to get device data stream port."; break;
                    case SciCam.SCI_ERR_CAMERA_GET_DEVICE_DATA_STREAM_FAILED: errorMsg += " Failed to get device data stream."; break;
                    case SciCam.SCI_ERR_CAMERA_GET_DEVICE_DATA_STREAM_COUNT_ZERO: errorMsg += " Device data stream count is zero."; break;
                    case SciCam.SCI_ERR_CAMERA_GET_DATA_STREAM_ID_FAILED: errorMsg += " Failed to get device data stream ID."; break;
                    case SciCam.SCI_ERR_CAMERA_OPEN_DATA_STREAM_FAILED: errorMsg += " Failed to open data stream."; break;
                    case SciCam.SCI_ERR_CAMERA_NODEMAP_NULL: errorMsg += " Device nodemap is null."; break;
                    case SciCam.SCI_ERR_CAMERA_PAYLOAD_SIZE_INVALID: errorMsg += " Invalid payload size."; break;
                    case SciCam.SCI_ERR_CAMERA_REGISTER_IMAGE_EVENT_FAILED: errorMsg += " Failed to register image event."; break;
                    case SciCam.SCI_ERR_CAMERA_CTI: errorMsg += " CTI error."; break;
                    case SciCam.SCI_ERR_CAMERA_DS: errorMsg += " DS error."; break;
                    case SciCam.SCI_ERR_CAMERA_GEN_TL_EVENT: errorMsg += " GenTL Event error."; break;
                    case SciCam.SCI_ERR_CAMERA_BUF: errorMsg += " Buf error."; break;
                    default: break;
                }
            }
            else
            {
                errorMsg = msg;
            }
            textBox1.AppendText(errorMsg);
            textBox1.AppendText(System.Environment.NewLine);

        }

        //ch:刷新控件状态 | en:Refresh UI State
        private void RefreshWindow()
        {

            // 打开设备按钮
            btn_open.Enabled = !m_bOpenDevice;
            // 关闭相机按钮
            btn_close.Enabled = m_bOpenDevice;
            //枚举设备按钮
            btn_enum.Enabled = !m_bOpenDevice;
            // 连续采集
            rbn_continusMode.Enabled = m_bOpenDevice && !m_bStartGrabbing;
            // 触发模式
            rbn_triggerMode.Enabled = m_bOpenDevice && !m_bStartGrabbing;
            // 开始采集按钮
            btn_startGrabbing.Enabled = m_bOpenDevice && !m_bStartGrabbing;
            // 停止采集按钮
            btn_stopGrabbing.Enabled = m_bOpenDevice && m_bStartGrabbing;
            // 软触发按钮
            btn_software.Enabled = m_nTriggerMode && m_bOpenDevice;
            // 硬触发按钮
            btn_trigger.Enabled = m_nTriggerMode && m_bOpenDevice;
            //软触发信号按钮
            btn_excute.Enabled = m_IsSoftWare && m_nTriggerMode;
            //保存图片按钮
            btn_saveimg.Enabled = m_bStartGrabbing;
        }

        //ch:从勾选框更新值到数组 | en:Update value from checkbox to array
        private void updateSelCam()
        {
            for (int i = 0; i < 9; i++)
            {
                CheckBox checkBox = Controls.Find("checkBox" + (i + 1), true).FirstOrDefault() as CheckBox;
                m_bCamCheck[i] = checkBox.Checked;
            }

        }

        //ch:保存图片 | en:Save Image
        private uint SaveImage(IntPtr imgData, ulong imgWidth, ulong imgHeight, ulong framID, SciCam.SciCamPixelType imgType, int index)
        {
            uint nReVal = SciCam.SCI_CAMERA_OK;

            mutexarr[index].WaitOne();

            if (m_isSaveImg[index])
            {
                string fileName = string.Format("Device_{0}Image_W{1}_H{2}_fID{3}.bmp", index,imgWidth, imgHeight, framID);
                nReVal = SciCam.PayloadSaveImage(fileName, imgType, imgData, (long)imgWidth, (long)imgHeight);
                if (nReVal != SciCam.SCI_CAMERA_OK)
                {
                    ShowMsg("Save bmp image failed", nReVal, index + 1, true);
                }
            }

            m_isSaveImg[index] = false;
            mutexarr[index].ReleaseMutex();
            return 0;
        }

        // ch:获取当前图像转换格式后的相关信息 | en:Get info about the current image after conversion format
        private int GetConvertedInfo(IntPtr payload, int index)
        {

            if (payload == IntPtr.Zero)
            {
                return -1;
            }

            SciCam.SCI_CAM_PAYLOAD_ATTRIBUTE payloadAttribute = new SciCam.SCI_CAM_PAYLOAD_ATTRIBUTE();
            uint nReVal = SciCam.PayloadGetAttribute(payload, ref payloadAttribute);

            if (nReVal !=  SciCam.SCI_CAMERA_OK)
            {
                return -1;
            }

            bool imgIsComplete = payloadAttribute.isComplete;
            SciCam.SciCamPayloadMode payloadMode = payloadAttribute.payloadMode;
            SciCam.SciCamPixelType imgPixelType = payloadAttribute.imgAttr.pixelType;
            ulong imgWidth = payloadAttribute.imgAttr.width;
            ulong imgHeight = payloadAttribute.imgAttr.height;
            ulong framID = payloadAttribute.frameID;

            if (!imgIsComplete || payloadMode != SciCam.SciCamPayloadMode.SciCam_PayloadMode_2D)
            {
                return -1;
            }

            IntPtr imgData = IntPtr.Zero;
            nReVal = SciCam.PayloadGetImage(payload, ref imgData);
            if (nReVal !=  SciCam.SCI_CAMERA_OK)
            {
                return -1;
            }

            long destImgSize = 0;
            IntPtr destImg = IntPtr.Zero;

            if (imgPixelType == SciCam.SciCamPixelType.Mono1p ||
                imgPixelType == SciCam.SciCamPixelType.Mono2p ||
                imgPixelType == SciCam.SciCamPixelType.Mono4p ||
                imgPixelType == SciCam.SciCamPixelType.Mono8s ||
                imgPixelType == SciCam.SciCamPixelType.Mono8 ||
                imgPixelType == SciCam.SciCamPixelType.Mono10 ||
                imgPixelType == SciCam.SciCamPixelType.Mono10p ||
                imgPixelType == SciCam.SciCamPixelType.Mono12 ||
                imgPixelType == SciCam.SciCamPixelType.Mono12p ||
                imgPixelType == SciCam.SciCamPixelType.Mono14 ||
                imgPixelType == SciCam.SciCamPixelType.Mono16 ||
                imgPixelType == SciCam.SciCamPixelType.Mono10Packed ||
                imgPixelType == SciCam.SciCamPixelType.Mono12Packed ||
                imgPixelType == SciCam.SciCamPixelType.Mono14p)
            {
                nReVal = SciCam.PayloadConvertImageEx(ref payloadAttribute.imgAttr, imgData, SciCam.SciCamPixelType.Mono8, IntPtr.Zero, ref destImgSize, true,0);
                if (nReVal ==  SciCam.SCI_CAMERA_OK)
                {
                    try
                    {
                        destImg = Marshal.AllocHGlobal((int)destImgSize);

                        nReVal = SciCam.PayloadConvertImageEx(ref payloadAttribute.imgAttr, imgData, SciCam.SciCamPixelType.Mono8, destImg, ref destImgSize, true,0);
                        if (nReVal ==  SciCam.SCI_CAMERA_OK)
                        {
                            byte[] bBitmap = new byte[destImgSize];
                            Marshal.Copy(destImg, bBitmap, 0, (int)destImgSize);
                            Bitmap bitMap = new Bitmap((int)imgWidth, (int)imgHeight, GdiPlus.PixelFormat.Format8bppIndexed);
                            GdiPlus.BitmapData bitmapData = bitMap.LockBits(new Rectangle(0, 0, (int)imgWidth, (int)imgHeight), GdiPlus.ImageLockMode.WriteOnly, GdiPlus.PixelFormat.Format8bppIndexed);
                            Marshal.Copy(bBitmap, 0, bitmapData.Scan0, (int)destImgSize);
                            bitMap.UnlockBits(bitmapData);

                            //设置调色板
                            GdiPlus.ColorPalette palette = bitMap.Palette;
                            for (int i = 0; i < 256; i++)
                            {
                                palette.Entries[i] = Color.FromArgb(i, i, i);
                            }
                            bitMap.Palette = palette;

                            //显示图片
                           PictureBox pictureBox = Controls.Find("pictureBox"+(index + 1), true).FirstOrDefault() as PictureBox;
                            pictureBox.Image = bitMap;

                            SaveImage(destImg, imgWidth, imgHeight, framID, SciCam.SciCamPixelType.Mono8, index);
                        }
                    }
                    catch (Exception ex)
                    {

                    }
                    finally
                    {
                        if (destImg != IntPtr.Zero)
                        {
                            Marshal.FreeHGlobal(destImg);
                        }
                    }
                }
            }
            else
            {
                nReVal = SciCam.PayloadConvertImageEx(ref payloadAttribute.imgAttr, imgData, SciCam.SciCamPixelType.RGB8, IntPtr.Zero, ref destImgSize, true,0);
                if (nReVal ==  SciCam.SCI_CAMERA_OK)
                {
                    try
                    {
                        destImg = Marshal.AllocHGlobal((int)destImgSize);
                        nReVal = SciCam.PayloadConvertImageEx(ref payloadAttribute.imgAttr, imgData, SciCam.SciCamPixelType.RGB8, destImg, ref destImgSize, true,0);
                        if (nReVal ==  SciCam.SCI_CAMERA_OK)
                        {
                            byte[] bBitmap = new byte[destImgSize];
                            Marshal.Copy(destImg, bBitmap, 0, (int)destImgSize);
                            Bitmap bitMap = new Bitmap((int)imgWidth, (int)imgHeight, GdiPlus.PixelFormat.Format24bppRgb);
                            GdiPlus.BitmapData bitmapData = bitMap.LockBits(new Rectangle(0, 0, (int)imgWidth, (int)imgHeight), GdiPlus.ImageLockMode.WriteOnly, GdiPlus.PixelFormat.Format24bppRgb);
                            Marshal.Copy(bBitmap, 0, bitmapData.Scan0, (int)destImgSize);
                            bitMap.UnlockBits(bitmapData);

                            //显示图片
                            PictureBox pictureBox = Controls.Find("pictureBox"+(index + 1), true).FirstOrDefault() as PictureBox;
                            
                            pictureBox.Image = bitMap;

                            SaveImage(destImg, imgWidth, imgHeight, framID, SciCam.SciCamPixelType.RGB8, index);



                        }
                    }
                    catch (Exception ex)
                    {

                    }
                    finally
                    {
                        if (destImg != IntPtr.Zero)
                        {
                            Marshal.FreeHGlobal(destImg);
                        }
                    }
                }
            }
            return 0;
        }

        // ch:工作线程 | en:Working thread
        private void GrabThreadProcess(object state)
        {
            int index = (int)state; // 转换参数类型
         
            uint nReVal =  SciCam.SCI_CAMERA_OK;
            IntPtr payload = IntPtr.Zero;
            if (m_currentDevArr[index].IsDeviceOpen())
            {
               
                while (m_bStartGrabbing)
                {
                    
                    nReVal = m_currentDevArr[index].Grab(ref payload);
                    if (nReVal == SciCam.SCI_CAMERA_OK)
                    {
                        int reVal = GetConvertedInfo(payload, index);
                    }

                    nReVal = m_currentDevArr[index].FreePayload(payload);
                }
            }

        }

        // ch:点击重新枚举按钮 | en:Press Enum Button
        private void btn_enum_Click(object sender, EventArgs e)
        {
            uint nReVal = SciCam.DiscoveryDevices(ref m_stDevList, (uint)(SciCam.SciCamTLType.SciCam_TLType_Gige) | (uint)(SciCam.SciCamTLType.SciCam_TLType_Usb3));
            if (nReVal !=  SciCam.SCI_CAMERA_OK)
            {
                ShowMsg("Discovery devices failed!", nReVal, -1, true);

                return;
            }
            if (m_stDevList.count == 0)
            {
                ShowMsg("Discovery devices Success, but found 0 device.", 0, -1, true);
                return;
            }
            string chDeviceName;


            for (int i = 0; i < 9; i++)
            {
               CheckBox checkBox = Controls.Find("checkBox" + (i + 1), true).FirstOrDefault() as CheckBox;
             
                SciCam.SCI_DEVICE_INFO device = m_stDevList.pDevInfo[i];
                SciCam.SciCamTLType devTlType = device.tlType;
                SciCam.SciCamDeviceType devType = device.devType;
                if (devTlType == SciCam.SciCamTLType.SciCam_TLType_Gige)
                {
                    SciCam.SCI_DEVICE_GIGE_INFO gigeDevInfo = (SciCam.SCI_DEVICE_GIGE_INFO)SciCam.ByteToStruct(device.info.gigeInfo, typeof(SciCam.SCI_DEVICE_GIGE_INFO));
                    if (!string.IsNullOrEmpty(gigeDevInfo.userDefineName))
                    {
                        chDeviceName = string.Format("{0} [{1}]", gigeDevInfo.modelName, gigeDevInfo.userDefineName);

                    }
                    else
                    {
                        chDeviceName = string.Format("{0} [{1}]", gigeDevInfo.modelName, gigeDevInfo.serialNumber);

                    }
                    checkBox.Enabled = true;
                    checkBox.Text = chDeviceName;
                    m_nValidCamNum++;
                }
                else if (devTlType == SciCam.SciCamTLType.SciCam_TLType_Usb3)
                {
                    SciCam.SCI_DEVICE_USB3_INFO usbinfo = (SciCam.SCI_DEVICE_USB3_INFO)SciCam.ByteToStruct(device.info.usb3Info, typeof(SciCam.SCI_DEVICE_USB3_INFO));
                    if (!string.IsNullOrEmpty(usbinfo.userDefineName))
                    {
                        chDeviceName = string.Format("{0} [{1}]", usbinfo.modelName, usbinfo.userDefineName);

                    }
                    else
                    {
                        chDeviceName = string.Format("{0} [{1}]", usbinfo.modelName, usbinfo.serialNumber);

                    }
                    checkBox.Enabled = true;
                    checkBox.Text = chDeviceName;
                    m_nValidCamNum++;
                }
                else
                {
                    chDeviceName = string.Format("Cam {0}", i + 1);
                    checkBox.Text = chDeviceName;
                    checkBox.Enabled = false;
                }

                m_bCamCheck[i] = false;
            }
        }

        // ch:点击打开设备按钮 | en:Press Open Device Button
        private void btn_open_Click(object sender, EventArgs e)
        {
            if (m_nValidCamNum == 0)
                return;
            uint nReVal =  SciCam.SCI_CAMERA_OK;
            m_bOpenDevice = true;
            bool bHaveCheck = false;
            updateSelCam();
            for (int i = 0; i < 9; i++)
            {
                if (m_bCamCheck[i])
                {
                    bHaveCheck = true;
                    nReVal = m_currentDevArr[i].CreateDevice(ref m_stDevList.pDevInfo[i]);
                    if (nReVal !=  SciCam.SCI_CAMERA_OK)
                    {
                        ShowMsg("Create device failed", nReVal, i + 1, true);
                        continue;
                    }
                    nReVal = m_currentDevArr[i].OpenDevice();
                    if (nReVal !=  SciCam.SCI_CAMERA_OK)
                    {
                        m_bOpenDevice = false;
                        m_currentDevArr[i].DeleteDevice();
                        ShowMsg("Open device failed", nReVal, i + 1, true);
                        continue;
                    }

                }


            }
            if(!m_bOpenDevice)
            {
                for (int i = 0; i < 9; i++)
                {
                    if (m_bCamCheck[i] && m_currentDevArr[i].IsDeviceOpen())
                    {
                        m_currentDevArr[i].CloseDevice();
                        m_currentDevArr[i].DeleteDevice();
                    }
                }
            }



            if (!bHaveCheck)
                m_bOpenDevice = false;
            if (m_bOpenDevice && bHaveCheck)
            {
                rbn_continusMode_CheckedChanged(rbn_continusMode, EventArgs.Empty);
                RefreshWindow();
            }
            else
            {
                if (false == bHaveCheck)
                {
                    ShowMsg("Unchecked device!", 0, -1, false);
                }
                else
                {
                    ShowMsg("No device opened successfully!", 0, -1, false);
                }
            }
            for (int i = 0; i < 9; i++)
            {
                if (i < m_nValidCamNum)
                {
                   CheckBox checkBox = Controls.Find("checkBox" + (i + 1), true).FirstOrDefault() as CheckBox;
                    checkBox.Enabled = !m_bOpenDevice;
                }
            }


        }

        // ch:点击关闭设备按钮 | en:Press Close Device Button
        private void btn_close_Click(object sender, EventArgs e)
        {
            if (m_bStartGrabbing)
            {
                btn_stopGrabbing_Click(btn_close, EventArgs.Empty);

            }
            uint nReVal =  SciCam.SCI_CAMERA_OK;
            for (int i = 0; i < 9; i++)
            {
                if (m_currentDevArr[i].IsDeviceOpen())
                {

                    nReVal = m_currentDevArr[i].CloseDevice();
                    if ( SciCam.SCI_CAMERA_OK != nReVal)
                    {
                        ShowMsg("Close device fail! ", nReVal, i + 1, true);
                    }
                    nReVal = m_currentDevArr[i].DeleteDevice();
                    if ( SciCam.SCI_CAMERA_OK != nReVal)
                    {
                        ShowMsg("Delete device fail! ", nReVal, i + 1, true);
                    }
                }

                if (i < m_nValidCamNum)
                {
                   CheckBox checkBox = Controls.Find("checkBox" + (i + 1), true).FirstOrDefault() as CheckBox;
                    checkBox.Enabled = true;
                }
            }

            m_bOpenDevice = false;
            RefreshWindow();
        }

        // ch:点击连续模式按钮 | en:Press ContinueMode Button
        private void rbn_continusMode_CheckedChanged(object sender, EventArgs e)
        {
            rbn_continusMode.Checked = true;
            rbn_triggerMode.Checked = false;
            uint nReVal =  SciCam.SCI_CAMERA_OK;
            for (int i = 0; i < 9; i++)
            {
                if (m_currentDevArr[i].IsDeviceOpen())
                {
                    nReVal = m_currentDevArr[i].SetEnumValueByStringEx(SciCam.SciCamDeviceXmlType.SciCam_DeviceXml_Camera, "TriggerMode", "Off");
                    if ( SciCam.SCI_CAMERA_OK != nReVal)
                    {
                        ShowMsg("Set ContinueMode fail! ", nReVal, i + 1, true);
                    }
                }
            }
            m_nTriggerMode = false;
            RefreshWindow();
        }

        // ch:点击触发模式按钮 | en:Press TriggerMode Button
        private void rbn_triggerMode_CheckedChanged(object sender, EventArgs e)
        {
            rbn_continusMode.Checked = false;
            rbn_triggerMode.Checked = true;
            uint nReVal =  SciCam.SCI_CAMERA_OK;
            for (int i = 0; i < 9; i++)
            {
                if (m_currentDevArr[i].IsDeviceOpen())
                {
                    nReVal = m_currentDevArr[i].SetEnumValueByStringEx(SciCam.SciCamDeviceXmlType.SciCam_DeviceXml_Camera, "TriggerMode", "On");
                    if ( SciCam.SCI_CAMERA_OK != nReVal)
                    {
                        ShowMsg("Set TriggerMode fail! ", nReVal, i + 1, true);
                    }
                }
            }
            m_nTriggerMode = true;
            RefreshWindow();
        }

        // ch:点击开始采集按钮 | en:Press StartGrab Button
        private void btn_startGrabbing_Click(object sender, EventArgs e)
        {
            if (false == m_bOpenDevice)
            {
                return;
            }
            uint nReVal =  SciCam.SCI_CAMERA_OK;
            for (int i = 0; i < 9; i++)
            {
                if (m_currentDevArr[i].IsDeviceOpen())
                {
                    nReVal = m_currentDevArr[i].StartGrabbing();
                    if ( SciCam.SCI_CAMERA_OK != nReVal)
                    {
                        ShowMsg("Start Grab fail! ", nReVal, i + 1, true);
                        continue;
                    }
                    m_bStartGrabbing = true;
                    m_hGrabThread[i] = new Thread(GrabThreadProcess);
                    m_hGrabThread[i].Start(i);
                    if (null == m_hGrabThread[i])
                    {
                        string str = string.Format("Create grab thread fail! DevIndex[{%0}]", i + 1);
                        ShowMsg(str, 1, 0, false);
                    }
                }
            }

            RefreshWindow();
        }

        // ch:点击停止采集按钮 | en:Press StopGrab Button
        private void btn_stopGrabbing_Click(object sender, EventArgs e)
        {
            if (false == m_bStartGrabbing)
            {
                return;
            }
            uint nReVal =  SciCam.SCI_CAMERA_OK;
            m_bStartGrabbing = false;
            for (int i = 0; i < 9; i++)
            {
                if (m_currentDevArr[i].IsDeviceOpen())
                {
                    if (m_hGrabThread[i] != null)
                    {
                        m_hGrabThread[i].Join();
                    }
                    nReVal = m_currentDevArr[i].StopGrabbing();
                    if ( SciCam.SCI_CAMERA_OK != nReVal)
                    {
                        ShowMsg("Stop Grab fail! ", nReVal, i + 1, true);
                    }

                }
            }
            
            RefreshWindow();
        }

        // ch:点击硬触发按钮 | en:Press HardTrigger Button
        private void btn_trigger_Click(object sender, EventArgs e)
        {

            uint nReVal =  SciCam.SCI_CAMERA_OK;
            for (int i = 0; i < 9; i++)
            {
                if (m_currentDevArr[i].IsDeviceOpen())
                {
                    nReVal = m_currentDevArr[i].SetEnumValueByStringEx(SciCam.SciCamDeviceXmlType.SciCam_DeviceXml_Camera, "TriggerSource", "Line1");
                    if ( SciCam.SCI_CAMERA_OK != nReVal)
                    {
                        ShowMsg("Set TriggerSource to Line1 fail! ", nReVal, i + 1, true);
                    }
                }
            }
            m_IsSoftWare = false;
            RefreshWindow();
        }

        // ch:点击软触发按钮 | en:Press Software Trigger Button
        private void btn_software_Click(object sender, EventArgs e)
        {
            uint nReVal =  SciCam.SCI_CAMERA_OK;
            for (int i = 0; i < 9; i++)
            {
                if (m_currentDevArr[i].IsDeviceOpen())
                {
                    nReVal = m_currentDevArr[i].SetEnumValueByStringEx(SciCam.SciCamDeviceXmlType.SciCam_DeviceXml_Camera, "TriggerSource", "Software");
                    if ( SciCam.SCI_CAMERA_OK != nReVal)
                    {
                        ShowMsg("Set TriggerSource to Software fail! ", nReVal, i + 1, true);
                    }
                }
            }
            m_IsSoftWare = true;
            RefreshWindow();
        }

        // ch:点击保存图片按钮 | en:Press SaveImage Button
        private void btn_saveimg_Click(object sender, EventArgs e)
        {
            for(int i = 0;i<9;i++)
            {
                if (m_bCamCheck[i])
                    m_isSaveImg[i] = true;
            }
        }

        // ch:点击软触发一次按钮 | en:Press Software Command Button
        private void btn_excute_Click(object sender, EventArgs e)
        {
            if (!m_bStartGrabbing) return;
            uint nReVal =  SciCam.SCI_CAMERA_OK;
            for (int i = 0; i < 9; i++)
            {
                if (m_currentDevArr[i].IsDeviceOpen())
                {
                    nReVal = m_currentDevArr[i].SetCommandValueEx(SciCam.SciCamDeviceXmlType.SciCam_DeviceXml_Camera, "TriggerSoftware");
                    if ( SciCam.SCI_CAMERA_OK != nReVal)
                    {
                        ShowMsg("TriggerSoftware  fail! ", nReVal, i + 1, true);
                    }
                }
            }


        }

        // ch:双击窗口缩放图像窗口 | en:DoubleClick Form to Zoom PictureBox
        private void Form1_MouseDoubleClick_1(object sender, MouseEventArgs e)
        {
            var control = sender as Control;
            if (control == null) return;

            if (m_nZoomInIndex == -1)
            {
                // 坐标转换为窗体坐标
                Point globalPoint = control.PointToScreen(e.Location);
                Point formPoint = this.PointToClient(globalPoint);
                for (int i = 0; i < 9; i++)
                {
                    //判断是否打开相机，并被勾选
                    if (m_bOpenDevice == true && m_bCamCheck[i] == true)
                    {
                        PictureBox pictureBox = groupBox1.Controls.Find("pictureBox" + (i + 1), true).FirstOrDefault() as PictureBox;
                        Rectangle rectInForm = pictureBox.RectangleToScreen(pictureBox.ClientRectangle);
                        rectInForm = this.RectangleToClient(rectInForm);


                       
                        if(rectInForm.Contains(formPoint))
                        {
                            for (int j = 0; j < 9; j++)
                            {
                                
                                PictureBox pictureBox_1 = groupBox1.Controls.Find("pictureBox"+(i + 1), true).FirstOrDefault() as PictureBox;
                                CheckBox checkBox = Controls.Find("checkBox" + (i + 1), true).FirstOrDefault() as CheckBox;
                              
                                if (i != j)
                                {
                                    pictureBox_1.Visible = false;
                                }
                                else
                                {
                                    m_point = pictureBox_1.Location;
                                    m_size = pictureBox_1.Size;
                                    pictureBox_1.Size = new Size(groupBox1.Size.Width - 30, groupBox1.Size.Height - 30);
                                    pictureBox_1.Location =new Point(13,15);
                                }
                                checkBox.Visible = false;
                              
                                
                            }
                            m_nZoomInIndex = i;

                            Invalidate();
                        }
                    }
                }
            }
            else
            {
                
                for (int i = 0; i < 9; i++)
                {

                    PictureBox pictureBox = groupBox1.Controls.Find("pictureBox"+(i + 1), true).FirstOrDefault() as PictureBox;
                    CheckBox checkBox = Controls.Find("checkBox" + (i + 1), true).FirstOrDefault() as CheckBox;
                   
                    if (m_nZoomInIndex == i)
                    {

                        pictureBox.Size = m_size;
                        pictureBox.Location = m_point;
                    }
   
                    checkBox.Visible = true;
                   
                    pictureBox.Visible = true;

                }
                m_nZoomInIndex = -1;
                Invalidate();
            }
        }

        // ch:关闭页面 | en:Close Form
        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            btn_close_Click(btn_close, EventArgs.Empty);
            foreach (var mutex in mutexarr)
            {
                mutex.Dispose();
            }
        }
    }
}


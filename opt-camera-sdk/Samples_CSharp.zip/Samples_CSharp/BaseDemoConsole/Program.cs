﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Runtime.InteropServices;

using SciCamera.Net;

namespace BaseDemoConsole
{
    internal partial class Program
    {
        static void Main(string[] args)
        {
            ShowMainMenu();
        }
    }
}
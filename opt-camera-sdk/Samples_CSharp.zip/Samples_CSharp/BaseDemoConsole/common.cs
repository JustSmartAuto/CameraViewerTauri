﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BaseDemoConsole
{
    internal partial class Program
    {
        static void ShowMainMenu()
        {
            string[] mainMenu =
            {
                "[ 0] Exit program",
                "[ 1] Get SDK version information",
                "[ 2] Discovery devices",
                "[ 3] Open device",
                "[ 4] Close device",
                "[ 5] Open CL Camera",
                "[ 6] Close CL Camera",
                "[ 7] Check device/camera open status",
                "[ 8] Check CL camera open status",
                "[ 9] Set grab timeout",
                "[10] Get grab timeout",
                "[11] Set grab strategy",
                "[12] Get grab strategy",
                "[13] Set grab buffer count",
                "[14] Get grab buffer count",
                "[15] LP3D set grab type",
                "[16] Start grabbing",
                "[17] Stop grabbing",
                "[18] Register payload callback",
                "[19] Unregister payload callback",
                "[20] Grab one image",
                "[21] Device node"
            };

            while (true)
            {
                ClrScreen();
                ShowInfoTitle();
                ShowMenu(mainMenu);

                int op = WaitForNumInput(true, 0, 21);

                if (op == 0) break;

                ClrScreen();

                switch (op)
                {
                    case 1:
                        menuItem_GetSdkVersionInformation();
                        break;
                    case 2:
                        menuItem_DiscoveryDevices();
                        break;
                    case 3:
                        menuItem_OpenDevice();
                        break;
                    case 4:
                        menuItem_CloseDevice();
                        break;
                    case 5:
                        menuItem_CL_OpenCam();
                        break;
                    case 6:
                        menuItem_CL_CloseCam();
                        break;
                    case 7:
                        menuItem_IsDeviceOpen();
                        break;
                    case 8:
                        menuItem_IsCLCameraOpen();
                        break;
                    case 9:
                        menuItem_SetGrabTimeout();
                        break;
                    case 10:
                        menuItem_GetGrabTimeout();
                        break;
                    case 11:
                        menuItem_SetGrabStrategy();
                        break;
                    case 12:
                        menuItem_GetGrabStrategy();
                        break;
                    case 13:
                        menuItem_SetGrabBufferCount();
                        break;
                    case 14:
                        menuItem_GetGrabBufferCount();
                        break;
                    case 15:
                        menuItem_LP3D_SetGrabType();
                        break;
                    case 16:
                        menuItem_StartGrabbing();
                        break;
                    case 17:
                        menuItem_StopGrabbing();
                        break;
                    case 18:
                        menuItem_RegisterPayloadCallBack();
                        break;
                    case 19:
                        menuItem_UnRegisterPayloadCallBack();
                        break;
                    case 20:
                        menuItem_GrabOneImage();
                        break;
                    case 21:
                        menuItem_ReadWriteNode();
                        break;
                }

                waitEnterAnyKeyContinue();
            }
        }

        static void ShowInfoTitle()
        {
            Console.WriteLine("*******************************************");
            Console.WriteLine("* {0,-39} *", "SciCamera Demo");
            Console.WriteLine("*******************************************");
        }

        static void ShowMenu(string[] menuStr)
        {
            Console.WriteLine("-------------------------------------------");
            for (int index = 0; index < menuStr.Length; ++index)
            {
                Console.WriteLine(menuStr[index]);
            }
            Console.WriteLine("-------------------------------------------");
            Console.Write("Please enter your choice based on the menu option number: ");
        }

        static void ClrScreen()
        {
            Console.Clear();
        }

        static int WaitForNumInput(bool isLimit, int min, int max)
        {
            int number;

            while (true)
            {
                if (int.TryParse(Console.ReadLine(), out number))
                {
                    if (isLimit)
                    {
                        if (number < min || number > max)
                        {
                            Console.Write("Input error, please input again: ");
                        }
                        else
                        {
                            break;
                        }
                    }
                    else
                    {
                        break;
                    }
                }
                else
                {
                    Console.Write("Input error, please input again: ");
                }
            }

            return number;
        }

        static double WaitForDoubleNumInput()
        {
            double dVal;

            while (true)
            {
                if (double.TryParse(Console.ReadLine(), out dVal))
                {
                    break;
                }
                else
                {
                    Console.WriteLine("Input error, please enter again: ");
                }
            }

            return dVal;
        }

        static void waitEnterAnyKeyContinue()
        {
            Console.Write("Press any key to continue...");
            Console.ReadKey();
        }
    }
}

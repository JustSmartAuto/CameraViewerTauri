﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Net;
using System.Runtime.InteropServices;

using SciCamera.Net;
using System.Runtime.CompilerServices;

namespace BaseDemoConsole
{
    internal partial class Program
    {
        static void menuItem_GetSdkVersionInformation()
        {
            uint version = SciCam.GetSDKVersion();
            uint verMain = (version >> 24) & 0xff;
            uint verSub = (version >> 16) & 0xff;
            uint verRev = (version >> 8) & 0xff;
            uint verTest = version & 0xff;
            //Console.WriteLine($"SDK version is: V{verMain}.{verSub}.{verRev}.{verTest}");
            Console.WriteLine("SDK version is: V{0}.{1}.{2}.{3}", verMain, verSub, verRev, verTest);
        }

        static void menuItem_DiscoveryDevices()
        {
            Console.WriteLine("Please wait ...");

            SciCam.SCI_DEVICE_INFO_LIST devInfos = new SciCam.SCI_DEVICE_INFO_LIST();

            UInt32 reVal = SciCam.DiscoveryDevices(ref devInfos, 0);
            Console.WriteLine("The number of discovered devices is: {0}", devInfos.count);
            for (uint i = 0; i < devInfos.count; ++i)
            {
                Console.WriteLine("-------------------------------------------");
                Console.WriteLine("| ---- Index: {0}", i);
                ShowDeviceInfo(ref devInfos.pDevInfo[i]);
            }
            if (devInfos.count != 0)
            {
                Console.WriteLine("-------------------------------------------");
                Console.Write("Please enter your selection based on the index: ");
                int op = WaitForNumInput(true, 0, (int)devInfos.count - 1);

                m_currentDevInfo = devInfos.pDevInfo[op];
            }
        }

        static void menuItem_OpenDevice()
        {
            uint nReVal = m_currentDev.CreateDevice(ref m_currentDevInfo);
            if (nReVal != SciCam.SCI_CAMERA_OK)
            {
                Console.WriteLine("Create device failed, return error code: {0}: {1}", nReVal, GetErrorCodeStr(nReVal));
                return;
            }

            nReVal = m_currentDev.OpenDevice();
            if (nReVal != SciCam.SCI_CAMERA_OK)
            {
                Console.WriteLine("Open device failed, return error code: {0}: {1}", nReVal, GetErrorCodeStr(nReVal));
            }
            else
            {
                Console.WriteLine("Open device success!");
            }
        }

        static void menuItem_CloseDevice()
        {
            uint nReVal = m_currentDev.CloseDevice();
            if (nReVal != SciCam.SCI_CAMERA_OK)
            {
                Console.WriteLine("Close device failed, return error code: {0}: {1}", nReVal, GetErrorCodeStr(nReVal));
            }
            else
            {
                m_currentDev.DeleteDevice();
                Console.WriteLine("Close device success!");
            }
        }

        static void menuItem_CL_OpenCam()
        {
            uint nReVal = m_currentDev.CreateDevice(ref m_currentDevInfo);
            if (nReVal != SciCam.SCI_CAMERA_OK)
            {
                Console.WriteLine("Create device failed, return error code: {0}: {1}", nReVal, GetErrorCodeStr(nReVal));
                return;
            }

            nReVal = m_currentDev.CL_OpenCam();
            if (nReVal != SciCam.SCI_CAMERA_OK)
            {
                Console.WriteLine("Open CL camera failed, return error code: {0}: {1}", nReVal, GetErrorCodeStr(nReVal));
            }
            else
            {
                Console.WriteLine("Open CL camera success!");
            }
        }

        static void menuItem_CL_CloseCam()
        {
            uint nReVal = m_currentDev.CL_CloseCam();
            if (nReVal != SciCam.SCI_CAMERA_OK)
            {
                Console.WriteLine("Close CL camera failed, return error code: {0}: {1}", nReVal, GetErrorCodeStr(nReVal));
            }
            else
            {
                Console.WriteLine("Close CL camera success!");
            }
        }

        static void menuItem_IsDeviceOpen()
        {
            bool bReVal = m_currentDev.IsDeviceOpen();
            if (bReVal)
            {
                Console.WriteLine("Device is opened.");
            }
            else
            {
                Console.WriteLine("Device is not opened.");
            }
        }

        static void menuItem_IsCLCameraOpen()
        {
            bool bReVal = m_currentDev.CL_IsCamOpen();
            if (bReVal)
            {
                Console.WriteLine("CL camera is opened.");
            }
            else
            {
                Console.WriteLine("CL camera is not opened.");
            }
        }

        static void menuItem_SetGrabTimeout()
        {
            Console.Write("Please enter the grab timeout: ");
            int timeout = WaitForNumInput(true, 0, 999999);
            uint nReVal = m_currentDev.SetGrabTimeout((uint)timeout);
            if (nReVal != SciCam.SCI_CAMERA_OK)
            {
                Console.WriteLine("Set grab timeout failed, return error code: {0}: {1}", nReVal, GetErrorCodeStr(nReVal));
            }
            else
            {
                Console.WriteLine("Set grab timeout success, current timeout is: {0}", timeout);
            }
        }

        static void menuItem_GetGrabTimeout()
        {
            uint timeout = 0;
            uint nReVal = m_currentDev.GetGrabTimeout(ref timeout);
            if (nReVal != SciCam.SCI_CAMERA_OK)
            {
                Console.WriteLine("Get grab timeout failed, return error code: {0}: {1}", nReVal, GetErrorCodeStr(nReVal));
            }
            else
            {
                Console.WriteLine("Get grab timeout success.");
                Console.WriteLine("Current grab timeout is: {0}ms", timeout);
            }
        }

        static void menuItem_SetGrabStrategy()
        {
            string[] menu =
            {
                "Please select the grab stategy:",
                "[0] OneByOne",
                "[1] Latest",
                "[2] Upcoming"
            };

            ShowMenu(menu);

            int op = WaitForNumInput(true, 0, 2);
            uint nReVal = m_currentDev.SetGrabStrategy((SciCam.SciCamGrabStrategy)op);
            if (nReVal != SciCam.SCI_CAMERA_OK)
            {
                Console.WriteLine("Set grab strategy failed, return error code: {0}: {1}", nReVal, GetErrorCodeStr(nReVal));
            }
            else
            {
                Console.WriteLine("Set grab strategy success!");
            }
        }

        static void menuItem_GetGrabStrategy()
        {
            SciCam.SciCamGrabStrategy grabStrategy = SciCam.SciCamGrabStrategy.SciCam_GrabStrategy_OneByOne;
            uint nReVal = m_currentDev.GetGrabStrategy(ref grabStrategy);
            if (nReVal != SciCam.SCI_CAMERA_OK)
            {
                Console.WriteLine("Get grab strategy failed, return error code: {0}: {1}", nReVal, GetErrorCodeStr(nReVal));
            }
            else
            {
                Console.WriteLine("Get grab strategy success!");
                string strGrabStrategy = GetEnumStr_SciCamGrabStrategy(grabStrategy);
                Console.WriteLine("Current grab strategy is:{0}", strGrabStrategy);
            }
        }

        static void menuItem_SetGrabBufferCount()
        {
            Console.WriteLine("Please enter grab buffer count: ");
            uint bufferCount = (uint)WaitForNumInput(true, 0, 999999);
            uint nReVal = m_currentDev.SetGrabBufferCount(bufferCount);
            if (nReVal != SciCam.SCI_CAMERA_OK)
            {
                Console.WriteLine("Set grab buffer count failed, return error code: {0}: {1}", nReVal, GetErrorCodeStr(nReVal));
            }
            else
            {
                Console.WriteLine("Set grab buffer count success!");
            }
        }

        static void menuItem_GetGrabBufferCount()
        {
            uint bufferCount = 0;
            uint nReVal = m_currentDev.GetGrabBufferCount(ref bufferCount);
            if (nReVal != SciCam.SCI_CAMERA_OK)
            {
                Console.WriteLine("Get grab buffer count failed, return error code: {0}: {1}", nReVal, GetErrorCodeStr(nReVal));
            }
            else
            {
                Console.WriteLine("Get grab buffer count success.");
                Console.WriteLine("Current grab buffer count is: {0}", bufferCount);
            }
        }

        static void menuItem_LP3D_SetGrabType()
        {
            string[] menu =
            {
                "Please select the LP3D grab mode:",
                "[1] Image",
                "[2] Contour",
                "[3] BatchContour"
            };
            ShowMenu(menu);

            int op = WaitForNumInput(true, 1, 3);
            uint nReVal = m_currentDev.LP3D_SetGrabType((SciCam.SciCamLp3dGrabMode)op);
            if (nReVal != SciCam.SCI_CAMERA_OK)
            {
                Console.WriteLine("Set LP3D grab type failed, return error code: {0}: {1}", nReVal, GetErrorCodeStr(nReVal));
            }
            else
            {
                Console.WriteLine("Set LP3D grab type success!");
            }
        }

        static void menuItem_StartGrabbing()
        {
            uint nReVal = m_currentDev.StartGrabbing();
            if (nReVal != SciCam.SCI_CAMERA_OK)
            {
                Console.WriteLine("Start grabbing failed, return error code: {0}: {1}", nReVal, GetErrorCodeStr(nReVal));
            }
            else
            {
                Console.WriteLine("Start grabbing success!");
            }
        }

        static void menuItem_StopGrabbing()
        {
            uint nReVal = m_currentDev.StopGrabbing();
            if (nReVal != SciCam.SCI_CAMERA_OK)
            {
                Console.WriteLine("Stop grabbing failed, return error code: {0}: {1}", nReVal, GetErrorCodeStr(nReVal));
            }
            else
            {
                Console.WriteLine("Stop grabbing success!");
            }
        }

        static void menuItem_RegisterPayloadCallBack()
        {
            m_imageCallBack = new SciCam.fnOnPayloadDelegate(GrabPayloadData);
            uint nReVal = m_currentDev.RegisterPayloadCallBack(m_imageCallBack, IntPtr.Zero, true);
            if (nReVal != SciCam.SCI_CAMERA_OK)
            {
                Console.WriteLine("Register payload callback function failed, return error code: {0}: {1}", nReVal, GetErrorCodeStr(nReVal));
            }
            else
            {
                Console.WriteLine("Register payload callback function success!");
            }
        }

        static void menuItem_UnRegisterPayloadCallBack()
        {
            uint nReVal = m_currentDev.RegisterPayloadCallBack(null, IntPtr.Zero, true);
            if (nReVal != SciCam.SCI_CAMERA_OK)
            {
                Console.WriteLine("UnRegister payload callback function failed, return error code: {0}: {1}", nReVal, GetErrorCodeStr(nReVal));
            }
            else
            {
                Console.WriteLine("UnRegister payload callback function success!");
            }
        }

        static void menuItem_GrabOneImage()
        {
            IntPtr pPayload = IntPtr.Zero;
            uint nReVal = m_currentDev.Grab(ref pPayload);
            if (nReVal != SciCam.SCI_CAMERA_OK)
            {
                Console.WriteLine("Grab failed, return error code: {0}: {1}", nReVal, GetErrorCodeStr(nReVal));
                return;
            }
            else
            {
                Console.WriteLine("Grab success!");
            }

            ShowPayloadDataAttribute(pPayload);

            nReVal = m_currentDev.FreePayload(pPayload);
            if (nReVal != SciCam.SCI_CAMERA_OK)
            {
                Console.WriteLine("Free payload failed, return error code: {0}: {1}", nReVal, GetErrorCodeStr(nReVal));
            }
        }

        static void menuItem_ReadWriteNode()
        {
            string[] menu =
            {
                "[ 0] Return to the previous menu",
                "[ 1] GetIntValue",
                "[ 2] SetIntValue",
                "[ 3] GetFloatValue",
                "[ 4] SetFloatValue",
                "[ 5] GetBoolValue",
                "[ 6] SetBoolValue",
                "[ 7] GetStringValue",
                "[ 8] SetStringValue",
                "[ 9] GetEnumValue",
                "[10] SetEnumValue",
                "[11] SetEnumValueByString",
                "[12] SetCommandValue",
                "[13] GetNodes",
                "[14] GetIntValueEx",
                "[15] SetIntValueEx",
                "[16] GetFloatValueEx",
                "[17] SetFloatValueEx",
                "[18] GetBoolValueEx",
                "[19] SetBoolValueEx",
                "[20] GetStringValueEx",
                "[21] SetStringValueEx",
                "[22] GetEnumValueEx",
                "[23] SetEnumValueEx",
                "[24] SetEnumValueByStringEx",
                "[25] SetCommandValueEx",
                "[26] GetNodesEx"
            };

            ShowMenu(menu);
            int op = WaitForNumInput(true, 0, 26);

            string inputStr = string.Empty;
            uint nReVal = SciCam.SCI_CAMERA_OK;

            if (op == 0)
            {
                return;
            }
            else if (op == 1)
            {
                inputStr = GetInputNodeName();
                SciCam.SCI_NODE_VAL_INT nodeVal = new SciCam.SCI_NODE_VAL_INT();
                nReVal = m_currentDev.GetIntValue(inputStr, ref nodeVal);
                if (nReVal == SciCam.SCI_CAMERA_OK)
                {
                    Console.WriteLine("---- Node Name: {0}", inputStr);
                    Console.WriteLine("---- Node Value: {0}", nodeVal.nVal);
                    Console.WriteLine("---- Node Max: {0}", nodeVal.nMax);
                    Console.WriteLine("---- Node Min: {0}", nodeVal.nMin);
                    Console.WriteLine("---- Node Inc: {0}", nodeVal.nInc);
                }
            }
            else if (op == 2)
            {
                inputStr = GetInputNodeName();
                Console.Write("Please input node value(int): ");
                int nodeVal = WaitForNumInput(false, 0, 0);
                nReVal = m_currentDev.SetIntValue(inputStr, nodeVal);
                if (nReVal == SciCam.SCI_CAMERA_OK)
                {
                    Console.WriteLine("Set device node: {0}, val: {1} success!", inputStr, nodeVal);
                }
            }
            else if (op == 3)
            {
                inputStr = GetInputNodeName();
                SciCam.SCI_NODE_VAL_FLOAT nodeVal = new SciCam.SCI_NODE_VAL_FLOAT();
                nReVal = m_currentDev.GetFloatValue(inputStr, ref nodeVal);
                if (nReVal == SciCam.SCI_CAMERA_OK)
                {
                    Console.WriteLine("---- Node Name: {0}", inputStr);
                    Console.WriteLine("---- Node Value: {0}", nodeVal.dVal);
                    Console.WriteLine("---- Node Max: {0}", nodeVal.dMax);
                    Console.WriteLine("---- Node Min: {0}", nodeVal.dMin);
                    Console.WriteLine("---- Node Inc: {0}", nodeVal.dInc);
                }
            }
            else if (op == 4)
            {
                inputStr = GetInputNodeName();
                Console.Write("Please input node value(double): ");
                double nodeVal = WaitForDoubleNumInput();
                nReVal = m_currentDev.SetFloatValue(inputStr, nodeVal);
                if (nReVal == SciCam.SCI_CAMERA_OK)
                {
                    Console.WriteLine("Set device node: {0}, val: {1} success!", inputStr, nodeVal);
                }
            }
            else if (op == 5)
            {
                inputStr = GetInputNodeName();
                bool nodeVal = false;
                nReVal = m_currentDev.GetBoolValue(inputStr, ref nodeVal);
                if (nReVal == SciCam.SCI_CAMERA_OK)
                {
                    Console.WriteLine("---- Node Name: {0}", inputStr);
                    Console.WriteLine("---- Node Value: {0}", (nodeVal ? "true" : "false"));
                }
            }
            else if (op == 6)
            {
                inputStr = GetInputNodeName();
                Console.Write("Please input node value(0 is false, ~0 is true)");
                int nodeValTem = WaitForNumInput(false, 0, 0);
                bool nodeVal = nodeValTem == 0 ? false : true;
                nReVal = m_currentDev.SetBoolValue(inputStr, nodeVal);
                if (nReVal == SciCam.SCI_CAMERA_OK)
                {
                    Console.WriteLine("Set device node: {0}, val: {1} success!", inputStr, (nodeVal ? "true" : "false"));
                }
            }
            else if (op == 7)
            {
                inputStr = GetInputNodeName();
                SciCam.SCI_NODE_VAL_STRING nodeVal = new SciCam.SCI_NODE_VAL_STRING();
                nReVal = m_currentDev.GetStringValue(inputStr, ref nodeVal);
                if (nReVal == SciCam.SCI_CAMERA_OK)
                {
                    Console.WriteLine("---- Node Name: {0}", inputStr);
                    Console.WriteLine("---- Node Value: {0}", nodeVal.val);
                }
            }
            else if (op == 8)
            {
                inputStr = GetInputNodeName();
                Console.Write("Please input node value(string): ");
                string nodeVal = Console.ReadLine();
                nReVal = m_currentDev.SetStringValue(inputStr, nodeVal);
                if (nReVal == SciCam.SCI_CAMERA_OK)
                {
                    Console.WriteLine("Set device node: {0}, val: {1} success!", inputStr, nodeVal);
                }
            }
            else if (op == 9)
            {
                inputStr = GetInputNodeName();
                SciCam.SCI_NODE_VAL_ENUM nodeVal = new SciCam.SCI_NODE_VAL_ENUM();
                nReVal = m_currentDev.GetEnumValue(inputStr, ref nodeVal);
                if (nReVal == SciCam.SCI_CAMERA_OK)
                {
                    Console.WriteLine("---- Node Name: {0}", inputStr);
                    Console.WriteLine("---- Node Current Value: {0}", nodeVal.nVal);
                    Console.WriteLine("-------- Node enum item count: {0}", nodeVal.itemCount);
                    Console.WriteLine("-------- Node enum items:");
                    for (int i = 0; i < nodeVal.itemCount; i++)
                    {
                        Console.WriteLine("-------- {0}\t{1}", nodeVal.items[i].val, nodeVal.items[i].desc);
                    }
                }
            }
            else if (op == 10)
            {
                inputStr = GetInputNodeName();
                Console.Write("Please input node value(int): ");
                int nodeVal = WaitForNumInput(false, 0, 0);
                nReVal = m_currentDev.SetEnumValue(inputStr, nodeVal);
                if (nReVal == SciCam.SCI_CAMERA_OK)
                {
                    Console.WriteLine("Set device node: {0}, val: {1} success!", inputStr, nodeVal);
                }
            }
            else if (op == 11)
            {
                inputStr = GetInputNodeName();
                Console.Write("Please input node value(string): ");
                string nodeVal = Console.ReadLine();
                nReVal = m_currentDev.SetEnumValueByString(inputStr, nodeVal);
                if (nReVal == SciCam.SCI_CAMERA_OK)
                {
                    Console.WriteLine("Set device node: {0}, val: {1} success!", inputStr, nodeVal);
                }
            }
            else if (op == 12)
            {
                inputStr = GetInputNodeName();
                string[] opMenu =
                {
                    "[0] Cancel",
                    "[1] Execute"
                };
                ShowMenu(opMenu);
                int inVal = WaitForNumInput(true, 0, 1);
                if (inVal == 0)
                {
                    nReVal = 0;
                }
                else
                {
                    nReVal = m_currentDev.SetCommandValue(inputStr);
                    if (nReVal == SciCam.SCI_CAMERA_OK)
                    {
                        Console.WriteLine("Set device node: {0} command value success!", inputStr);
                    }
                }
            }
            else if (op == 13)
            {
                SciCam.SCI_CAM_NODE[] nodes = null;
                uint nodesCount = 0;
                nReVal = m_currentDev.GetNodes(ref nodes, ref nodesCount);
                if (nReVal == SciCam.SCI_CAMERA_OK)
                {
                    if (nodesCount == 0)
                    {
                        Console.WriteLine("Get nodes success, but the nodes count is 0.");
                        return;
                    }

                    ClrScreen();
                    Console.WriteLine("Successfully retrieved all nodes of the device, the number of nodes is: {0}", nodesCount);

                    nodes = new SciCam.SCI_CAM_NODE[nodesCount];
                    nReVal = m_currentDev.GetNodes(ref nodes, ref nodesCount);
                    if (nReVal == SciCam.SCI_CAMERA_OK)
                    {
                        Console.WriteLine(new string('-', 140));
                        Console.WriteLine("{0,-70} {1,-15} {2,-15} {3,-15} {4,-15} {5}", "NodeName", "NodeType", "Namespace", "Visibility", "AccessMode", "Value");
                        Console.WriteLine(new string('-', 140));
                        foreach (var node in nodes)
                        {
                            Console.WriteLine("{0,-70} {1,-15} {2,-15} {3,-15} {4,-15} {5}",
                                new string(' ', node.level * 4) + node.name,
                                GetEnumStr_SciCamNodeType(node.type),
                                GetEnumStr_SciCamNodeNameSpace(node.nameSpace),
                                GetEnumStr_SciCamNodeVisibility(node.visibility),
                                GetEnumStr_SciCamNodeAccessMode(node.accessMode),
                                GetNodeValueStr(SciCam.SciCamDeviceXmlType.SciCam_DeviceXml_Camera, node));
                        }
                    }
                }
            }
            else if (op == 14)
            {
                inputStr = GetInputNodeName();
                SciCam.SciCamDeviceXmlType xmlType = GetInputDeviceNodeXmlType();
                SciCam.SCI_NODE_VAL_INT nodeVal = new SciCam.SCI_NODE_VAL_INT();
                nReVal = m_currentDev.GetIntValueEx(xmlType, inputStr, ref nodeVal);
                if (nReVal == SciCam.SCI_CAMERA_OK)
                {
                    Console.WriteLine("---- Node Name: {0}", inputStr);
                    Console.WriteLine("---- Node Value: {0}", nodeVal.nVal);
                    Console.WriteLine("---- Node Max: {0}", nodeVal.nMax);
                    Console.WriteLine("---- Node Min: {0}", nodeVal.nMin);
                    Console.WriteLine("---- Node Inc: {0}", nodeVal.nInc);
                }
            }
            else if (op == 15)
            {
                inputStr = GetInputNodeName();
                SciCam.SciCamDeviceXmlType xmlType = GetInputDeviceNodeXmlType();
                Console.Write("Please input node value(int): ");
                int nodeVal = WaitForNumInput(false, 0, 0);
                nReVal = m_currentDev.SetIntValueEx(xmlType, inputStr, nodeVal);
                if (nReVal == SciCam.SCI_CAMERA_OK)
                {
                    Console.WriteLine("Set device node: {0}, val: {1} success!", inputStr, nodeVal);
                }
            }
            else if (op == 16)
            {
                inputStr = GetInputNodeName();
                SciCam.SciCamDeviceXmlType xmlType = GetInputDeviceNodeXmlType();
                SciCam.SCI_NODE_VAL_FLOAT nodeVal = new SciCam.SCI_NODE_VAL_FLOAT();
                nReVal = m_currentDev.GetFloatValueEx(xmlType, inputStr, ref nodeVal);
                if (nReVal == SciCam.SCI_CAMERA_OK)
                {
                    Console.WriteLine("---- Node Name: {0}", inputStr);
                    Console.WriteLine("---- Node Value: {0}", nodeVal.dVal);
                    Console.WriteLine("---- Node Max: {0}", nodeVal.dMax);
                    Console.WriteLine("---- Node Min: {0}", nodeVal.dMin);
                    Console.WriteLine("---- Node Inc: {0}", nodeVal.dInc);
                }
            }
            else if (op == 17)
            {
                inputStr = GetInputNodeName();
                SciCam.SciCamDeviceXmlType xmlType = GetInputDeviceNodeXmlType();
                Console.Write("Please input node value(double): ");
                double nodeVal = WaitForDoubleNumInput();
                nReVal = m_currentDev.SetFloatValueEx(xmlType, inputStr, nodeVal);
                if (nReVal == SciCam.SCI_CAMERA_OK)
                {
                    Console.WriteLine("Set device node: {0}, val: {0} success!", inputStr, nodeVal);
                }
            }
            else if (op == 18)
            {
                inputStr = GetInputNodeName();
                SciCam.SciCamDeviceXmlType xmlType = GetInputDeviceNodeXmlType();
                bool nodeVal = false;
                nReVal = m_currentDev.GetBoolValueEx(xmlType, inputStr, ref nodeVal);
                if (nReVal == SciCam.SCI_CAMERA_OK)
                {
                    Console.WriteLine("---- Node Name: {0}", inputStr);
                    Console.WriteLine("---- Node Value: {0}", (nodeVal ? "true" : "false"));
                }
            }
            else if (op == 19)
            {
                inputStr = GetInputNodeName();
                SciCam.SciCamDeviceXmlType xmlType = GetInputDeviceNodeXmlType();
                Console.Write("Please input node value(0 is false, ~0 is true)");
                int nodeValTem = WaitForNumInput(false, 0, 0);
                bool nodeVal = nodeValTem == 0 ? false : true;
                nReVal = m_currentDev.SetBoolValueEx(xmlType, inputStr, nodeVal);
                if (nReVal == SciCam.SCI_CAMERA_OK)
                {
                    Console.WriteLine("Set device node: {0}, val: {1} success!", inputStr, (nodeVal ? "true" : "false"));
                }
            }
            else if (op == 20)
            {
                inputStr = GetInputNodeName();
                SciCam.SciCamDeviceXmlType xmlType = GetInputDeviceNodeXmlType();
                SciCam.SCI_NODE_VAL_STRING nodeVal = new SciCam.SCI_NODE_VAL_STRING();
                nReVal = m_currentDev.GetStringValueEx(xmlType, inputStr, ref nodeVal);
                if (nReVal == SciCam.SCI_CAMERA_OK)
                {
                    Console.WriteLine("---- Node Name: {0}", inputStr);
                    Console.WriteLine("---- Node Value: {0}", nodeVal.val);
                }
            }
            else if (op == 21)
            {
                inputStr = GetInputNodeName();
                SciCam.SciCamDeviceXmlType xmlType = GetInputDeviceNodeXmlType();
                Console.Write("Please input node value(string): ");
                string nodeVal = Console.ReadLine();
                nReVal = m_currentDev.SetStringValueEx(xmlType, inputStr, nodeVal);
                if (nReVal == SciCam.SCI_CAMERA_OK)
                {
                    Console.WriteLine("Set device node: {0}, val: {1} success!", inputStr, nodeVal);
                }
            }
            else if (op == 22)
            {
                inputStr = GetInputNodeName();
                SciCam.SciCamDeviceXmlType xmlType = GetInputDeviceNodeXmlType();
                SciCam.SCI_NODE_VAL_ENUM nodeVal = new SciCam.SCI_NODE_VAL_ENUM();
                nReVal = m_currentDev.GetEnumValueEx(xmlType, inputStr, ref nodeVal);
                if (nReVal == SciCam.SCI_CAMERA_OK)
                {
                    Console.WriteLine("---- Node Name: {0}", inputStr);
                    Console.WriteLine("---- Node Current Value: {0}", nodeVal.nVal);
                    Console.WriteLine("-------- Node enum item count: {0}", nodeVal.itemCount);
                    Console.WriteLine("-------- Node enum items:");
                    for (int i = 0; i < nodeVal.itemCount; i++)
                    {
                        Console.WriteLine("-------- {0}\t{1}", nodeVal.items[i].val, nodeVal.items[i].desc);
                    }
                }
            }
            else if (op == 23)
            {
                inputStr = GetInputNodeName();
                SciCam.SciCamDeviceXmlType xmlType = GetInputDeviceNodeXmlType();
                Console.Write("Please input node value(int): ");
                int nodeVal = WaitForNumInput(false, 0, 0);
                nReVal = m_currentDev.SetEnumValueEx(xmlType, inputStr, nodeVal);
                if (nReVal == SciCam.SCI_CAMERA_OK)
                {
                    Console.WriteLine("Set device node: {0}, val: {1} success!", inputStr, nodeVal);
                }
            }
            else if (op == 24)
            {
                inputStr = GetInputNodeName();
                SciCam.SciCamDeviceXmlType xmlType = GetInputDeviceNodeXmlType();
                Console.Write("Please input node value(string): ");
                string nodeVal = Console.ReadLine();
                nReVal = m_currentDev.SetEnumValueByStringEx(xmlType, inputStr, nodeVal);
                if (nReVal == SciCam.SCI_CAMERA_OK)
                {
                    Console.WriteLine("Set device node: {0}, val: {1} success!", inputStr, nodeVal);
                }
            }
            else if (op == 25)
            {
                inputStr = GetInputNodeName();
                SciCam.SciCamDeviceXmlType xmlType = GetInputDeviceNodeXmlType();
                string[] opMenu =
                {
                    "[0] Cancel",
                    "[1] Execute"
                };
                ShowMenu(opMenu);
                int inVal = WaitForNumInput(true, 0, 1);
                if (inVal == 0)
                {
                    nReVal = 0;
                }
                else
                {
                    nReVal = m_currentDev.SetCommandValueEx(xmlType, inputStr);
                    if (nReVal == SciCam.SCI_CAMERA_OK)
                    {
                        Console.WriteLine("Set device node: {0} command value success!", inputStr);
                    }
                }
            }
            else if (op == 26)
            {
                SciCam.SciCamDeviceXmlType xmlType = GetInputDeviceNodeXmlType();

                SciCam.SCI_CAM_NODE[] nodes = null;
                uint nodesCount = 0;
                nReVal = m_currentDev.GetNodesEx(xmlType, ref nodes, ref nodesCount);
                if (nReVal == SciCam.SCI_CAMERA_OK)
                {
                    if (nodesCount == 0)
                    {
                        Console.WriteLine("Get nodes success, but the nodes count is 0.");
                        return;
                    }

                    ClrScreen();
                    Console.WriteLine("Successfully retrieved all nodes of the device, the number of nodes is: {0}", nodesCount);

                    nodes = new SciCam.SCI_CAM_NODE[nodesCount];
                    nReVal = m_currentDev.GetNodesEx(xmlType, ref nodes, ref nodesCount);
                    if (nReVal == SciCam.SCI_CAMERA_OK)
                    {
                        Console.WriteLine(new string('-', 140));
                        Console.WriteLine("{0,-70} {1,-15} {2,-15} {3,-15} {4,-15} {5}", "NodeName", "NodeType", "Namespace", "Visibility", "AccessMode", "Value");
                        Console.WriteLine(new string('-', 140));
                        foreach (var node in nodes)
                        {
                            Console.WriteLine("{0,-70} {1,-15} {2,-15} {3,-15} {4,-15} {5}",
                                new string(' ', node.level * 4) + node.name,
                                GetEnumStr_SciCamNodeType(node.type),
                                GetEnumStr_SciCamNodeNameSpace(node.nameSpace),
                                GetEnumStr_SciCamNodeVisibility(node.visibility),
                                GetEnumStr_SciCamNodeAccessMode(node.accessMode),
                                GetNodeValueStr(xmlType, node));
                        }
                    }
                }
            }

            if (nReVal != SciCam.SCI_CAMERA_OK)
            {
                Console.WriteLine("Operation failed, return error code: {0}: {1}", nReVal, GetErrorCodeStr(nReVal));
            }
        }

        static void ShowDeviceInfo(ref SciCam.SCI_DEVICE_INFO device)
        {
            string devType = GetEnumStr_SciCamDeviceType(device.devType);
            Console.WriteLine("| Device type: {0}", devType);

            string devTlType = GetEnumStr_SciCamTLType(device.tlType);
            Console.WriteLine("| Device transfer type: {0}", devTlType);

            if (device.tlType == SciCam.SciCamTLType.SciCam_TLType_Gige)
            {
                SciCam.SCI_DEVICE_GIGE_INFO gigeDevInfo = (SciCam.SCI_DEVICE_GIGE_INFO)SciCam.ByteToStruct(device.info.gigeInfo, typeof(SciCam.SCI_DEVICE_GIGE_INFO));
                Console.WriteLine("| Camera status: {0}", gigeDevInfo.status);
                Console.WriteLine("| Camera name: {0}", gigeDevInfo.name);
                Console.WriteLine("| Camera manufactureName: {0}", gigeDevInfo.manufactureName);
                Console.WriteLine("| Camera modelName: {0}", gigeDevInfo.modelName);
                Console.WriteLine("| Camera version: {0}", gigeDevInfo.version);
                Console.WriteLine("| Camera userDefineName: {0}", gigeDevInfo.userDefineName);
                Console.WriteLine("| Camera serialNumber: {0}", gigeDevInfo.serialNumber);
                Console.WriteLine("| Camera mac: {0:X}:{1:X}:{2:X}:{3:X}:{4:X}:{5:X}", gigeDevInfo.mac[0], gigeDevInfo.mac[1], gigeDevInfo.mac[2], gigeDevInfo.mac[3], gigeDevInfo.mac[4], gigeDevInfo.mac[5]);
                Console.WriteLine("| Camera ip: {0}", i4tos(gigeDevInfo.ip));
                Console.WriteLine("| Camera mask: {0}", i4tos(gigeDevInfo.mask));
                Console.WriteLine("| Camera gateway: {0}", i4tos(gigeDevInfo.gateway));
                Console.WriteLine("| Camera adapterIp: {0}", i4tos(gigeDevInfo.adapterIp));
                Console.WriteLine("| Camera adapterMask: {0}", i4tos(gigeDevInfo.adapterMask));
                Console.WriteLine("| Camera adapterName: {0}", gigeDevInfo.adapterName);
            }
            else if (device.tlType == SciCam.SciCamTLType.SciCam_TLType_Usb3)
            {
                SciCam.SCI_DEVICE_USB3_INFO usb3Info = (SciCam.SCI_DEVICE_USB3_INFO)SciCam.ByteToStruct(device.info.gigeInfo, typeof(SciCam.SCI_DEVICE_USB3_INFO));
                Console.WriteLine("| Camera status: {0}", usb3Info.status);
                Console.WriteLine("| Camera name: {0}", usb3Info.name);
                Console.WriteLine("| Camera manufactureName: {0}", usb3Info.manufactureName);
                Console.WriteLine("| Camera modelName: {0}", usb3Info.modelName);
                Console.WriteLine("| Camera version: {0}", usb3Info.version);
                Console.WriteLine("| Camera userDefineName: {0}", usb3Info.userDefineName);
                Console.WriteLine("| Camera serialNumber: {0}", usb3Info.serialNumber);
                Console.WriteLine("| Camera guid: {0}", usb3Info.guid);
                Console.WriteLine("| Camera U3VVersion: {0}", usb3Info.U3VVersion);
                Console.WriteLine("| Camera GenCPVersion: {0}", usb3Info.GenCPVersion);
            }
            else if (device.tlType == SciCam.SciCamTLType.SciCam_TLType_CL)
            {
                SciCam.SCI_DEVICE_CL_INFO clInfo = (SciCam.SCI_DEVICE_CL_INFO)SciCam.ByteToStruct(device.info.gigeInfo, typeof(SciCam.SCI_DEVICE_CL_INFO));
                Console.WriteLine("| Card Status: {0}", clInfo.cardStatus);
                Console.WriteLine("| Card Name: {0}", clInfo.cardName);
                Console.WriteLine("| Card Manufacture: {0}", clInfo.cardManufacture);
                Console.WriteLine("| Card Model: {0}", clInfo.cardModel);
                Console.WriteLine("| Card Version: {0}", clInfo.cardVersion);
                Console.WriteLine("| Card UserDefineName: {0}", clInfo.cardUserDefineName);
                Console.WriteLine("| Card SerialNumber: {0}", clInfo.cardSerialNumber);

                Console.WriteLine("| Camera Status: {0}", clInfo.cameraStatus);
                Console.WriteLine("| Camera Type: {0}", clInfo.cameraType);
                Console.WriteLine("| Camera Baud: {0}", clInfo.cameraBaud);
                Console.WriteLine("| Camera Model: {0}", clInfo.cameraModel);
                Console.WriteLine("| Camera Manufacture: {0}", clInfo.cameraManufacture);
                Console.WriteLine("| Camera Family: {0}", clInfo.cameraFamily);
                Console.WriteLine("| Camera Model: {0}", clInfo.cameraModel);
                Console.WriteLine("| Camera Version: {0}", clInfo.cameraVersion);
                Console.WriteLine("| Camera SerialNumber: {0}", clInfo.cameraSerialNumber);
                Console.WriteLine("| Camera SerialPort: {0}", clInfo.cameraSerialPort);
                Console.WriteLine("| Camera Protocol: {0}", clInfo.cameraProtocol);
            }
        }

        static string i4tos(uint ip)
        {
            IPAddress iPAddress = new IPAddress(ip);
            return iPAddress.ToString();
        }

        static string GetInputNodeName()
        {
            Console.Write("Please enter node name(string): ");
            return Console.ReadLine();
        }

        static SciCam.SciCamDeviceXmlType GetInputDeviceNodeXmlType()
        {
            string[] menu =
            {
                "[0] SciCam_DeviceXml_Camera",
                "[1] SciCam_DeviceXml_Card",
                "[2] SciCam_DeviceXml_TL",
                "[3] SciCam_DeviceXml_IF",
                "[4] SciCam_DeviceXml_DS"
            };
            ShowMenu(menu);
            int op = WaitForNumInput(true, 0, 4);
            return (SciCam.SciCamDeviceXmlType)op;
        }

        static string GetNodeValueStr(SciCam.SciCamDeviceXmlType xmlType, SciCam.SCI_CAM_NODE node)
        {
            SciCam.SciCamNodeType type = node.type;
            string valStr = "N/A";
            uint nReVal = SciCam.SCI_ERR_CAMERA_UNKNOW;

            SciCam.SCI_NODE_VAL_INT iVal = new SciCam.SCI_NODE_VAL_INT();
            bool bVal = false;
            SciCam.SCI_NODE_VAL_FLOAT fVal = new SciCam.SCI_NODE_VAL_FLOAT();
            SciCam.SCI_NODE_VAL_ENUM eVal = new SciCam.SCI_NODE_VAL_ENUM();
            SciCam.SCI_NODE_VAL_STRING sVal = new SciCam.SCI_NODE_VAL_STRING();

            switch (type)
            {
                case SciCam.SciCamNodeType.SciCam_NodeType_Unknown:
                    break;
                case SciCam.SciCamNodeType.SciCam_NodeType_Bool:
                    nReVal = m_currentDev.GetBoolValueEx(xmlType, node.name, ref bVal);
                    valStr = nReVal == SciCam.SCI_CAMERA_OK ? (bVal ? "True" : "False") : "N/A";
                    break;
                case SciCam.SciCamNodeType.SciCam_NodeType_Int:
                    nReVal = m_currentDev.GetIntValueEx(xmlType, node.name, ref iVal);
                    valStr = nReVal == SciCam.SCI_CAMERA_OK ? iVal.nVal.ToString() : "N/A";
                    break;
                case SciCam.SciCamNodeType.SciCam_NodeType_Float:
                    nReVal = m_currentDev.GetFloatValueEx(xmlType, node.name, ref fVal);
                    valStr = nReVal == SciCam.SCI_CAMERA_OK ? fVal.dVal.ToString() : "N/A";
                    break;
                case SciCam.SciCamNodeType.SciCam_NodeType_Enum:
                    nReVal = m_currentDev.GetEnumValueEx(xmlType, node.name, ref eVal);
                    valStr = nReVal == SciCam.SCI_CAMERA_OK ? eVal.nVal.ToString() : "N/A";
                    break;
                case SciCam.SciCamNodeType.SciCam_NodeType_String:
                    nReVal = m_currentDev.GetStringValueEx(xmlType, node.name, ref sVal);
                    valStr = nReVal == SciCam.SCI_CAMERA_OK ? sVal.val : "N/A";
                    break;
                default:
                    break;
            }

            return valStr;
        }

        static string GetEnumStr_SciCamTLType(SciCam.SciCamTLType val)
        {
            switch (val)
            {
                case SciCam.SciCamTLType.SciCam_TLType_Unknown:
                    return "Unknown";
                case SciCam.SciCamTLType.SciCam_TLType_Gige:
                    return "Gige";
                case SciCam.SciCamTLType.SciCam_TLType_Usb3:
                    return "USB3";
                case SciCam.SciCamTLType.SciCam_TLType_CL:
                    return "CL";
                case SciCam.SciCamTLType.SciCam_TLType_CXP:
                    return "CXP";
                case SciCam.SciCamTLType.SciCam_TLType_IIDC:
                    return "IIDC";
                case SciCam.SciCamTLType.SciCam_TLType_UVC:
                    return "UVC";
                case SciCam.SciCamTLType.SciCam_TLType_CLHS:
                    return "CLHS";
                case SciCam.SciCamTLType.SciCam_TLType_Ethernet:
                    return "Ethernet";
                case SciCam.SciCamTLType.SciCam_TLType_PCI:
                    return "PCI";
                case SciCam.SciCamTLType.SciCam_TLType_CL_CAM_ONLY:
                    return "CL_CAM_ONLY";
                default:
                    break;
            }

            return "Invalid";
        }

        static string GetEnumStr_SciCamDeviceType(SciCam.SciCamDeviceType val)
        {
            switch (val)
            {
                case SciCam.SciCamDeviceType.SciCam_DeviceType_Unknown:
                    return "Unknown device";
                case SciCam.SciCamDeviceType.SciCam_DeviceType_2D:
                    return "2D device";
                case SciCam.SciCamDeviceType.SciCam_DeviceType_3DLP:
                    return "3DLP device";
                default:
                    break;
            }

            return "Invalid";
        }

        static string GetEnumStr_SciCamGrabStrategy(SciCam.SciCamGrabStrategy val)
        {
            switch (val)
            {
                case SciCam.SciCamGrabStrategy.SciCam_GrabStrategy_OneByOne:
                    return "OneByOne";
                case SciCam.SciCamGrabStrategy.SciCam_GrabStrategy_Latest:
                    return "Latest";
                case SciCam.SciCamGrabStrategy.SciCam_GrabStrategy_Upcoming:
                    return "Upcoming";
                default:
                    break;
            }

            return "Invalid";
        }

        static string GetEnumStr_SciCamDeviceXmlType(SciCam.SciCamDeviceXmlType val)
        {
            switch (val)
            {
                case SciCam.SciCamDeviceXmlType.SciCam_DeviceXml_Camera:
                    return "Camera";
                case SciCam.SciCamDeviceXmlType.SciCam_DeviceXml_Card:
                    return "Card";
                case SciCam.SciCamDeviceXmlType.SciCam_DeviceXml_TL:
                    return "TL";
                case SciCam.SciCamDeviceXmlType.SciCam_DeviceXml_IF:
                    return "IF";
                case SciCam.SciCamDeviceXmlType.SciCam_DeviceXml_DS:
                    return "DS";
                default:
                    break;
            }

            return "Invalid";
        }

        static string GetEnumStr_SciCamNodeType(SciCam.SciCamNodeType val)
        {
            switch (val)
            {
                case SciCam.SciCamNodeType.SciCam_NodeType_Unknown:
                    return "Unknown";
                case SciCam.SciCamNodeType.SciCam_NodeType_Bool:
                    return "Bool";
                case SciCam.SciCamNodeType.SciCam_NodeType_Int:
                    return "Int";
                case SciCam.SciCamNodeType.SciCam_NodeType_Float:
                    return "Float";
                case SciCam.SciCamNodeType.SciCam_NodeType_Enum:
                    return "Enum";
                case SciCam.SciCamNodeType.SciCam_NodeType_Cmd:
                    return "Cmd";
                case SciCam.SciCamNodeType.SciCam_NodeType_String:
                    return "String";
                case SciCam.SciCamNodeType.SciCam_NodeType_Category:
                    return "Category";
                case SciCam.SciCamNodeType.SciCam_NodeType_Register:
                    return "Register";
                default:
                    break;
            }

            return "Invalid";
        }

        static string GetEnumStr_SciCamNodeNameSpace(SciCam.SciCamNodeNameSpace val)
        {
            switch (val)
            {
                case SciCam.SciCamNodeNameSpace.SciCam_NodeNameSpace_Custom:
                    return "Custom";
                case SciCam.SciCamNodeNameSpace.SciCam_NodeNameSpace_Standard:
                    return "Standard";
                case SciCam.SciCamNodeNameSpace.SciCam_NodeNameSpace_Unknown:
                    return "Unknown";
                default:
                    break;
            }

            return "Invalid";
        }

        static string GetEnumStr_SciCamNodeVisibility(SciCam.SciCamNodeVisibility val)
        {
            switch (val)
            {
                case SciCam.SciCamNodeVisibility.SciCam_NodeVisibility_Beginner:
                    return "Beginner";
                case SciCam.SciCamNodeVisibility.SciCam_NodeVisibility_Expert:
                    return "Expert";
                case SciCam.SciCamNodeVisibility.SciCam_NodeVisibility_Guru:
                    return "Guru";
                case SciCam.SciCamNodeVisibility.SciCam_NodeVisibility_Invisible:
                    return "Invisible";
                case SciCam.SciCamNodeVisibility.SciCam_NodeVisibility_Unknown:
                    return "Unknown";
                default:
                    break;
            }

            return "Invalid";
        }

        static string GetEnumStr_SciCamNodeAccessMode(SciCam.SciCamNodeAccessMode val)
        {
            switch (val)
            {
                case SciCam.SciCamNodeAccessMode.SciCam_NodeAccessMode_NI:
                    return "NI";
                case SciCam.SciCamNodeAccessMode.SciCam_NodeAccessMode_NA:
                    return "NA";
                case SciCam.SciCamNodeAccessMode.SciCam_NodeAccessMode_WO:
                    return "WO";
                case SciCam.SciCamNodeAccessMode.SciCam_NodeAccessMode_RO:
                    return "RO";
                case SciCam.SciCamNodeAccessMode.SciCam_NodeAccessMode_RW:
                    return "RW";
                case SciCam.SciCamNodeAccessMode.SciCam_NodeAccessMode_Unknown:
                    return "Unknown";
                case SciCam.SciCamNodeAccessMode.SciCam_NodeAccessMode_CycleDetect:
                    return "CycleDetect";
                default:
                    break;
            }

            return "Invalid";
        }

        static string GetEnumStr_SciCamPayloadMode(SciCam.SciCamPayloadMode val)
        {
            switch (val)
            {
                case SciCam.SciCamPayloadMode.SciCam_PayloadMode_Unknown:
                    return "Unknown mode";
                case SciCam.SciCamPayloadMode.SciCam_PayloadMode_2D:
                    return "2D mode";
                case SciCam.SciCamPayloadMode.SciCam_PayloadMode_LP3D_Image:
                    return "Image mode";
                case SciCam.SciCamPayloadMode.SciCam_PayloadMode_LP3D_Contour:
                    return "Contour mode";
                case SciCam.SciCamPayloadMode.SciCam_PayloadMode_LP3D_BatchContour:
                    return "BatchContour mode";
                case SciCam.SciCamPayloadMode.SciCam_PayloadMode_ACC:
                    return "ACC mode";
                default:
                    break;
            }

            return "Invalid";
        }

        static string GetEnumStr_SciCamPayloadDataType(SciCam.SciCamPayloadDataType val)
        {
            switch (val)
            {
                case SciCam.SciCamPayloadDataType.SciCam_Payload_DataType_UCHAR:
                    return "UCHAR";
                case SciCam.SciCamPayloadDataType.SciCam_Payload_DataType_CHAR:
                    return "CHAR";
                case SciCam.SciCamPayloadDataType.SciCam_Payload_DataType_USHORT:
                    return "USHORT";
                case SciCam.SciCamPayloadDataType.SciCam_Payload_DataType_SHORT:
                    return "SHORT";
                case SciCam.SciCamPayloadDataType.SciCam_Payload_DataType_INT:
                    return "INT";
                case SciCam.SciCamPayloadDataType.SciCam_Payload_DataType_FLOAT:
                    return "FLOAT";
                case SciCam.SciCamPayloadDataType.SciCam_Payload_DataType_DOUBLE:
                    return "DOUBLE";
                default:
                    break;
            }

            return "Invalid";
        }

        static string GetErrorCodeStr(uint code)
        {
            switch (code)
            {
                case SciCam.SCI_CAMERA_OK: return "Success.";

                case SciCam.SCI_ERR_CAMERA_INCORRECT_INIT_OBJECT: return "Incorrect initialization object.";
                case SciCam.SCI_ERR_CAMERA_PARAM_INVALID: return "Parameter is invalid.";
                case SciCam.SCI_ERR_CAMERA_SDK_VERSION_MISMATCH: return "SDK version mismatch.";
                case SciCam.SCI_ERR_CAMERA_UNKNOW: return "Unknow error.";
                case SciCam.SCI_ERR_CAMERA_FUNCTION_CONFLICT: return "Function or interface call conflict.";

                case SciCam.SCI_ERR_CAMERA_ENUM_DEVICES_FAILED: return "Failed to search camera.";
                case SciCam.SCI_ERR_CAMERA_MODIFY_IP_ADDRESS_FAILED: return "Failed to modify camera ip address.";
                case SciCam.SCI_ERR_CAMERA_SET_PERSISTENT_IP_FAILED: return "Failed to modify persistent camera ip address.";
                case SciCam.SCI_ERR_CAMERA_CREATE_FAILED: return "Failed to create a camera object.";
                case SciCam.SCI_ERR_CAMERA_EXCEPTION: return "Camera operation exception.";
                case SciCam.SCI_ERR_CAMERA_NOT_FOUND: return "Cannot to find camera.";
                case SciCam.SCI_ERR_CAMERA_OFFLINE: return "Camera is offline.";
                case SciCam.SCI_ERR_CAMERA_OPEN_FAILED: return "Failed to open camera.";
                case SciCam.SCI_ERR_CAMERA_NOT_MISMATCHACQ: return "Camera mismatch witch ACQ.";
                case SciCam.SCI_ERR_CAMERA_NOT_SUPPORT: return "Camera does not support.";
                case SciCam.SCI_ERR_CAMERA_NOT_OPEN: return "Camera isn't open.";
                case SciCam.SCI_ERR_CAMERA_ALLREADY_OPEN: return "Camera allready open.";
                case SciCam.SCI_ERR_CAMERA_OCCUPANCY: return "Camera occupied by another device.";
                case SciCam.SCI_ERR_CAMERA_ROMOVED: return "The camera was removed.";

                case SciCam.SCI_ERR_CAMERA_START_GRAB_FAILED: return "Failed to start grab.";
                case SciCam.SCI_ERR_CAMERA_NOT_GRABBING: return "Camera isn't grabbing.";
                case SciCam.SCI_ERR_CAMERA_ALREADY_GRABBING: return "Camera is grabbing.";
                case SciCam.SCI_ERR_CAMERA_GRAB_FAILED: return "Camera grab failed.";
                case SciCam.SCI_ERR_CAMERA_GRAB_TIMEOUT: return "Grab image timeout.";
                case SciCam.SCI_ERR_CAMERA_TRIGGER_WAIT_FAILED: return "Wait for trigger failed.";
                case SciCam.SCI_ERR_CAMERA_SOFTWARE_TRIGGER_FAILED: return "Failed to set software trigger.";
                case SciCam.SCI_ERR_CAMERA_GRAB_EXCEPTION: return "Camera grab image exception.";
                case SciCam.SCI_ERR_CAMERA_GRAB_INTERRUPTED: return "Capture interrupted.";
                case SciCam.SCI_ERR_CAMERA_GRAB_INSUFFICIENT_BUFFER: return "Insufficient buffer for capture.";

                case SciCam.SCI_ERR_CAMERA_SET_VALUE_FAILED: return "Failed to set parameter value.";
                case SciCam.SCI_ERR_CAMERA_GET_VALUE_FAILED: return "Failed to Get parameter value.";
                case SciCam.SCI_ERR_CAMERA_SEND_CMD_FAILED: return "Failed to send command.";
                case SciCam.SCI_ERR_CAMERA_WRONG_ACK: return "Get ACK failed, maybe result of wrong IP.";
                case SciCam.SCI_ERR_CAMERA_FILE_OPEN_FAILED: return "Open camera configuration file error.";

                case SciCam.SCI_ERR_CAMERA_NODE_XML_TYPE: return "XML type error.";
                case SciCam.SCI_ERR_CAMERA_NODE_NAME_INVALID: return "Node name is invalid.";
                case SciCam.SCI_ERR_CAMERA_NODE_READ_FORBIDDEN: return "Node is forbidden to read.";
                case SciCam.SCI_ERR_CAMERA_NODE_WRITE_FORBIDDEN: return "Node is forbidden to write.";
                case SciCam.SCI_ERR_CAMERA_NODE_TYPE_INVALID: return "Node type is invalid.";
                case SciCam.SCI_ERR_CAMERA_NODE_TYPE_UNMATCH: return "Node type is unmatched.";
                case SciCam.SCI_ERR_CAMERA_NODE_VALUE: return "The value of node is wrong.";
                case SciCam.SCI_ERR_CAMERA_NODE_MAP_INVALID: return "Failed to access the node map.";
                case SciCam.SCI_ERR_CAMERA_NODE_GET_ROOT_NODE_FAILED: return "Failed to get root node.";
                case SciCam.SCI_ERR_CAMERA_NODE_TRAVERSE: return "Failed to traverse nodes.";

                case SciCam.SCI_ERR_CAMERA_IMAGE_INVALID: return "Image data is invalid.";
                case SciCam.SCI_ERR_CAMERA_IMAGE_CREATE_FAILED: return "Failed to create image file.";
                case SciCam.SCI_ERR_CAMERA_IMAGE_TYPE_NOT_SUPPORT: return "Image type does not support.";
                case SciCam.SCI_ERR_CAMERA_IMAGE_NOT_COMPLETE: return "Grab Image not complete.";
                case SciCam.SCI_ERR_CAMERA_IMAGE_DATACONVERT_FAILED: return "Failed to convert to image.";
                case SciCam.SCI_ERR_CAMERA_IMAGE_FORMAT: return "Image format is wrong.";
                case SciCam.SCI_ERR_CAMERA_IMAGE_GET_PROPERTY: return "Failed to get image properties (e.g., width, height).";
                case SciCam.SCI_ERR_CAMERA_IMAGE_OUT_OF_BOUNDS: return "Image data out of bounds.";

                case SciCam.SCI_ERR_CAMERA_CHUNKDATA_EMPTY: return "Chunk data is empty.";
                case SciCam.SCI_ERR_CAMERA_CHUNKDATA_LENGTH: return "Chunk data length is abnormal.";
                case SciCam.SCI_ERR_CAMERA_CHUNKDATA_PARSING_EXCEPTION: return "Chunk parsing exception.";

                case SciCam.SCI_ERR_CAMERA_MEMORY_ALLOCATION_FAILED: return "Memory allocation failed.";
                case SciCam.SCI_ERR_CAMERA_APPEND_BUFFER_FAILED: return "Failed to append buffer.";
                case SciCam.SCI_ERR_CAMERA_SYSTEM_RESOURCE_EXHAUSTED: return "System resource exhausted.";
                case SciCam.SCI_ERR_CAMERA_INSUFFICIENT_MEMORY_LENGTH: return "Insufficient memory length at the target address.";

                case SciCam.SCI_ERR_CAMERA_GET_CTI_OBJECT_NULL: return "Failed to get CTI object.";
                case SciCam.SCI_ERR_CAMERA_GET_ANY_PORT_FAILED: return "Failed to get any port (card port, data stream port, or device port) is null.";
                case SciCam.SCI_ERR_CAMERA_GET_IF_PORT_FAILED: return "Failed to get IF port.";
                case SciCam.SCI_ERR_CAMERA_GET_DEVICE_PORT_FAILED: return "Failed to get device port.";
                case SciCam.SCI_ERR_CAMERA_GET_DEVICE_DATA_STREAM_PORT_FAILED: return "Failed to get device data stream port.";
                case SciCam.SCI_ERR_CAMERA_GET_DEVICE_DATA_STREAM_FAILED: return "Failed to get device data stream.";
                case SciCam.SCI_ERR_CAMERA_GET_DEVICE_DATA_STREAM_COUNT_ZERO: return "Device data stream count is zero.";
                case SciCam.SCI_ERR_CAMERA_GET_DATA_STREAM_ID_FAILED: return "Failed to get device data stream ID.";
                case SciCam.SCI_ERR_CAMERA_OPEN_DATA_STREAM_FAILED: return "Failed to open data stream.";
                case SciCam.SCI_ERR_CAMERA_NODEMAP_NULL: return "Device nodemap is null.";
                case SciCam.SCI_ERR_CAMERA_PAYLOAD_SIZE_INVALID: return "Invalid payload size.";
                case SciCam.SCI_ERR_CAMERA_REGISTER_IMAGE_EVENT_FAILED: return "Failed to register image event.";
                case SciCam.SCI_ERR_CAMERA_CTI: return "CTI error.";
                case SciCam.SCI_ERR_CAMERA_DS: return "DS error.";
                case SciCam.SCI_ERR_CAMERA_GEN_TL_EVENT: return "GenTL Event error.";
                case SciCam.SCI_ERR_CAMERA_BUF: return "Buf error.";
            }

            return "Undefine error";
        }

        static void GrabPayloadData(IntPtr payload, IntPtr tag)
        {
            ShowPayloadDataAttribute(payload);
        }

        static void ShowPayloadDataAttribute(IntPtr payload)
        {
            SciCam.SCI_CAM_PAYLOAD_ATTRIBUTE payloadAttribute = new SciCam.SCI_CAM_PAYLOAD_ATTRIBUTE();
            uint nReVal = SciCam.PayloadGetAttribute(payload, ref payloadAttribute);
            if (nReVal != SciCam.SCI_CAMERA_OK)
            {
                Console.WriteLine("Get payload attribute failed, return error code: {0}: {1}", nReVal, GetErrorCodeStr(nReVal));
                return;
            }

            Console.WriteLine("***********************************");
            Console.WriteLine("Payload frameID: {0}", payloadAttribute.frameID);
            Console.WriteLine("Payload isComplete: {0}", payloadAttribute.isComplete ? "true" : "false");
            Console.WriteLine("Payload hasChunk: {0}", payloadAttribute.hasChunk ? "true" : "false");
            Console.WriteLine("Payload timeStamp: {0}", payloadAttribute.timeStamp);
            string payloadMode = GetEnumStr_SciCamPayloadMode(payloadAttribute.payloadMode);
            Console.WriteLine("Payload payloadMode: {0}", payloadMode);
            Console.WriteLine("--------------------");

            if (payloadAttribute.payloadMode == SciCam.SciCamPayloadMode.SciCam_PayloadMode_2D ||
                payloadAttribute.payloadMode == SciCam.SciCamPayloadMode.SciCam_PayloadMode_LP3D_Image)
            {
                Console.WriteLine("image width: {0}", payloadAttribute.imgAttr.width);
                Console.WriteLine("image height: {0}", payloadAttribute.imgAttr.height);
                Console.WriteLine("image offsetX: {0}", payloadAttribute.imgAttr.offsetX);
                Console.WriteLine("image offsetY: {0}", payloadAttribute.imgAttr.offsetY);
                Console.WriteLine("image paddingX: {0}", payloadAttribute.imgAttr.paddingX);
                Console.WriteLine("image paddingY: {0}", payloadAttribute.imgAttr.paddingY);
                Console.WriteLine("image pixelType: 0x{0:X}", (int)payloadAttribute.imgAttr.pixelType);
            }
            else if (payloadAttribute.payloadMode == SciCam.SciCamPayloadMode.SciCam_PayloadMode_LP3D_Contour ||
                payloadAttribute.payloadMode == SciCam.SciCamPayloadMode.SciCam_PayloadMode_LP3D_BatchContour)
            {
                SciCam.SCI_CAM_LP3D_META Meta = new SciCam.SCI_CAM_LP3D_META();
                nReVal = SciCam.PayloadLP3DGetMeta(payload, ref Meta);
                if (nReVal != SciCam.SCI_CAMERA_OK)
                {
                    Console.WriteLine("Get meta failed, return error code: {0}: {1}", nReVal, GetErrorCodeStr(nReVal));
                }

                Console.WriteLine("Frame ID:              {0}", Meta.frameId);
                Console.WriteLine("Intra-frame index:     {0}", Meta.index);
                Console.WriteLine("Frame completion flag: {0}", Meta.finished ? "true" : "false");
            }
        }

        private static SciCam.SCI_DEVICE_INFO m_currentDevInfo = new SciCam.SCI_DEVICE_INFO();
        private static SciCam m_currentDev = new SciCam();
        private static SciCam.fnOnPayloadDelegate m_imageCallBack;
    }
}

﻿namespace BaseDemo
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.comboBox_devList = new System.Windows.Forms.ComboBox();
            this.groupBox_init = new System.Windows.Forms.GroupBox();
            this.button_close = new System.Windows.Forms.Button();
            this.button_open = new System.Windows.Forms.Button();
            this.button_search = new System.Windows.Forms.Button();
            this.pictureBox_picture = new System.Windows.Forms.PictureBox();
            this.groupBox_grabImg = new System.Windows.Forms.GroupBox();
            this.button_execute = new System.Windows.Forms.Button();
            this.checkBox_softwareTrigger = new System.Windows.Forms.CheckBox();
            this.button_stopGrabbing = new System.Windows.Forms.Button();
            this.button_startGrabbing = new System.Windows.Forms.Button();
            this.radioButton_triggerMode = new System.Windows.Forms.RadioButton();
            this.radioButton_continusMode = new System.Windows.Forms.RadioButton();
            this.comboBox_pixelFormat = new System.Windows.Forms.ComboBox();
            this.label_pixelFormat = new System.Windows.Forms.Label();
            this.groupBox_saveImg = new System.Windows.Forms.GroupBox();
            this.button_savePNG = new System.Windows.Forms.Button();
            this.button_saveTIFF = new System.Windows.Forms.Button();
            this.button_saveJPG = new System.Windows.Forms.Button();
            this.button_saveBMP = new System.Windows.Forms.Button();
            this.groupBox_parameter = new System.Windows.Forms.GroupBox();
            this.button_setParameter = new System.Windows.Forms.Button();
            this.button_getParameter = new System.Windows.Forms.Button();
            this.textBox_frameRate = new System.Windows.Forms.TextBox();
            this.textBox_gain = new System.Windows.Forms.TextBox();
            this.textBox_exposure = new System.Windows.Forms.TextBox();
            this.label_frameRate = new System.Windows.Forms.Label();
            this.label_gain = new System.Windows.Forms.Label();
            this.label_exposure = new System.Windows.Forms.Label();
            this.groupBox_init.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_picture)).BeginInit();
            this.groupBox_grabImg.SuspendLayout();
            this.groupBox_saveImg.SuspendLayout();
            this.groupBox_parameter.SuspendLayout();
            this.SuspendLayout();
            // 
            // comboBox_devList
            // 
            this.comboBox_devList.FormattingEnabled = true;
            this.comboBox_devList.Location = new System.Drawing.Point(12, 12);
            this.comboBox_devList.Name = "comboBox_devList";
            this.comboBox_devList.Size = new System.Drawing.Size(761, 20);
            this.comboBox_devList.TabIndex = 0;
            // 
            // groupBox_init
            // 
            this.groupBox_init.Controls.Add(this.button_close);
            this.groupBox_init.Controls.Add(this.button_open);
            this.groupBox_init.Controls.Add(this.button_search);
            this.groupBox_init.Location = new System.Drawing.Point(779, 12);
            this.groupBox_init.Name = "groupBox_init";
            this.groupBox_init.Size = new System.Drawing.Size(253, 84);
            this.groupBox_init.TabIndex = 1;
            this.groupBox_init.TabStop = false;
            this.groupBox_init.Text = "初始化";
            // 
            // button_close
            // 
            this.button_close.Location = new System.Drawing.Point(133, 49);
            this.button_close.Name = "button_close";
            this.button_close.Size = new System.Drawing.Size(114, 23);
            this.button_close.TabIndex = 2;
            this.button_close.Text = "关闭设备";
            this.button_close.UseVisualStyleBackColor = true;
            this.button_close.Click += new System.EventHandler(this.button3_Click);
            // 
            // button_open
            // 
            this.button_open.Location = new System.Drawing.Point(6, 49);
            this.button_open.Name = "button_open";
            this.button_open.Size = new System.Drawing.Size(114, 23);
            this.button_open.TabIndex = 1;
            this.button_open.Text = "打开设备";
            this.button_open.UseVisualStyleBackColor = true;
            this.button_open.Click += new System.EventHandler(this.button2_Click);
            // 
            // button_search
            // 
            this.button_search.Location = new System.Drawing.Point(6, 20);
            this.button_search.Name = "button_search";
            this.button_search.Size = new System.Drawing.Size(241, 23);
            this.button_search.TabIndex = 0;
            this.button_search.Text = "搜索设备";
            this.button_search.UseVisualStyleBackColor = true;
            this.button_search.Click += new System.EventHandler(this.button1_Click);
            // 
            // pictureBox_picture
            // 
            this.pictureBox_picture.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.pictureBox_picture.Location = new System.Drawing.Point(12, 38);
            this.pictureBox_picture.Name = "pictureBox_picture";
            this.pictureBox_picture.Size = new System.Drawing.Size(761, 477);
            this.pictureBox_picture.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox_picture.TabIndex = 2;
            this.pictureBox_picture.TabStop = false;
            // 
            // groupBox_grabImg
            // 
            this.groupBox_grabImg.Controls.Add(this.button_execute);
            this.groupBox_grabImg.Controls.Add(this.checkBox_softwareTrigger);
            this.groupBox_grabImg.Controls.Add(this.button_stopGrabbing);
            this.groupBox_grabImg.Controls.Add(this.button_startGrabbing);
            this.groupBox_grabImg.Controls.Add(this.radioButton_triggerMode);
            this.groupBox_grabImg.Controls.Add(this.radioButton_continusMode);
            this.groupBox_grabImg.Controls.Add(this.comboBox_pixelFormat);
            this.groupBox_grabImg.Controls.Add(this.label_pixelFormat);
            this.groupBox_grabImg.Location = new System.Drawing.Point(779, 103);
            this.groupBox_grabImg.Name = "groupBox_grabImg";
            this.groupBox_grabImg.Size = new System.Drawing.Size(253, 151);
            this.groupBox_grabImg.TabIndex = 3;
            this.groupBox_grabImg.TabStop = false;
            this.groupBox_grabImg.Text = "图像采集";
            // 
            // button_execute
            // 
            this.button_execute.Location = new System.Drawing.Point(133, 116);
            this.button_execute.Name = "button_execute";
            this.button_execute.Size = new System.Drawing.Size(114, 23);
            this.button_execute.TabIndex = 7;
            this.button_execute.Text = "执行";
            this.button_execute.UseVisualStyleBackColor = true;
            this.button_execute.Click += new System.EventHandler(this.button6_Click);
            // 
            // checkBox_softwareTrigger
            // 
            this.checkBox_softwareTrigger.AutoSize = true;
            this.checkBox_softwareTrigger.Location = new System.Drawing.Point(9, 120);
            this.checkBox_softwareTrigger.Name = "checkBox_softwareTrigger";
            this.checkBox_softwareTrigger.Size = new System.Drawing.Size(60, 16);
            this.checkBox_softwareTrigger.TabIndex = 6;
            this.checkBox_softwareTrigger.Text = "软触发";
            this.checkBox_softwareTrigger.UseVisualStyleBackColor = true;
            this.checkBox_softwareTrigger.CheckedChanged += new System.EventHandler(this.checkBox1_CheckedChanged);
            // 
            // button_stopGrabbing
            // 
            this.button_stopGrabbing.Location = new System.Drawing.Point(133, 86);
            this.button_stopGrabbing.Name = "button_stopGrabbing";
            this.button_stopGrabbing.Size = new System.Drawing.Size(114, 23);
            this.button_stopGrabbing.TabIndex = 5;
            this.button_stopGrabbing.Text = "停止采集";
            this.button_stopGrabbing.UseVisualStyleBackColor = true;
            this.button_stopGrabbing.Click += new System.EventHandler(this.button5_Click);
            // 
            // button_startGrabbing
            // 
            this.button_startGrabbing.Location = new System.Drawing.Point(9, 86);
            this.button_startGrabbing.Name = "button_startGrabbing";
            this.button_startGrabbing.Size = new System.Drawing.Size(114, 23);
            this.button_startGrabbing.TabIndex = 4;
            this.button_startGrabbing.Text = "开始采集";
            this.button_startGrabbing.UseVisualStyleBackColor = true;
            this.button_startGrabbing.Click += new System.EventHandler(this.button4_Click);
            // 
            // radioButton_triggerMode
            // 
            this.radioButton_triggerMode.AutoSize = true;
            this.radioButton_triggerMode.Location = new System.Drawing.Point(133, 63);
            this.radioButton_triggerMode.Name = "radioButton_triggerMode";
            this.radioButton_triggerMode.Size = new System.Drawing.Size(71, 16);
            this.radioButton_triggerMode.TabIndex = 3;
            this.radioButton_triggerMode.TabStop = true;
            this.radioButton_triggerMode.Text = "触发模式";
            this.radioButton_triggerMode.UseVisualStyleBackColor = true;
            this.radioButton_triggerMode.CheckedChanged += new System.EventHandler(this.radioButton2_CheckedChanged);
            // 
            // radioButton_continusMode
            // 
            this.radioButton_continusMode.AutoSize = true;
            this.radioButton_continusMode.Location = new System.Drawing.Point(9, 63);
            this.radioButton_continusMode.Name = "radioButton_continusMode";
            this.radioButton_continusMode.Size = new System.Drawing.Size(71, 16);
            this.radioButton_continusMode.TabIndex = 2;
            this.radioButton_continusMode.TabStop = true;
            this.radioButton_continusMode.Text = "自由采集";
            this.radioButton_continusMode.UseVisualStyleBackColor = true;
            this.radioButton_continusMode.CheckedChanged += new System.EventHandler(this.radioButton1_CheckedChanged);
            // 
            // comboBox_pixelFormat
            // 
            this.comboBox_pixelFormat.FormattingEnabled = true;
            this.comboBox_pixelFormat.Location = new System.Drawing.Point(9, 37);
            this.comboBox_pixelFormat.Name = "comboBox_pixelFormat";
            this.comboBox_pixelFormat.Size = new System.Drawing.Size(238, 20);
            this.comboBox_pixelFormat.TabIndex = 1;
            this.comboBox_pixelFormat.SelectedIndexChanged += new System.EventHandler(this.comboBox_pixelFormat_SelectedIndexChanged);
            // 
            // label_pixelFormat
            // 
            this.label_pixelFormat.AutoSize = true;
            this.label_pixelFormat.Location = new System.Drawing.Point(7, 21);
            this.label_pixelFormat.Name = "label_pixelFormat";
            this.label_pixelFormat.Size = new System.Drawing.Size(65, 12);
            this.label_pixelFormat.TabIndex = 0;
            this.label_pixelFormat.Text = "像素格式：";
            // 
            // groupBox_saveImg
            // 
            this.groupBox_saveImg.Controls.Add(this.button_savePNG);
            this.groupBox_saveImg.Controls.Add(this.button_saveTIFF);
            this.groupBox_saveImg.Controls.Add(this.button_saveJPG);
            this.groupBox_saveImg.Controls.Add(this.button_saveBMP);
            this.groupBox_saveImg.Location = new System.Drawing.Point(779, 261);
            this.groupBox_saveImg.Name = "groupBox_saveImg";
            this.groupBox_saveImg.Size = new System.Drawing.Size(253, 82);
            this.groupBox_saveImg.TabIndex = 4;
            this.groupBox_saveImg.TabStop = false;
            this.groupBox_saveImg.Text = "图像保存";
            // 
            // button_savePNG
            // 
            this.button_savePNG.Location = new System.Drawing.Point(133, 49);
            this.button_savePNG.Name = "button_savePNG";
            this.button_savePNG.Size = new System.Drawing.Size(114, 23);
            this.button_savePNG.TabIndex = 11;
            this.button_savePNG.Text = "保存PNG";
            this.button_savePNG.UseVisualStyleBackColor = true;
            this.button_savePNG.Click += new System.EventHandler(this.button10_Click);
            // 
            // button_saveTIFF
            // 
            this.button_saveTIFF.Location = new System.Drawing.Point(6, 49);
            this.button_saveTIFF.Name = "button_saveTIFF";
            this.button_saveTIFF.Size = new System.Drawing.Size(114, 23);
            this.button_saveTIFF.TabIndex = 10;
            this.button_saveTIFF.Text = "保存TIFF";
            this.button_saveTIFF.UseVisualStyleBackColor = true;
            this.button_saveTIFF.Click += new System.EventHandler(this.button9_Click);
            // 
            // button_saveJPG
            // 
            this.button_saveJPG.Location = new System.Drawing.Point(133, 20);
            this.button_saveJPG.Name = "button_saveJPG";
            this.button_saveJPG.Size = new System.Drawing.Size(114, 23);
            this.button_saveJPG.TabIndex = 9;
            this.button_saveJPG.Text = "保存JPG";
            this.button_saveJPG.UseVisualStyleBackColor = true;
            this.button_saveJPG.Click += new System.EventHandler(this.button8_Click);
            // 
            // button_saveBMP
            // 
            this.button_saveBMP.Location = new System.Drawing.Point(6, 20);
            this.button_saveBMP.Name = "button_saveBMP";
            this.button_saveBMP.Size = new System.Drawing.Size(114, 23);
            this.button_saveBMP.TabIndex = 8;
            this.button_saveBMP.Text = "保存BMP";
            this.button_saveBMP.UseVisualStyleBackColor = true;
            this.button_saveBMP.Click += new System.EventHandler(this.button7_Click);
            // 
            // groupBox_parameter
            // 
            this.groupBox_parameter.Controls.Add(this.button_setParameter);
            this.groupBox_parameter.Controls.Add(this.button_getParameter);
            this.groupBox_parameter.Controls.Add(this.textBox_frameRate);
            this.groupBox_parameter.Controls.Add(this.textBox_gain);
            this.groupBox_parameter.Controls.Add(this.textBox_exposure);
            this.groupBox_parameter.Controls.Add(this.label_frameRate);
            this.groupBox_parameter.Controls.Add(this.label_gain);
            this.groupBox_parameter.Controls.Add(this.label_exposure);
            this.groupBox_parameter.Location = new System.Drawing.Point(779, 350);
            this.groupBox_parameter.Name = "groupBox_parameter";
            this.groupBox_parameter.Size = new System.Drawing.Size(253, 165);
            this.groupBox_parameter.TabIndex = 5;
            this.groupBox_parameter.TabStop = false;
            this.groupBox_parameter.Text = "参数";
            // 
            // button_setParameter
            // 
            this.button_setParameter.Location = new System.Drawing.Point(133, 136);
            this.button_setParameter.Name = "button_setParameter";
            this.button_setParameter.Size = new System.Drawing.Size(114, 23);
            this.button_setParameter.TabIndex = 13;
            this.button_setParameter.Text = "参数设置";
            this.button_setParameter.UseVisualStyleBackColor = true;
            this.button_setParameter.Click += new System.EventHandler(this.button12_Click);
            // 
            // button_getParameter
            // 
            this.button_getParameter.Location = new System.Drawing.Point(9, 136);
            this.button_getParameter.Name = "button_getParameter";
            this.button_getParameter.Size = new System.Drawing.Size(114, 23);
            this.button_getParameter.TabIndex = 12;
            this.button_getParameter.Text = "参数获取";
            this.button_getParameter.UseVisualStyleBackColor = true;
            this.button_getParameter.Click += new System.EventHandler(this.button11_Click);
            // 
            // textBox_frameRate
            // 
            this.textBox_frameRate.Location = new System.Drawing.Point(133, 100);
            this.textBox_frameRate.Name = "textBox_frameRate";
            this.textBox_frameRate.Size = new System.Drawing.Size(114, 21);
            this.textBox_frameRate.TabIndex = 5;
            // 
            // textBox_gain
            // 
            this.textBox_gain.Location = new System.Drawing.Point(133, 63);
            this.textBox_gain.Name = "textBox_gain";
            this.textBox_gain.Size = new System.Drawing.Size(114, 21);
            this.textBox_gain.TabIndex = 4;
            // 
            // textBox_exposure
            // 
            this.textBox_exposure.Location = new System.Drawing.Point(133, 25);
            this.textBox_exposure.Name = "textBox_exposure";
            this.textBox_exposure.Size = new System.Drawing.Size(114, 21);
            this.textBox_exposure.TabIndex = 3;
            // 
            // label_frameRate
            // 
            this.label_frameRate.AutoSize = true;
            this.label_frameRate.Location = new System.Drawing.Point(51, 103);
            this.label_frameRate.Name = "label_frameRate";
            this.label_frameRate.Size = new System.Drawing.Size(29, 12);
            this.label_frameRate.TabIndex = 2;
            this.label_frameRate.Text = "帧率";
            // 
            // label_gain
            // 
            this.label_gain.AutoSize = true;
            this.label_gain.Location = new System.Drawing.Point(51, 66);
            this.label_gain.Name = "label_gain";
            this.label_gain.Size = new System.Drawing.Size(29, 12);
            this.label_gain.TabIndex = 1;
            this.label_gain.Text = "增益";
            // 
            // label_exposure
            // 
            this.label_exposure.AutoSize = true;
            this.label_exposure.Location = new System.Drawing.Point(51, 28);
            this.label_exposure.Name = "label_exposure";
            this.label_exposure.Size = new System.Drawing.Size(29, 12);
            this.label_exposure.TabIndex = 0;
            this.label_exposure.Text = "曝光";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1044, 528);
            this.Controls.Add(this.groupBox_parameter);
            this.Controls.Add(this.groupBox_saveImg);
            this.Controls.Add(this.groupBox_grabImg);
            this.Controls.Add(this.pictureBox_picture);
            this.Controls.Add(this.groupBox_init);
            this.Controls.Add(this.comboBox_devList);
            this.Name = "Form1";
            this.Text = "SciCamera SDK CS演示程序";
            this.groupBox_init.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_picture)).EndInit();
            this.groupBox_grabImg.ResumeLayout(false);
            this.groupBox_grabImg.PerformLayout();
            this.groupBox_saveImg.ResumeLayout(false);
            this.groupBox_parameter.ResumeLayout(false);
            this.groupBox_parameter.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ComboBox comboBox_devList;
        private System.Windows.Forms.GroupBox groupBox_init;
        private System.Windows.Forms.Button button_search;
        private System.Windows.Forms.PictureBox pictureBox_picture;
        private System.Windows.Forms.Button button_close;
        private System.Windows.Forms.Button button_open;
        private System.Windows.Forms.GroupBox groupBox_grabImg;
        private System.Windows.Forms.Button button_execute;
        private System.Windows.Forms.CheckBox checkBox_softwareTrigger;
        private System.Windows.Forms.Button button_stopGrabbing;
        private System.Windows.Forms.Button button_startGrabbing;
        private System.Windows.Forms.RadioButton radioButton_triggerMode;
        private System.Windows.Forms.RadioButton radioButton_continusMode;
        private System.Windows.Forms.ComboBox comboBox_pixelFormat;
        private System.Windows.Forms.Label label_pixelFormat;
        private System.Windows.Forms.GroupBox groupBox_saveImg;
        private System.Windows.Forms.Button button_savePNG;
        private System.Windows.Forms.Button button_saveTIFF;
        private System.Windows.Forms.Button button_saveJPG;
        private System.Windows.Forms.Button button_saveBMP;
        private System.Windows.Forms.GroupBox groupBox_parameter;
        private System.Windows.Forms.Button button_setParameter;
        private System.Windows.Forms.Button button_getParameter;
        private System.Windows.Forms.TextBox textBox_frameRate;
        private System.Windows.Forms.TextBox textBox_gain;
        private System.Windows.Forms.TextBox textBox_exposure;
        private System.Windows.Forms.Label label_frameRate;
        private System.Windows.Forms.Label label_gain;
        private System.Windows.Forms.Label label_exposure;
    }
}

